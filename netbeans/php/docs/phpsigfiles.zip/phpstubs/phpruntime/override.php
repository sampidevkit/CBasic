<?php

namespace {

	/**
	 * @link https://php.net/manual/en/class.override.php
	 * @since PHP 8 >= 8.3.0
	 */
	final class Override {

		/**
		 * Construct a new Override attribute instance
		 * <p>Constructs a new <code>Override</code> instance.</p>
		 * @return self
		 * @link https://php.net/manual/en/override.construct.php
		 * @since PHP 8 >= 8.3.0
		 */
		public function __construct() {}
	}

}
