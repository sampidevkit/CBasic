<?php



namespace {

	class stdClass {
	}

}
