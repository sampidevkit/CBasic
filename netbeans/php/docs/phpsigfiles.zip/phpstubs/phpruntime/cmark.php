<?php

namespace CommonMark\Parser {

	const Normal = null;

	const Normalize = null;

	const Smart = null;

	const ValidateUTF8 = null;

}

namespace CommonMark\Render {

	const HardBreaks = null;

	const NoBreaks = null;

	const Normal = null;

	const Safe = null;

	const SourcePos = null;

}
