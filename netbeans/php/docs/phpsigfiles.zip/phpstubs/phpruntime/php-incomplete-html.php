<?php

namespace {

	/**
	 * @link https://php.net/manual/en/class.php-incomplete-class.php
	 * @since PHP 4 >=4.0.1, PHP 5, PHP 7, PHP 8
	 */
	final class __PHP_Incomplete_Class {
	}

}
