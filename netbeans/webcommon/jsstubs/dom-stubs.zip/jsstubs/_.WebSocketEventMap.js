/**


@returns {WebSocketEventMap}
*/
WebSocketEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CloseEvent}
**/
WebSocketEventMap.prototype["close"] = new CloseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WebSocketEventMap.prototype["error"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
WebSocketEventMap.prototype["message"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WebSocketEventMap.prototype["open"] = new Event();

