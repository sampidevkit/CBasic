/**


@returns {QueuingStrategySize}
*/
QueuingStrategySize = function() {};

