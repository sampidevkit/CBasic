/**
An iterator over the members of a list of the nodes in a subtree of the DOM. The nodes will be returned in document order.

@returns {NodeIterator}
*/
NodeIterator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | Object | null)} NodeFilter | null
**/
NodeIterator.prototype.filter = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
NodeIterator.prototype.pointerBeforeReferenceNode = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Node}
**/
NodeIterator.prototype.referenceNode = new Node();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Node}
**/
NodeIterator.prototype.root = new Node();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
NodeIterator.prototype.whatToShow = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
NodeIterator.prototype.detach = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Node | null)} Node | null
**/
NodeIterator.prototype.nextNode = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Node | null)} Node | null
**/
NodeIterator.prototype.previousNode = function() {};

