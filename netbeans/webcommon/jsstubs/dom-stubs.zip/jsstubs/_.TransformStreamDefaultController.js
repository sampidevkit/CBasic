/**


@returns {TransformStreamDefaultController}
*/
TransformStreamDefaultController = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
TransformStreamDefaultController.prototype.desiredSize = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} [chunk] O
@returns {undefined}
**/
TransformStreamDefaultController.prototype.enqueue = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} [reason]
@returns {undefined}
**/
TransformStreamDefaultController.prototype.error = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
TransformStreamDefaultController.prototype.terminate = function() {};

