/**
Available only in secure contexts.

@returns {GeolocationPosition}
*/
GeolocationPosition = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {GeolocationCoordinates}
**/
GeolocationPosition.prototype.coords = new GeolocationCoordinates();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} EpochTimeStamp
**/
GeolocationPosition.prototype.timestamp = new Number();

