/**
This WebRTC API interface manages the reception and decoding of data for a MediaStreamTrack on an RTCPeerConnection.

@returns {RTCRtpReceiver}
*/
RTCRtpReceiver = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaStreamTrack}
**/
RTCRtpReceiver.prototype.track = new MediaStreamTrack();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(RTCDtlsTransport | null)} RTCDtlsTransport | null
**/
RTCRtpReceiver.prototype.transport = new RTCDtlsTransport();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpContributingSource[]}
**/
RTCRtpReceiver.prototype.getContributingSources = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpReceiveParameters}
**/
RTCRtpReceiver.prototype.getParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Promise}
**/
RTCRtpReceiver.prototype.getStats = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpSynchronizationSource[]}
**/
RTCRtpReceiver.prototype.getSynchronizationSources = function() {};

