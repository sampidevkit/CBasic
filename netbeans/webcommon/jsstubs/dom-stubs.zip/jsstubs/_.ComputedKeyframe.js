/**


@returns {ComputedKeyframe}
*/
ComputedKeyframe = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("accumulate" | "add" | "auto" | "replace")} CompositeOperationOrAuto
**/
ComputedKeyframe.prototype.composite = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
ComputedKeyframe.prototype.computedOffset = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
ComputedKeyframe.prototype.easing = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
ComputedKeyframe.prototype.offset = new Number();

