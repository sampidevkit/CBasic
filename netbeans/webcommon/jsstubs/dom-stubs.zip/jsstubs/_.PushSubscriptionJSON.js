/**


@returns {PushSubscriptionJSON}
*/
PushSubscriptionJSON = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
PushSubscriptionJSON.prototype.endpoint = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} EpochTimeStamp | null
**/
PushSubscriptionJSON.prototype.expirationTime = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object.<String,String>} Record
**/
PushSubscriptionJSON.prototype.keys = {};

