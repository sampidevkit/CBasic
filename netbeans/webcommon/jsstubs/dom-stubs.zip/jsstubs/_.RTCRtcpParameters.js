/**


@returns {RTCRtcpParameters}
*/
RTCRtcpParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCRtcpParameters.prototype.cname = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
RTCRtcpParameters.prototype.reducedSize = new Boolean();

