/**


@returns {WEBGL_multi_draw}
*/
WEBGL_multi_draw = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} mode GLenum
@param {(Int32Array | Iterable)} firstsList Int32Array | Iterable<GLint>
@param {Number} firstsOffset GLuint
@param {(Int32Array | Iterable)} countsList Int32Array | Iterable<GLsizei>
@param {Number} countsOffset GLuint
@param {(Int32Array | Iterable)} instanceCountsList Int32Array | Iterable<GLsizei>
@param {Number} instanceCountsOffset GLuint
@param {Number} drawcount GLsizei
@returns {undefined}
**/
WEBGL_multi_draw.prototype.multiDrawArraysInstancedWEBGL = function(mode, firstsList, firstsOffset, countsList, countsOffset, instanceCountsList, instanceCountsOffset, drawcount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} mode GLenum
@param {(Int32Array | Iterable)} firstsList Int32Array | Iterable<GLint>
@param {Number} firstsOffset GLuint
@param {(Int32Array | Iterable)} countsList Int32Array | Iterable<GLsizei>
@param {Number} countsOffset GLuint
@param {Number} drawcount GLsizei
@returns {undefined}
**/
WEBGL_multi_draw.prototype.multiDrawArraysWEBGL = function(mode, firstsList, firstsOffset, countsList, countsOffset, drawcount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} mode GLenum
@param {(Int32Array | Iterable)} countsList Int32Array | Iterable<GLint>
@param {Number} countsOffset GLuint
@param {Number} type GLenum
@param {(Int32Array | Iterable)} offsetsList Int32Array | Iterable<GLsizei>
@param {Number} offsetsOffset GLuint
@param {(Int32Array | Iterable)} instanceCountsList Int32Array | Iterable<GLsizei>
@param {Number} instanceCountsOffset GLuint
@param {Number} drawcount GLsizei
@returns {undefined}
**/
WEBGL_multi_draw.prototype.multiDrawElementsInstancedWEBGL = function(mode, countsList, countsOffset, type, offsetsList, offsetsOffset, instanceCountsList, instanceCountsOffset, drawcount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} mode GLenum
@param {(Int32Array | Iterable)} countsList Int32Array | Iterable<GLint>
@param {Number} countsOffset GLuint
@param {Number} type GLenum
@param {(Int32Array | Iterable)} offsetsList Int32Array | Iterable<GLsizei>
@param {Number} offsetsOffset GLuint
@param {Number} drawcount GLsizei
@returns {undefined}
**/
WEBGL_multi_draw.prototype.multiDrawElementsWEBGL = function(mode, countsList, countsOffset, type, offsetsList, offsetsOffset, drawcount) {};

