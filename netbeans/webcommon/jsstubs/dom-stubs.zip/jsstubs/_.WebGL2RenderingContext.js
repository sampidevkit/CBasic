/**


@returns {WebGL2RenderingContext}
*/
WebGL2RenderingContext = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {WebGLQuery} query WebGLQuery
@returns {undefined}
**/
WebGL2RenderingContext.prototype.beginQuery = function(target, query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} primitiveMode GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.beginTransformFeedback = function(primitiveMode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} index GLuint
@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindBufferBase = function(target, index, buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} index GLuint
@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@param {Number} offset GLintptr
@param {Number} size GLsizeiptr
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindBufferRange = function(target, index, buffer, offset, size) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} unit GLuint
@param {(WebGLSampler | null)} sampler WebGLSampler | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindSampler = function(unit, sampler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {(WebGLTransformFeedback | null)} tf WebGLTransformFeedback | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindTransformFeedback = function(target, tf) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObject | null)} array WebGLVertexArrayObject | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindVertexArray = function(array) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} srcX0 GLint
@param {Number} srcY0 GLint
@param {Number} srcX1 GLint
@param {Number} srcY1 GLint
@param {Number} dstX0 GLint
@param {Number} dstY0 GLint
@param {Number} dstX1 GLint
@param {Number} dstY1 GLint
@param {Number} mask GLbitfield
@param {Number} filter GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.blitFramebuffer = function(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Number} depth GLfloat
@param {Number} stencil GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearBufferfi = function(buffer, drawbuffer, depth, stencil) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Iterable} values Iterable
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearBufferfv = function(buffer, drawbuffer, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Iterable} values Iterable
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearBufferiv = function(buffer, drawbuffer, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Iterable} values Iterable
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearBufferuiv = function(buffer, drawbuffer, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSync} sync WebGLSync
@param {Number} flags GLbitfield
@param {Number} timeout GLuint64
@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.clientWaitSync = function(sync, flags, timeout) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} border GLint
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} [srcOffset] GLuint
@param {Number} [srcLengthOverride] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.compressedTexImage3D = function(target, level, internalformat, width, height, depth, border, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} zoffset GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} format GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} [srcOffset] GLuint
@param {Number} [srcLengthOverride] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.compressedTexSubImage3D = function(target, level, xoffset, yoffset, zoffset, width, height, depth, format, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} readTarget GLenum
@param {Number} writeTarget GLenum
@param {Number} readOffset GLintptr
@param {Number} writeOffset GLintptr
@param {Number} size GLsizeiptr
@returns {undefined}
**/
WebGL2RenderingContext.prototype.copyBufferSubData = function(readTarget, writeTarget, readOffset, writeOffset, size) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} zoffset GLint
@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.copyTexSubImage3D = function(target, level, xoffset, yoffset, zoffset, x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLQuery | null)} WebGLQuery | null
**/
WebGL2RenderingContext.prototype.createQuery = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLSampler | null)} WebGLSampler | null
**/
WebGL2RenderingContext.prototype.createSampler = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLTransformFeedback | null)} WebGLTransformFeedback | null
**/
WebGL2RenderingContext.prototype.createTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLVertexArrayObject | null)} WebGLVertexArrayObject | null
**/
WebGL2RenderingContext.prototype.createVertexArray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLQuery | null)} query WebGLQuery | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteQuery = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSampler | null)} sampler WebGLSampler | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteSampler = function(sampler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSync | null)} sync WebGLSync | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteSync = function(sync) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLTransformFeedback | null)} tf WebGLTransformFeedback | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteTransformFeedback = function(tf) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObject | null)} vertexArray WebGLVertexArrayObject | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteVertexArray = function(vertexArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} first GLint
@param {Number} count GLsizei
@param {Number} instanceCount GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.drawArraysInstanced = function(mode, first, count, instanceCount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Iterable} buffers Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.drawBuffers = function(buffers) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} count GLsizei
@param {Number} type GLenum
@param {Number} offset GLintptr
@param {Number} instanceCount GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.drawElementsInstanced = function(mode, count, type, offset, instanceCount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} start GLuint
@param {Number} end GLuint
@param {Number} count GLsizei
@param {Number} type GLenum
@param {Number} offset GLintptr
@returns {undefined}
**/
WebGL2RenderingContext.prototype.drawRangeElements = function(mode, start, end, count, type, offset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.endQuery = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContext.prototype.endTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} condition GLenum
@param {Number} flags GLbitfield
@returns {(WebGLSync | null)} WebGLSync | null
**/
WebGL2RenderingContext.prototype.fenceSync = function(condition, flags) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} attachment GLenum
@param {(WebGLTexture | null)} texture WebGLTexture | null
@param {Number} level GLint
@param {Number} layer GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.framebufferTextureLayer = function(target, attachment, texture, level, layer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} uniformBlockIndex GLuint
@returns {(String | null)} string | null
**/
WebGL2RenderingContext.prototype.getActiveUniformBlockName = function(program, uniformBlockIndex) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} uniformBlockIndex GLuint
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getActiveUniformBlockParameter = function(program, uniformBlockIndex, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Iterable} uniformIndices Iterable
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getActiveUniforms = function(program, uniformIndices, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} srcByteOffset GLintptr
@param {ArrayBufferView} dstBuffer ArrayBufferView
@param {Number} [dstOffset] GLuint
@param {Number} [length] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.getBufferSubData = function(target, srcByteOffset, dstBuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {String} name
@returns {Number} GLint
**/
WebGL2RenderingContext.prototype.getFragDataLocation = function(program, name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} index GLuint
@returns {Object}
**/
WebGL2RenderingContext.prototype.getIndexedParameter = function(target, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} internalformat GLenum
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getInternalformatParameter = function(target, internalformat, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@returns {(WebGLQuery | null)} WebGLQuery | null
**/
WebGL2RenderingContext.prototype.getQuery = function(target, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLQuery} query WebGLQuery
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getQueryParameter = function(query, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSampler} sampler WebGLSampler
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getSamplerParameter = function(sampler, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSync} sync WebGLSync
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getSyncParameter = function(sync, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} index GLuint
@returns {(WebGLActiveInfo | null)} WebGLActiveInfo | null
**/
WebGL2RenderingContext.prototype.getTransformFeedbackVarying = function(program, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {String} uniformBlockName
@returns {Number} GLuint
**/
WebGL2RenderingContext.prototype.getUniformBlockIndex = function(program, uniformBlockName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Iterable} uniformNames Iterable
@returns {(Iterable | null)} Iterable<GLuint> | null
**/
WebGL2RenderingContext.prototype.getUniformIndices = function(program, uniformNames) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} target GLenum
@param {Iterable} attachments Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.invalidateFramebuffer = function(target, attachments) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} target GLenum
@param {Iterable} attachments Iterable
@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.invalidateSubFramebuffer = function(target, attachments, x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLQuery | null)} query WebGLQuery | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isQuery = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSampler | null)} sampler WebGLSampler | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isSampler = function(sampler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSync | null)} sync WebGLSync | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isSync = function(sync) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLTransformFeedback | null)} tf WebGLTransformFeedback | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isTransformFeedback = function(tf) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObject | null)} vertexArray WebGLVertexArrayObject | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isVertexArray = function(vertexArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContext.prototype.pauseTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} src GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.readBuffer = function(src) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} samples GLsizei
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.renderbufferStorageMultisample = function(target, samples, internalformat, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContext.prototype.resumeTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSampler} sampler WebGLSampler
@param {Number} pname GLenum
@param {Number} param GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.samplerParameterf = function(sampler, pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSampler} sampler WebGLSampler
@param {Number} pname GLenum
@param {Number} param GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.samplerParameteri = function(sampler, pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} border GLint
@param {Number} format GLenum
@param {Number} type GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} srcOffset GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texImage3D = function(target, level, internalformat, width, height, depth, border, format, type, srcData, srcOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} levels GLsizei
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texStorage2D = function(target, levels, internalformat, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} levels GLsizei
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texStorage3D = function(target, levels, internalformat, width, height, depth) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} zoffset GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} format GLenum
@param {Number} type GLenum
@param {(ArrayBufferView | null)} srcData ArrayBufferView | null
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texSubImage3D = function(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Iterable} varyings Iterable
@param {Number} bufferMode GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.transformFeedbackVaryings = function(program, varyings, bufferMode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform1ui = function(location, v0) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform1uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@param {Number} v1 GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform2ui = function(location, v0, v1) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform2uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@param {Number} v1 GLuint
@param {Number} v2 GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform3ui = function(location, v0, v1, v2) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform3uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@param {Number} v1 GLuint
@param {Number} v2 GLuint
@param {Number} v3 GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform4ui = function(location, v0, v1, v2, v3) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform4uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} uniformBlockIndex GLuint
@param {Number} uniformBlockBinding GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformBlockBinding = function(program, uniformBlockIndex, uniformBlockBinding) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix2x3fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix2x4fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix3x2fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix3x4fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix4x2fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix4x3fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} divisor GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribDivisor = function(index, divisor) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLint
@param {Number} y GLint
@param {Number} z GLint
@param {Number} w GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribI4i = function(index, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribI4iv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLuint
@param {Number} y GLuint
@param {Number} z GLuint
@param {Number} w GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribI4ui = function(index, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribI4uiv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} size GLint
@param {Number} type GLenum
@param {Number} stride GLsizei
@param {Number} offset GLintptr
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribIPointer = function(index, size, type, stride, offset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSync} sync WebGLSync
@param {Number} flags GLbitfield
@param {Number} timeout GLint64
@returns {undefined}
**/
WebGL2RenderingContext.prototype.waitSync = function(sync, flags, timeout) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ACTIVE_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ALREADY_SIGNALED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ANY_SAMPLES_PASSED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ANY_SAMPLES_PASSED_CONSERVATIVE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT10 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT11 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT12 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT13 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT14 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT15 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT6 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT7 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT9 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COMPARE_REF_TO_TEXTURE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CONDITION_SATISFIED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COPY_READ_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COPY_READ_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COPY_WRITE_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COPY_WRITE_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CURRENT_QUERY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH24_STENCIL8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH32F_STENCIL8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_COMPONENT24 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_COMPONENT32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER0 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER10 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER11 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER12 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER13 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER14 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER15 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER6 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER7 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_BUFFER9 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_FRAMEBUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DRAW_FRAMEBUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DYNAMIC_COPY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DYNAMIC_READ = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_32_UNSIGNED_INT_24_8_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT2x3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT2x4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT3x2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT3x4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT4x2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT4x3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAGMENT_SHADER_DERIVATIVE_HINT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_BLUE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_GREEN_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_RED_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_DEFAULT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_INCOMPLETE_MULTISAMPLE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.HALF_FLOAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INTERLEAVED_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_2_10_10_10_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_SAMPLER_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_SAMPLER_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_SAMPLER_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_SAMPLER_CUBE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INVALID_INDEX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_3D_TEXTURE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_ARRAY_TEXTURE_LAYERS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_CLIENT_WAIT_TIMEOUT_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_COLOR_ATTACHMENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_COMBINED_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_DRAW_BUFFERS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_ELEMENTS_INDICES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_ELEMENTS_VERTICES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_ELEMENT_INDEX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_FRAGMENT_INPUT_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_FRAGMENT_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_FRAGMENT_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_PROGRAM_TEXEL_OFFSET = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_SAMPLES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_SERVER_WAIT_TIMEOUT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_TEXTURE_LOD_BIAS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_UNIFORM_BLOCK_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_UNIFORM_BUFFER_BINDINGS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VARYING_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VERTEX_OUTPUT_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VERTEX_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VERTEX_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MIN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MIN_PROGRAM_TEXEL_OFFSET = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.OBJECT_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PACK_ROW_LENGTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PACK_SKIP_PIXELS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PACK_SKIP_ROWS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PIXEL_PACK_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PIXEL_PACK_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PIXEL_UNPACK_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PIXEL_UNPACK_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.QUERY_RESULT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.QUERY_RESULT_AVAILABLE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R11F_G11F_B10F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.R8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RASTERIZER_DISCARD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.READ_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.READ_FRAMEBUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.READ_FRAMEBUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RED_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_SAMPLES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB10_A2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB10_A2UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB9_E5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RG_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_2D_ARRAY_SHADOW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_2D_SHADOW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_CUBE_SHADOW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SEPARATE_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SIGNALED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SIGNED_NORMALIZED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SRGB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SRGB8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SRGB8_ALPHA8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STATIC_COPY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STATIC_READ = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STREAM_COPY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STREAM_READ = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SYNC_CONDITION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SYNC_FENCE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SYNC_FLAGS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SYNC_FLUSH_COMMANDS_BIT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SYNC_GPU_COMMANDS_COMPLETE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SYNC_STATUS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_BASE_LEVEL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_BINDING_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_BINDING_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_COMPARE_FUNC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_COMPARE_MODE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_IMMUTABLE_FORMAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_IMMUTABLE_LEVELS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_MAX_LEVEL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_MAX_LOD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_MIN_LOD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_WRAP_R = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TIMEOUT_EXPIRED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLint64
**/
WebGL2RenderingContext.prototype.TIMEOUT_IGNORED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_ACTIVE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_BUFFER_MODE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_BUFFER_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_BUFFER_START = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_PAUSED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRANSFORM_FEEDBACK_VARYINGS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_ARRAY_STRIDE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_ACTIVE_UNIFORMS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_DATA_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_INDEX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BUFFER_OFFSET_ALIGNMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BUFFER_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_BUFFER_START = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_IS_ROW_MAJOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_MATRIX_STRIDE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_OFFSET = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNIFORM_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_IMAGE_HEIGHT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_ROW_LENGTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_SKIP_IMAGES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_SKIP_PIXELS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_SKIP_ROWS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNALED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_10F_11F_11F_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_24_8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_2_10_10_10_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_5_9_9_9_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_SAMPLER_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_SAMPLER_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_SAMPLER_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_SAMPLER_CUBE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_VEC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_VEC3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT_VEC4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_NORMALIZED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ARRAY_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_DIVISOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.WAIT_FAILED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} usage GLenum
@param {Number} srcOffset GLuint
@param {Number} [length] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bufferData = function(target, srcData, usage, srcOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} dstByteOffset GLintptr
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} srcOffset GLuint
@param {Number} [length] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bufferSubData = function(target, dstByteOffset, srcData, srcOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} border GLint
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} [srcOffset] GLuint
@param {Number} [srcLengthOverride] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.compressedTexImage2D = function(target, level, internalformat, width, height, border, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} format GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} [srcOffset] GLuint
@param {Number} [srcLengthOverride] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.compressedTexSubImage2D = function(target, level, xoffset, yoffset, width, height, format, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} format GLenum
@param {Number} type GLenum
@param {ArrayBufferView} dstData ArrayBufferView
@param {Number} dstOffset GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.readPixels = function(x, y, width, height, format, type, dstData, dstOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} border GLint
@param {Number} format GLenum
@param {Number} type GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} srcOffset GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texImage2D = function(target, level, internalformat, width, height, border, format, type, srcData, srcOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} format GLenum
@param {Number} type GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} srcOffset GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texSubImage2D = function(target, level, xoffset, yoffset, width, height, format, type, srcData, srcOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform1fv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform1iv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform2fv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform2iv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform3fv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform3iv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform4fv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform4iv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix2fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix3fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniformMatrix4fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLCanvasElement}
**/
WebGL2RenderingContext.prototype.canvas = new HTMLCanvasElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLsizei
**/
WebGL2RenderingContext.prototype.drawingBufferHeight = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLsizei
**/
WebGL2RenderingContext.prototype.drawingBufferWidth = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} texture GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.activeTexture = function(texture) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {WebGLShader} shader WebGLShader
@returns {undefined}
**/
WebGL2RenderingContext.prototype.attachShader = function(program, shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} index GLuint
@param {String} name
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindAttribLocation = function(program, index, name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindBuffer = function(target, buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {(WebGLFramebuffer | null)} framebuffer WebGLFramebuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindFramebuffer = function(target, framebuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {(WebGLRenderbuffer | null)} renderbuffer WebGLRenderbuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindRenderbuffer = function(target, renderbuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {(WebGLTexture | null)} texture WebGLTexture | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.bindTexture = function(target, texture) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} red GLclampf
@param {Number} green GLclampf
@param {Number} blue GLclampf
@param {Number} alpha GLclampf
@returns {undefined}
**/
WebGL2RenderingContext.prototype.blendColor = function(red, green, blue, alpha) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.blendEquation = function(mode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} modeRGB GLenum
@param {Number} modeAlpha GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.blendEquationSeparate = function(modeRGB, modeAlpha) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} sfactor GLenum
@param {Number} dfactor GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.blendFunc = function(sfactor, dfactor) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} srcRGB GLenum
@param {Number} dstRGB GLenum
@param {Number} srcAlpha GLenum
@param {Number} dstAlpha GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.blendFuncSeparate = function(srcRGB, dstRGB, srcAlpha, dstAlpha) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.checkFramebufferStatus = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mask GLbitfield
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clear = function(mask) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} red GLclampf
@param {Number} green GLclampf
@param {Number} blue GLclampf
@param {Number} alpha GLclampf
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearColor = function(red, green, blue, alpha) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} depth GLclampf
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearDepth = function(depth) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} s GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.clearStencil = function(s) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Boolean} red GLboolean
@param {Boolean} green GLboolean
@param {Boolean} blue GLboolean
@param {Boolean} alpha GLboolean
@returns {undefined}
**/
WebGL2RenderingContext.prototype.colorMask = function(red, green, blue, alpha) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLShader} shader WebGLShader
@returns {undefined}
**/
WebGL2RenderingContext.prototype.compileShader = function(shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLenum
@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} border GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.copyTexImage2D = function(target, level, internalformat, x, y, width, height, border) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.copyTexSubImage2D = function(target, level, xoffset, yoffset, x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLBuffer | null)} WebGLBuffer | null
**/
WebGL2RenderingContext.prototype.createBuffer = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLFramebuffer | null)} WebGLFramebuffer | null
**/
WebGL2RenderingContext.prototype.createFramebuffer = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLProgram | null)} WebGLProgram | null
**/
WebGL2RenderingContext.prototype.createProgram = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLRenderbuffer | null)} WebGLRenderbuffer | null
**/
WebGL2RenderingContext.prototype.createRenderbuffer = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} type GLenum
@returns {(WebGLShader | null)} WebGLShader | null
**/
WebGL2RenderingContext.prototype.createShader = function(type) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLTexture | null)} WebGLTexture | null
**/
WebGL2RenderingContext.prototype.createTexture = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.cullFace = function(mode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteBuffer = function(buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLFramebuffer | null)} framebuffer WebGLFramebuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteFramebuffer = function(framebuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLProgram | null)} program WebGLProgram | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteProgram = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLRenderbuffer | null)} renderbuffer WebGLRenderbuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteRenderbuffer = function(renderbuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLShader | null)} shader WebGLShader | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteShader = function(shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLTexture | null)} texture WebGLTexture | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.deleteTexture = function(texture) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} func GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.depthFunc = function(func) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Boolean} flag GLboolean
@returns {undefined}
**/
WebGL2RenderingContext.prototype.depthMask = function(flag) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} zNear GLclampf
@param {Number} zFar GLclampf
@returns {undefined}
**/
WebGL2RenderingContext.prototype.depthRange = function(zNear, zFar) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {WebGLShader} shader WebGLShader
@returns {undefined}
**/
WebGL2RenderingContext.prototype.detachShader = function(program, shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} cap GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.disable = function(cap) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.disableVertexAttribArray = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} first GLint
@param {Number} count GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.drawArrays = function(mode, first, count) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} count GLsizei
@param {Number} type GLenum
@param {Number} offset GLintptr
@returns {undefined}
**/
WebGL2RenderingContext.prototype.drawElements = function(mode, count, type, offset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} cap GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.enable = function(cap) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.enableVertexAttribArray = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContext.prototype.finish = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContext.prototype.flush = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} attachment GLenum
@param {Number} renderbuffertarget GLenum
@param {(WebGLRenderbuffer | null)} renderbuffer WebGLRenderbuffer | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.framebufferRenderbuffer = function(target, attachment, renderbuffertarget, renderbuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} attachment GLenum
@param {Number} textarget GLenum
@param {(WebGLTexture | null)} texture WebGLTexture | null
@param {Number} level GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.framebufferTexture2D = function(target, attachment, textarget, texture, level) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.frontFace = function(mode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.generateMipmap = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} index GLuint
@returns {(WebGLActiveInfo | null)} WebGLActiveInfo | null
**/
WebGL2RenderingContext.prototype.getActiveAttrib = function(program, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} index GLuint
@returns {(WebGLActiveInfo | null)} WebGLActiveInfo | null
**/
WebGL2RenderingContext.prototype.getActiveUniform = function(program, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@returns {(WebGLShader[] | null)} WebGLShader[] | null
**/
WebGL2RenderingContext.prototype.getAttachedShaders = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {String} name
@returns {Number} GLint
**/
WebGL2RenderingContext.prototype.getAttribLocation = function(program, name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getBufferParameter = function(target, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLContextAttributes | null)} WebGLContextAttributes | null
**/
WebGL2RenderingContext.prototype.getContextAttributes = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.getError = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@returns {Object}
**/
WebGL2RenderingContext.prototype.getExtension = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} attachment GLenum
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getFramebufferAttachmentParameter = function(target, attachment, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getParameter = function(pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@returns {(String | null)} string | null
**/
WebGL2RenderingContext.prototype.getProgramInfoLog = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getProgramParameter = function(program, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getRenderbufferParameter = function(target, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLShader} shader WebGLShader
@returns {(String | null)} string | null
**/
WebGL2RenderingContext.prototype.getShaderInfoLog = function(shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLShader} shader WebGLShader
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getShaderParameter = function(shader, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} shadertype GLenum
@param {Number} precisiontype GLenum
@returns {(WebGLShaderPrecisionFormat | null)} WebGLShaderPrecisionFormat | null
**/
WebGL2RenderingContext.prototype.getShaderPrecisionFormat = function(shadertype, precisiontype) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLShader} shader WebGLShader
@returns {(String | null)} string | null
**/
WebGL2RenderingContext.prototype.getShaderSource = function(shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string[] | null
**/
WebGL2RenderingContext.prototype.getSupportedExtensions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getTexParameter = function(target, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {WebGLUniformLocation} location WebGLUniformLocation
@returns {Object}
**/
WebGL2RenderingContext.prototype.getUniform = function(program, location) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {String} name
@returns {(WebGLUniformLocation | null)} WebGLUniformLocation | null
**/
WebGL2RenderingContext.prototype.getUniformLocation = function(program, name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContext.prototype.getVertexAttrib = function(index, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} pname GLenum
@returns {Number} GLintptr
**/
WebGL2RenderingContext.prototype.getVertexAttribOffset = function(index, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} mode GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.hint = function(target, mode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isBuffer = function(buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
WebGL2RenderingContext.prototype.isContextLost = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} cap GLenum
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isEnabled = function(cap) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLFramebuffer | null)} framebuffer WebGLFramebuffer | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isFramebuffer = function(framebuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLProgram | null)} program WebGLProgram | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isProgram = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLRenderbuffer | null)} renderbuffer WebGLRenderbuffer | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isRenderbuffer = function(renderbuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLShader | null)} shader WebGLShader | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isShader = function(shader) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLTexture | null)} texture WebGLTexture | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContext.prototype.isTexture = function(texture) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} width GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.lineWidth = function(width) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@returns {undefined}
**/
WebGL2RenderingContext.prototype.linkProgram = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} pname GLenum
@param {(Number | Boolean)} param GLint | GLboolean
@returns {undefined}
**/
WebGL2RenderingContext.prototype.pixelStorei = function(pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} factor GLfloat
@param {Number} units GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.polygonOffset = function(factor, units) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.renderbufferStorage = function(target, internalformat, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} value GLclampf
@param {Boolean} invert GLboolean
@returns {undefined}
**/
WebGL2RenderingContext.prototype.sampleCoverage = function(value, invert) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.scissor = function(x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLShader} shader WebGLShader
@param {String} source
@returns {undefined}
**/
WebGL2RenderingContext.prototype.shaderSource = function(shader, source) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} func GLenum
@param {Number} ref GLint
@param {Number} mask GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.stencilFunc = function(func, ref, mask) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} face GLenum
@param {Number} func GLenum
@param {Number} ref GLint
@param {Number} mask GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.stencilFuncSeparate = function(face, func, ref, mask) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mask GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.stencilMask = function(mask) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} face GLenum
@param {Number} mask GLuint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.stencilMaskSeparate = function(face, mask) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} fail GLenum
@param {Number} zfail GLenum
@param {Number} zpass GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.stencilOp = function(fail, zfail, zpass) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} face GLenum
@param {Number} fail GLenum
@param {Number} zfail GLenum
@param {Number} zpass GLenum
@returns {undefined}
**/
WebGL2RenderingContext.prototype.stencilOpSeparate = function(face, fail, zfail, zpass) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@param {Number} param GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texParameterf = function(target, pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@param {Number} param GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.texParameteri = function(target, pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform1f = function(location, x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform1i = function(location, x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLfloat
@param {Number} y GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform2f = function(location, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLint
@param {Number} y GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform2i = function(location, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLfloat
@param {Number} y GLfloat
@param {Number} z GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform3f = function(location, x, y, z) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLint
@param {Number} y GLint
@param {Number} z GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform3i = function(location, x, y, z) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLfloat
@param {Number} y GLfloat
@param {Number} z GLfloat
@param {Number} w GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform4f = function(location, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} x GLint
@param {Number} y GLint
@param {Number} z GLint
@param {Number} w GLint
@returns {undefined}
**/
WebGL2RenderingContext.prototype.uniform4i = function(location, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLProgram | null)} program WebGLProgram | null
@returns {undefined}
**/
WebGL2RenderingContext.prototype.useProgram = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@returns {undefined}
**/
WebGL2RenderingContext.prototype.validateProgram = function(program) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib1f = function(index, x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib1fv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLfloat
@param {Number} y GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib2f = function(index, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib2fv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLfloat
@param {Number} y GLfloat
@param {Number} z GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib3f = function(index, x, y, z) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib3fv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLfloat
@param {Number} y GLfloat
@param {Number} z GLfloat
@param {Number} w GLfloat
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib4f = function(index, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttrib4fv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} size GLint
@param {Number} type GLenum
@param {Boolean} normalized GLboolean
@param {Number} stride GLsizei
@param {Number} offset GLintptr
@returns {undefined}
**/
WebGL2RenderingContext.prototype.vertexAttribPointer = function(index, size, type, normalized, stride, offset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContext.prototype.viewport = function(x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ACTIVE_ATTRIBUTES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ACTIVE_TEXTURE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ACTIVE_UNIFORMS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ALIASED_LINE_WIDTH_RANGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ALIASED_POINT_SIZE_RANGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ALPHA_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ALWAYS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ARRAY_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ARRAY_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ATTACHED_SHADERS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BACK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_DST_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_DST_RGB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_EQUATION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_EQUATION_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_EQUATION_RGB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_SRC_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLEND_SRC_RGB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BLUE_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BOOL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BOOL_VEC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BOOL_VEC3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BOOL_VEC4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BROWSER_DEFAULT_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BUFFER_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BUFFER_USAGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.BYTE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CCW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CLAMP_TO_EDGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_ATTACHMENT0 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_BUFFER_BIT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_CLEAR_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COLOR_WRITEMASK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COMPILE_STATUS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.COMPRESSED_TEXTURE_FORMATS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CONSTANT_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CONSTANT_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CONTEXT_LOST_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CULL_FACE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CULL_FACE_MODE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CURRENT_PROGRAM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CURRENT_VERTEX_ATTRIB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.CW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DECR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DECR_WRAP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DELETE_STATUS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_ATTACHMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_BUFFER_BIT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_CLEAR_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_COMPONENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_COMPONENT16 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_FUNC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_RANGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_STENCIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_STENCIL_ATTACHMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_TEST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DEPTH_WRITEMASK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DITHER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DONT_CARE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DST_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DST_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.DYNAMIC_DRAW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ELEMENT_ARRAY_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ELEMENT_ARRAY_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.EQUAL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FASTEST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_MAT4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_VEC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_VEC3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FLOAT_VEC4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAGMENT_SHADER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_OBJECT_NAME = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_OBJECT_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_TEXTURE_CUBE_MAP_FACE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_ATTACHMENT_TEXTURE_LEVEL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_COMPLETE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_INCOMPLETE_ATTACHMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_INCOMPLETE_DIMENSIONS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRAMEBUFFER_UNSUPPORTED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRONT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRONT_AND_BACK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FRONT_FACE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FUNC_ADD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FUNC_REVERSE_SUBTRACT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.FUNC_SUBTRACT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.GENERATE_MIPMAP_HINT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.GEQUAL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.GREATER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.GREEN_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.HIGH_FLOAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.HIGH_INT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.IMPLEMENTATION_COLOR_READ_FORMAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.IMPLEMENTATION_COLOR_READ_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INCR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INCR_WRAP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_VEC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_VEC3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INT_VEC4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INVALID_ENUM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INVALID_FRAMEBUFFER_OPERATION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INVALID_OPERATION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INVALID_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.INVERT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.KEEP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LEQUAL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LESS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINEAR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINEAR_MIPMAP_LINEAR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINEAR_MIPMAP_NEAREST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINE_LOOP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINE_STRIP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINE_WIDTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LINK_STATUS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LOW_FLOAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LOW_INT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LUMINANCE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.LUMINANCE_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_COMBINED_TEXTURE_IMAGE_UNITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_CUBE_MAP_TEXTURE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_FRAGMENT_UNIFORM_VECTORS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_RENDERBUFFER_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_TEXTURE_IMAGE_UNITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_TEXTURE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VARYING_VECTORS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VERTEX_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VERTEX_TEXTURE_IMAGE_UNITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VERTEX_UNIFORM_VECTORS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MAX_VIEWPORT_DIMS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MEDIUM_FLOAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MEDIUM_INT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.MIRRORED_REPEAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NEAREST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NEAREST_MIPMAP_LINEAR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NEAREST_MIPMAP_NEAREST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NEVER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NICEST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NONE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NOTEQUAL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.NO_ERROR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE_MINUS_CONSTANT_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE_MINUS_CONSTANT_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE_MINUS_DST_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE_MINUS_DST_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE_MINUS_SRC_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ONE_MINUS_SRC_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.OUT_OF_MEMORY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.PACK_ALIGNMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.POINTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.POLYGON_OFFSET_FACTOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.POLYGON_OFFSET_FILL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.POLYGON_OFFSET_UNITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RED_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_ALPHA_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_BLUE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_DEPTH_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_GREEN_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_HEIGHT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_INTERNAL_FORMAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_RED_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_STENCIL_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERBUFFER_WIDTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RENDERER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.REPEAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.REPLACE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB565 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGB5_A1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.RGBA4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLER_CUBE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLE_ALPHA_TO_COVERAGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLE_BUFFERS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLE_COVERAGE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLE_COVERAGE_INVERT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SAMPLE_COVERAGE_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SCISSOR_BOX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SCISSOR_TEST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SHADER_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SHADING_LANGUAGE_VERSION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SHORT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SRC_ALPHA = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SRC_ALPHA_SATURATE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SRC_COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STATIC_DRAW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_ATTACHMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_FAIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_FUNC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_PASS_DEPTH_FAIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_PASS_DEPTH_PASS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_REF = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_VALUE_MASK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BACK_WRITEMASK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_BUFFER_BIT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_CLEAR_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_FAIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_FUNC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_INDEX8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_PASS_DEPTH_FAIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_PASS_DEPTH_PASS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_REF = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_TEST = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_VALUE_MASK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STENCIL_WRITEMASK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.STREAM_DRAW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.SUBPIXEL_BITS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE0 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE10 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE11 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE12 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE13 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE14 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE15 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE16 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE17 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE18 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE19 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE20 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE21 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE22 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE23 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE24 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE25 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE26 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE27 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE28 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE29 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE30 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE31 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE6 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE7 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE9 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_BINDING_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_BINDING_CUBE_MAP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP_NEGATIVE_X = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP_NEGATIVE_Y = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP_NEGATIVE_Z = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP_POSITIVE_X = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP_POSITIVE_Y = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_CUBE_MAP_POSITIVE_Z = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_MAG_FILTER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_MIN_FILTER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_WRAP_S = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TEXTURE_WRAP_T = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRIANGLES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRIANGLE_FAN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.TRIANGLE_STRIP = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_ALIGNMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_COLORSPACE_CONVERSION_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_FLIP_Y_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNPACK_PREMULTIPLY_ALPHA_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_BYTE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_INT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_SHORT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_SHORT_4_4_4_4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_SHORT_5_5_5_1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.UNSIGNED_SHORT_5_6_5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VALIDATE_STATUS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VENDOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERSION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_ENABLED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_NORMALIZED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_POINTER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_STRIDE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_ATTRIB_ARRAY_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VERTEX_SHADER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.VIEWPORT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContext.prototype.ZERO = new Number();

