/**


@returns {DocumentTimeline}
*/
DocumentTimeline = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
DocumentTimeline.prototype.currentTime = new Number();

