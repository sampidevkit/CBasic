/**


@returns {HmacKeyGenParams}
*/
HmacKeyGenParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Algorithm | String)} HashAlgorithmIdentifier
**/
HmacKeyGenParams.prototype.hash = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
HmacKeyGenParams.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
HmacKeyGenParams.prototype.name = new String();

