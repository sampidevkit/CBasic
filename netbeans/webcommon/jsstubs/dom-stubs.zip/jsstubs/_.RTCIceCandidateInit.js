/**


@returns {RTCIceCandidateInit}
*/
RTCIceCandidateInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCIceCandidateInit.prototype.candidate = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
RTCIceCandidateInit.prototype.sdpMLineIndex = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidateInit.prototype.sdpMid = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidateInit.prototype.usernameFragment = new String();

