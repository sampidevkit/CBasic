/**


@returns {DecodeSuccessCallback}
*/
DecodeSuccessCallback = function() {};

