/**


@returns {ScrollIntoViewOptions}
*/
ScrollIntoViewOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("center" | "end" | "nearest" | "start")} ScrollLogicalPosition
**/
ScrollIntoViewOptions.prototype.block = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("center" | "end" | "nearest" | "start")} ScrollLogicalPosition
**/
ScrollIntoViewOptions.prototype.inline = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("auto" | "smooth")} ScrollBehavior
**/
ScrollIntoViewOptions.prototype.behavior = new Object();

