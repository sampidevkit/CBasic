/**


@returns {ResizeObserverCallback}
*/
ResizeObserverCallback = function() {};

