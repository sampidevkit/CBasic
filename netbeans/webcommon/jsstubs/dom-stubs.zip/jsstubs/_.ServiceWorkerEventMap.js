/**


@returns {ServiceWorkerEventMap}
*/
ServiceWorkerEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
ServiceWorkerEventMap.prototype["statechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ErrorEvent}
**/
ServiceWorkerEventMap.prototype["error"] = new ErrorEvent();

