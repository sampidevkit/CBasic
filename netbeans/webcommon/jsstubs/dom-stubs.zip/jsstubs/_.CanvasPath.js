/**


@returns {CanvasPath}
*/
CanvasPath = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@param {Number} radius
@param {Number} startAngle
@param {Number} endAngle
@param {Boolean} [counterclockwise]
@returns {undefined}
**/
CanvasPath.prototype.arc = function(x, y, radius, startAngle, endAngle) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x1
@param {Number} y1
@param {Number} x2
@param {Number} y2
@param {Number} radius
@returns {undefined}
**/
CanvasPath.prototype.arcTo = function(x1, y1, x2, y2, radius) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} cp1x
@param {Number} cp1y
@param {Number} cp2x
@param {Number} cp2y
@param {Number} x
@param {Number} y
@returns {undefined}
**/
CanvasPath.prototype.bezierCurveTo = function(cp1x, cp1y, cp2x, cp2y, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
CanvasPath.prototype.closePath = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@param {Number} radiusX
@param {Number} radiusY
@param {Number} rotation
@param {Number} startAngle
@param {Number} endAngle
@param {Boolean} [counterclockwise]
@returns {undefined}
**/
CanvasPath.prototype.ellipse = function(x, y, radiusX, radiusY, rotation, startAngle, endAngle) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@returns {undefined}
**/
CanvasPath.prototype.lineTo = function(x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@returns {undefined}
**/
CanvasPath.prototype.moveTo = function(x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} cpx
@param {Number} cpy
@param {Number} x
@param {Number} y
@returns {undefined}
**/
CanvasPath.prototype.quadraticCurveTo = function(cpx, cpy, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@param {Number} w
@param {Number} h
@returns {undefined}
**/
CanvasPath.prototype.rect = function(x, y, w, h) {};

