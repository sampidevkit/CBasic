/**


@returns {SpeechSynthesisUtteranceEventMap}
*/
SpeechSynthesisUtteranceEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["boundary"] = new SpeechSynthesisEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["end"] = new SpeechSynthesisEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisErrorEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["error"] = new SpeechSynthesisErrorEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["mark"] = new SpeechSynthesisEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["pause"] = new SpeechSynthesisEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["resume"] = new SpeechSynthesisEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SpeechSynthesisEvent}
**/
SpeechSynthesisUtteranceEventMap.prototype["start"] = new SpeechSynthesisEvent();

