/**


@returns {ReadableStreamDefaultReadDoneResult}
*/
ReadableStreamDefaultReadDoneResult = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {true}
**/
ReadableStreamDefaultReadDoneResult.prototype.done = true;

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
ReadableStreamDefaultReadDoneResult.prototype.value = undefined;

