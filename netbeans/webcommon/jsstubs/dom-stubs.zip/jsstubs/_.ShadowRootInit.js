/**


@returns {ShadowRootInit}
*/
ShadowRootInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
ShadowRootInit.prototype.delegatesFocus = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("closed" | "open")} ShadowRootMode
**/
ShadowRootInit.prototype.mode = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("manual" | "named")} SlotAssignmentMode
**/
ShadowRootInit.prototype.slotAssignment = new Object();

