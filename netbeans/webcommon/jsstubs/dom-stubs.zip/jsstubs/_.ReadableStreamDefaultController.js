/**


@returns {ReadableStreamDefaultController}
*/
ReadableStreamDefaultController = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
ReadableStreamDefaultController.prototype.desiredSize = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
ReadableStreamDefaultController.prototype.close = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} [chunk] R
@returns {undefined}
**/
ReadableStreamDefaultController.prototype.enqueue = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} [e]
@returns {undefined}
**/
ReadableStreamDefaultController.prototype.error = function() {};

