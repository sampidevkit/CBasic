/**


@returns {WindowEventHandlersEventMap}
*/
WindowEventHandlersEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WindowEventHandlersEventMap.prototype["afterprint"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WindowEventHandlersEventMap.prototype["beforeprint"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {BeforeUnloadEvent}
**/
WindowEventHandlersEventMap.prototype["beforeunload"] = new BeforeUnloadEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {GamepadEvent}
**/
WindowEventHandlersEventMap.prototype["gamepadconnected"] = new GamepadEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {GamepadEvent}
**/
WindowEventHandlersEventMap.prototype["gamepaddisconnected"] = new GamepadEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HashChangeEvent}
**/
WindowEventHandlersEventMap.prototype["hashchange"] = new HashChangeEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WindowEventHandlersEventMap.prototype["languagechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
WindowEventHandlersEventMap.prototype["message"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
WindowEventHandlersEventMap.prototype["messageerror"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WindowEventHandlersEventMap.prototype["offline"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WindowEventHandlersEventMap.prototype["online"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PageTransitionEvent}
**/
WindowEventHandlersEventMap.prototype["pagehide"] = new PageTransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PageTransitionEvent}
**/
WindowEventHandlersEventMap.prototype["pageshow"] = new PageTransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PopStateEvent}
**/
WindowEventHandlersEventMap.prototype["popstate"] = new PopStateEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PromiseRejectionEvent}
**/
WindowEventHandlersEventMap.prototype["rejectionhandled"] = new PromiseRejectionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {StorageEvent}
**/
WindowEventHandlersEventMap.prototype["storage"] = new StorageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PromiseRejectionEvent}
**/
WindowEventHandlersEventMap.prototype["unhandledrejection"] = new PromiseRejectionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
WindowEventHandlersEventMap.prototype["unload"] = new Event();

