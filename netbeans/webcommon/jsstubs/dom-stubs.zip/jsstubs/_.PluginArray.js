/**


@returns {PluginArray}
*/
PluginArray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
PluginArray.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {(Plugin | null)} Plugin | null
**/
PluginArray.prototype.item = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@returns {(Plugin | null)} Plugin | null
**/
PluginArray.prototype.namedItem = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
PluginArray.prototype.refresh = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
PluginArray.prototype[Symbol.iterator] = function() {};

