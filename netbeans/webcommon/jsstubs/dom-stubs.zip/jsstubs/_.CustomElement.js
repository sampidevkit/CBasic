//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@example new CustomElement(params: Object)

@param {Object} params
@returns {CustomElement}
**/
CustomElement = function(params) {};

