/**


@returns {RTCPeerConnectionEventMap}
*/
RTCPeerConnectionEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
RTCPeerConnectionEventMap.prototype["connectionstatechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCDataChannelEvent}
**/
RTCPeerConnectionEventMap.prototype["datachannel"] = new RTCDataChannelEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCPeerConnectionIceEvent}
**/
RTCPeerConnectionEventMap.prototype["icecandidate"] = new RTCPeerConnectionIceEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
RTCPeerConnectionEventMap.prototype["icecandidateerror"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
RTCPeerConnectionEventMap.prototype["iceconnectionstatechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
RTCPeerConnectionEventMap.prototype["icegatheringstatechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
RTCPeerConnectionEventMap.prototype["negotiationneeded"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
RTCPeerConnectionEventMap.prototype["signalingstatechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCTrackEvent}
**/
RTCPeerConnectionEventMap.prototype["track"] = new RTCTrackEvent();

