/**


@returns {HmacKeyAlgorithm}
*/
HmacKeyAlgorithm = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyAlgorithm}
**/
HmacKeyAlgorithm.prototype.hash = new KeyAlgorithm();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
HmacKeyAlgorithm.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
HmacKeyAlgorithm.prototype.name = new String();

