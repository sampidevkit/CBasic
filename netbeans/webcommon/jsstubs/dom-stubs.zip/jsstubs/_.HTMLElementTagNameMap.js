/**


@returns {HTMLElementTagNameMap}
*/
HTMLElementTagNameMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLAnchorElement}
**/
HTMLElementTagNameMap.prototype["a"] = new HTMLAnchorElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["abbr"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["address"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLAreaElement}
**/
HTMLElementTagNameMap.prototype["area"] = new HTMLAreaElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["article"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["aside"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLAudioElement}
**/
HTMLElementTagNameMap.prototype["audio"] = new HTMLAudioElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["b"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLBaseElement}
**/
HTMLElementTagNameMap.prototype["base"] = new HTMLBaseElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["bdi"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["bdo"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLQuoteElement}
**/
HTMLElementTagNameMap.prototype["blockquote"] = new HTMLQuoteElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLBodyElement}
**/
HTMLElementTagNameMap.prototype["body"] = new HTMLBodyElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLBRElement}
**/
HTMLElementTagNameMap.prototype["br"] = new HTMLBRElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLButtonElement}
**/
HTMLElementTagNameMap.prototype["button"] = new HTMLButtonElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLCanvasElement}
**/
HTMLElementTagNameMap.prototype["canvas"] = new HTMLCanvasElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableCaptionElement}
**/
HTMLElementTagNameMap.prototype["caption"] = new HTMLTableCaptionElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["cite"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["code"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableColElement}
**/
HTMLElementTagNameMap.prototype["col"] = new HTMLTableColElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableColElement}
**/
HTMLElementTagNameMap.prototype["colgroup"] = new HTMLTableColElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDataElement}
**/
HTMLElementTagNameMap.prototype["data"] = new HTMLDataElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDataListElement}
**/
HTMLElementTagNameMap.prototype["datalist"] = new HTMLDataListElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["dd"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLModElement}
**/
HTMLElementTagNameMap.prototype["del"] = new HTMLModElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDetailsElement}
**/
HTMLElementTagNameMap.prototype["details"] = new HTMLDetailsElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["dfn"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDialogElement}
**/
HTMLElementTagNameMap.prototype["dialog"] = new HTMLDialogElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDirectoryElement}
**/
HTMLElementTagNameMap.prototype["dir"] = new HTMLDirectoryElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDivElement}
**/
HTMLElementTagNameMap.prototype["div"] = new HTMLDivElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLDListElement}
**/
HTMLElementTagNameMap.prototype["dl"] = new HTMLDListElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["dt"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["em"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLEmbedElement}
**/
HTMLElementTagNameMap.prototype["embed"] = new HTMLEmbedElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLFieldSetElement}
**/
HTMLElementTagNameMap.prototype["fieldset"] = new HTMLFieldSetElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["figcaption"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["figure"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLFontElement}
**/
HTMLElementTagNameMap.prototype["font"] = new HTMLFontElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["footer"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLFormElement}
**/
HTMLElementTagNameMap.prototype["form"] = new HTMLFormElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLFrameElement}
**/
HTMLElementTagNameMap.prototype["frame"] = new HTMLFrameElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLFrameSetElement}
**/
HTMLElementTagNameMap.prototype["frameset"] = new HTMLFrameSetElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadingElement}
**/
HTMLElementTagNameMap.prototype["h1"] = new HTMLHeadingElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadingElement}
**/
HTMLElementTagNameMap.prototype["h2"] = new HTMLHeadingElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadingElement}
**/
HTMLElementTagNameMap.prototype["h3"] = new HTMLHeadingElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadingElement}
**/
HTMLElementTagNameMap.prototype["h4"] = new HTMLHeadingElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadingElement}
**/
HTMLElementTagNameMap.prototype["h5"] = new HTMLHeadingElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadingElement}
**/
HTMLElementTagNameMap.prototype["h6"] = new HTMLHeadingElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHeadElement}
**/
HTMLElementTagNameMap.prototype["head"] = new HTMLHeadElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["header"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["hgroup"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHRElement}
**/
HTMLElementTagNameMap.prototype["hr"] = new HTMLHRElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLHtmlElement}
**/
HTMLElementTagNameMap.prototype["html"] = new HTMLHtmlElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["i"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLIFrameElement}
**/
HTMLElementTagNameMap.prototype["iframe"] = new HTMLIFrameElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLImageElement}
**/
HTMLElementTagNameMap.prototype["img"] = new HTMLImageElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLInputElement}
**/
HTMLElementTagNameMap.prototype["input"] = new HTMLInputElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLModElement}
**/
HTMLElementTagNameMap.prototype["ins"] = new HTMLModElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["kbd"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLLabelElement}
**/
HTMLElementTagNameMap.prototype["label"] = new HTMLLabelElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLLegendElement}
**/
HTMLElementTagNameMap.prototype["legend"] = new HTMLLegendElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLLIElement}
**/
HTMLElementTagNameMap.prototype["li"] = new HTMLLIElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLLinkElement}
**/
HTMLElementTagNameMap.prototype["link"] = new HTMLLinkElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["main"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLMapElement}
**/
HTMLElementTagNameMap.prototype["map"] = new HTMLMapElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["mark"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLMarqueeElement}
**/
HTMLElementTagNameMap.prototype["marquee"] = new HTMLMarqueeElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLMenuElement}
**/
HTMLElementTagNameMap.prototype["menu"] = new HTMLMenuElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLMetaElement}
**/
HTMLElementTagNameMap.prototype["meta"] = new HTMLMetaElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLMeterElement}
**/
HTMLElementTagNameMap.prototype["meter"] = new HTMLMeterElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["nav"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["noscript"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLObjectElement}
**/
HTMLElementTagNameMap.prototype["object"] = new HTMLObjectElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLOListElement}
**/
HTMLElementTagNameMap.prototype["ol"] = new HTMLOListElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLOptGroupElement}
**/
HTMLElementTagNameMap.prototype["optgroup"] = new HTMLOptGroupElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLOptionElement}
**/
HTMLElementTagNameMap.prototype["option"] = new HTMLOptionElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLOutputElement}
**/
HTMLElementTagNameMap.prototype["output"] = new HTMLOutputElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLParagraphElement}
**/
HTMLElementTagNameMap.prototype["p"] = new HTMLParagraphElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLParamElement}
**/
HTMLElementTagNameMap.prototype["param"] = new HTMLParamElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLPictureElement}
**/
HTMLElementTagNameMap.prototype["picture"] = new HTMLPictureElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLPreElement}
**/
HTMLElementTagNameMap.prototype["pre"] = new HTMLPreElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLProgressElement}
**/
HTMLElementTagNameMap.prototype["progress"] = new HTMLProgressElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLQuoteElement}
**/
HTMLElementTagNameMap.prototype["q"] = new HTMLQuoteElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["rp"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["rt"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["ruby"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["s"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["samp"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLScriptElement}
**/
HTMLElementTagNameMap.prototype["script"] = new HTMLScriptElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["section"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLSelectElement}
**/
HTMLElementTagNameMap.prototype["select"] = new HTMLSelectElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLSlotElement}
**/
HTMLElementTagNameMap.prototype["slot"] = new HTMLSlotElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["small"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLSourceElement}
**/
HTMLElementTagNameMap.prototype["source"] = new HTMLSourceElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLSpanElement}
**/
HTMLElementTagNameMap.prototype["span"] = new HTMLSpanElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["strong"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLStyleElement}
**/
HTMLElementTagNameMap.prototype["style"] = new HTMLStyleElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["sub"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["summary"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["sup"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableElement}
**/
HTMLElementTagNameMap.prototype["table"] = new HTMLTableElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableSectionElement}
**/
HTMLElementTagNameMap.prototype["tbody"] = new HTMLTableSectionElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableCellElement}
**/
HTMLElementTagNameMap.prototype["td"] = new HTMLTableCellElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTemplateElement}
**/
HTMLElementTagNameMap.prototype["template"] = new HTMLTemplateElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTextAreaElement}
**/
HTMLElementTagNameMap.prototype["textarea"] = new HTMLTextAreaElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableSectionElement}
**/
HTMLElementTagNameMap.prototype["tfoot"] = new HTMLTableSectionElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableCellElement}
**/
HTMLElementTagNameMap.prototype["th"] = new HTMLTableCellElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableSectionElement}
**/
HTMLElementTagNameMap.prototype["thead"] = new HTMLTableSectionElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTimeElement}
**/
HTMLElementTagNameMap.prototype["time"] = new HTMLTimeElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTitleElement}
**/
HTMLElementTagNameMap.prototype["title"] = new HTMLTitleElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTableRowElement}
**/
HTMLElementTagNameMap.prototype["tr"] = new HTMLTableRowElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLTrackElement}
**/
HTMLElementTagNameMap.prototype["track"] = new HTMLTrackElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["u"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLUListElement}
**/
HTMLElementTagNameMap.prototype["ul"] = new HTMLUListElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["var"] = new HTMLElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLVideoElement}
**/
HTMLElementTagNameMap.prototype["video"] = new HTMLVideoElement();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HTMLElement}
**/
HTMLElementTagNameMap.prototype["wbr"] = new HTMLElement();

