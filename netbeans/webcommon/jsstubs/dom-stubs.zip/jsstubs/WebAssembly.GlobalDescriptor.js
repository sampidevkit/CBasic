/**


@returns {WebAssembly.GlobalDescriptor}
*/
WebAssembly.GlobalDescriptor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
WebAssembly.GlobalDescriptor.prototype.mutable = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("anyfunc" | "externref" | "f32" | "f64" | "i32" | "i64" | "v128")} ValueType
**/
WebAssembly.GlobalDescriptor.prototype.value = new Object();

