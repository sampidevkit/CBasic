/**


@returns {ServiceWorkerContainerEventMap}
*/
ServiceWorkerContainerEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
ServiceWorkerContainerEventMap.prototype["controllerchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
ServiceWorkerContainerEventMap.prototype["message"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
ServiceWorkerContainerEventMap.prototype["messageerror"] = new MessageEvent();

