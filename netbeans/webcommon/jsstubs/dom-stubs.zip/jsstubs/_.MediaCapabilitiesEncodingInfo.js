/**


@returns {MediaCapabilitiesEncodingInfo}
*/
MediaCapabilitiesEncodingInfo = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaEncodingConfiguration}
**/
MediaCapabilitiesEncodingInfo.prototype.configuration = new MediaEncodingConfiguration();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
MediaCapabilitiesEncodingInfo.prototype.powerEfficient = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
MediaCapabilitiesEncodingInfo.prototype.smooth = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
MediaCapabilitiesEncodingInfo.prototype.supported = new Boolean();

