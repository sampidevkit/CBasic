/**
This Intersection Observer API interface describes the intersection between the target element and its root container at a specific moment of transition.

@returns {IntersectionObserverEntry}
*/
IntersectionObserverEntry = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMRectReadOnly}
**/
IntersectionObserverEntry.prototype.boundingClientRect = new DOMRectReadOnly();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
IntersectionObserverEntry.prototype.intersectionRatio = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMRectReadOnly}
**/
IntersectionObserverEntry.prototype.intersectionRect = new DOMRectReadOnly();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
IntersectionObserverEntry.prototype.isIntersecting = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(DOMRectReadOnly | null)} DOMRectReadOnly | null
**/
IntersectionObserverEntry.prototype.rootBounds = new DOMRectReadOnly();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Element}
**/
IntersectionObserverEntry.prototype.target = new Element();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} DOMHighResTimeStamp
**/
IntersectionObserverEntry.prototype.time = new Number();

