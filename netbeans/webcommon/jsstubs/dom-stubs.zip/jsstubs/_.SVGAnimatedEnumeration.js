/**
Used for attributes whose value must be a constant from a particular enumeration and which can be animated.

@returns {SVGAnimatedEnumeration}
*/
SVGAnimatedEnumeration = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGAnimatedEnumeration.prototype.animVal = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGAnimatedEnumeration.prototype.baseVal = new Number();

