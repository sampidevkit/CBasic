/**


@returns {AnimationEffect}
*/
AnimationEffect = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ComputedEffectTiming}
**/
AnimationEffect.prototype.getComputedTiming = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {EffectTiming}
**/
AnimationEffect.prototype.getTiming = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {OptionalEffectTiming} [timing] OptionalEffectTiming
@returns {undefined}
**/
AnimationEffect.prototype.updateTiming = function() {};

