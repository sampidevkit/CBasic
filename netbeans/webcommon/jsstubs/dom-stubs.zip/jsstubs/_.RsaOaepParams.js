/**


@returns {RsaOaepParams}
*/
RsaOaepParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ArrayBufferView | ArrayBuffer)} BufferSource
**/
RsaOaepParams.prototype.label = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RsaOaepParams.prototype.name = new String();

