/**


@returns {IdleRequestCallback}
*/
IdleRequestCallback = function() {};

