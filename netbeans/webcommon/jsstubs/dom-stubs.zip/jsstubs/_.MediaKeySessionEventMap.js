/**


@returns {MediaKeySessionEventMap}
*/
MediaKeySessionEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
MediaKeySessionEventMap.prototype["keystatuseschange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaKeyMessageEvent}
**/
MediaKeySessionEventMap.prototype["message"] = new MediaKeyMessageEvent();

