/**


@returns {IntersectionObserverCallback}
*/
IntersectionObserverCallback = function() {};

