/**


@returns {RTCRtpParameters}
*/
RTCRtpParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpCodecParameters[]}
**/
RTCRtpParameters.prototype.codecs = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpHeaderExtensionParameters[]}
**/
RTCRtpParameters.prototype.headerExtensions = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtcpParameters}
**/
RTCRtpParameters.prototype.rtcp = new RTCRtcpParameters();

