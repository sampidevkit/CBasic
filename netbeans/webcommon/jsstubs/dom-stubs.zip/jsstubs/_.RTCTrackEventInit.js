/**


@returns {RTCTrackEventInit}
*/
RTCTrackEventInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpReceiver}
**/
RTCTrackEventInit.prototype.receiver = new RTCRtpReceiver();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaStream[]}
**/
RTCTrackEventInit.prototype.streams = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaStreamTrack}
**/
RTCTrackEventInit.prototype.track = new MediaStreamTrack();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpTransceiver}
**/
RTCTrackEventInit.prototype.transceiver = new RTCRtpTransceiver();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
RTCTrackEventInit.prototype.bubbles = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
RTCTrackEventInit.prototype.cancelable = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
RTCTrackEventInit.prototype.composed = new Boolean();

