/**
An individual button of a gamepad or other controller, allowing access to the current state of different types of buttons available on the control device.
Available only in secure contexts.

@returns {GamepadButton}
*/
GamepadButton = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
GamepadButton.prototype.pressed = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
GamepadButton.prototype.touched = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
GamepadButton.prototype.value = new Number();

