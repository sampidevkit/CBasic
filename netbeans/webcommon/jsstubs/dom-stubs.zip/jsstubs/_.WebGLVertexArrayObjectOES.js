/**


@returns {WebGLVertexArrayObjectOES}
*/
WebGLVertexArrayObjectOES = function() {};

