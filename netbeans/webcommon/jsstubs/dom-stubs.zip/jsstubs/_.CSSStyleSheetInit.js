/**


@returns {CSSStyleSheetInit}
*/
CSSStyleSheetInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
CSSStyleSheetInit.prototype.baseURL = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
CSSStyleSheetInit.prototype.disabled = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(MediaList | String)} MediaList | string
**/
CSSStyleSheetInit.prototype.media = new Object();

