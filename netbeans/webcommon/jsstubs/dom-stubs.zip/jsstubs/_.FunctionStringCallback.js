/**


@returns {FunctionStringCallback}
*/
FunctionStringCallback = function() {};

