/**
An XSLTProcessor applies an XSLT stylesheet transformation to an XML document to produce a new XML document as output. It has methods to load the XSLT stylesheet, to manipulate <xsl:param> parameter values, and to apply the transformation to documents.

@returns {XSLTProcessor}
*/
XSLTProcessor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
XSLTProcessor.prototype.clearParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(String | null)} namespaceURI string | null
@param {String} localName
@returns {Object}
**/
XSLTProcessor.prototype.getParameter = function(namespaceURI, localName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Node} style Node
@returns {undefined}
**/
XSLTProcessor.prototype.importStylesheet = function(style) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(String | null)} namespaceURI string | null
@param {String} localName
@returns {undefined}
**/
XSLTProcessor.prototype.removeParameter = function(namespaceURI, localName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
XSLTProcessor.prototype.reset = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(String | null)} namespaceURI string | null
@param {String} localName
@param {Object} value
@returns {undefined}
**/
XSLTProcessor.prototype.setParameter = function(namespaceURI, localName, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Node} source Node
@returns {Document}
**/
XSLTProcessor.prototype.transformToDocument = function(source) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Node} source Node
@param {Document} output Document
@returns {DocumentFragment}
**/
XSLTProcessor.prototype.transformToFragment = function(source, output) {};

