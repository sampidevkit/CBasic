/**


@returns {IntersectionObserverInit}
*/
IntersectionObserverInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Element | Document | null)} Element | Document | null
**/
IntersectionObserverInit.prototype.root = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
IntersectionObserverInit.prototype.rootMargin = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | Number)} number | number[]
**/
IntersectionObserverInit.prototype.threshold = new Object();

