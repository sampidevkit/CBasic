/**


@returns {ElementDefinitionOptions}
*/
ElementDefinitionOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
ElementDefinitionOptions.prototype.extends = new String();

