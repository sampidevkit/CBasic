/**


@returns {WebGLSampler}
*/
WebGLSampler = function() {};

