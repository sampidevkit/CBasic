/**


@returns {IDBOpenDBRequestEventMap}
*/
IDBOpenDBRequestEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
IDBOpenDBRequestEventMap.prototype["blocked"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {IDBVersionChangeEvent}
**/
IDBOpenDBRequestEventMap.prototype["upgradeneeded"] = new IDBVersionChangeEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
IDBOpenDBRequestEventMap.prototype["error"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
IDBOpenDBRequestEventMap.prototype["success"] = new Event();

