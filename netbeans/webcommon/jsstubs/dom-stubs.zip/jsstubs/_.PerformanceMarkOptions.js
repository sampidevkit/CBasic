/**


@returns {PerformanceMarkOptions}
*/
PerformanceMarkOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
PerformanceMarkOptions.prototype.detail = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} DOMHighResTimeStamp
**/
PerformanceMarkOptions.prototype.startTime = new Number();

