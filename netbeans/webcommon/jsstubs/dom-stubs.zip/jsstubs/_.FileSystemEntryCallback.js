/**


@returns {FileSystemEntryCallback}
*/
FileSystemEntryCallback = function() {};

