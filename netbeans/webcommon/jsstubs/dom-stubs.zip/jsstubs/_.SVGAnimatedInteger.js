/**
Used for attributes of basic type <integer> which can be animated.

@returns {SVGAnimatedInteger}
*/
SVGAnimatedInteger = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGAnimatedInteger.prototype.animVal = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGAnimatedInteger.prototype.baseVal = new Number();

