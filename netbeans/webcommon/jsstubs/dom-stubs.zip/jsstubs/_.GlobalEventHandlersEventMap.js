/**


@returns {GlobalEventHandlersEventMap}
*/
GlobalEventHandlersEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
GlobalEventHandlersEventMap.prototype["abort"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
GlobalEventHandlersEventMap.prototype["animationcancel"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
GlobalEventHandlersEventMap.prototype["animationend"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
GlobalEventHandlersEventMap.prototype["animationiteration"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
GlobalEventHandlersEventMap.prototype["animationstart"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["auxclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {InputEvent}
**/
GlobalEventHandlersEventMap.prototype["beforeinput"] = new InputEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
GlobalEventHandlersEventMap.prototype["blur"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["canplay"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["canplaythrough"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["change"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["click"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["close"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
GlobalEventHandlersEventMap.prototype["compositionend"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
GlobalEventHandlersEventMap.prototype["compositionstart"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
GlobalEventHandlersEventMap.prototype["compositionupdate"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["contextmenu"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["cuechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["dblclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["drag"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["dragend"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["dragenter"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["dragleave"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["dragover"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["dragstart"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
GlobalEventHandlersEventMap.prototype["drop"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["durationchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["emptied"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["ended"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ErrorEvent}
**/
GlobalEventHandlersEventMap.prototype["error"] = new ErrorEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
GlobalEventHandlersEventMap.prototype["focus"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
GlobalEventHandlersEventMap.prototype["focusin"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
GlobalEventHandlersEventMap.prototype["focusout"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FormDataEvent}
**/
GlobalEventHandlersEventMap.prototype["formdata"] = new FormDataEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["gotpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["input"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["invalid"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
GlobalEventHandlersEventMap.prototype["keydown"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
GlobalEventHandlersEventMap.prototype["keypress"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
GlobalEventHandlersEventMap.prototype["keyup"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["load"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["loadeddata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["loadedmetadata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["loadstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["lostpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mousedown"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mouseenter"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mouseleave"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mousemove"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mouseout"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mouseover"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
GlobalEventHandlersEventMap.prototype["mouseup"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["pause"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["play"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["playing"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointercancel"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointerdown"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointerenter"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointerleave"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointermove"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointerout"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointerover"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
GlobalEventHandlersEventMap.prototype["pointerup"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
GlobalEventHandlersEventMap.prototype["progress"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["ratechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["reset"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
GlobalEventHandlersEventMap.prototype["resize"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["scroll"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SecurityPolicyViolationEvent}
**/
GlobalEventHandlersEventMap.prototype["securitypolicyviolation"] = new SecurityPolicyViolationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["seeked"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["seeking"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["select"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["selectionchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["selectstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["slotchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["stalled"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SubmitEvent}
**/
GlobalEventHandlersEventMap.prototype["submit"] = new SubmitEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["suspend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["timeupdate"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["toggle"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
GlobalEventHandlersEventMap.prototype["touchcancel"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
GlobalEventHandlersEventMap.prototype["touchend"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
GlobalEventHandlersEventMap.prototype["touchmove"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
GlobalEventHandlersEventMap.prototype["touchstart"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
GlobalEventHandlersEventMap.prototype["transitioncancel"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
GlobalEventHandlersEventMap.prototype["transitionend"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
GlobalEventHandlersEventMap.prototype["transitionrun"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
GlobalEventHandlersEventMap.prototype["transitionstart"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["volumechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["waiting"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["webkitanimationend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["webkitanimationiteration"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["webkitanimationstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
GlobalEventHandlersEventMap.prototype["webkittransitionend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {WheelEvent}
**/
GlobalEventHandlersEventMap.prototype["wheel"] = new WheelEvent();

