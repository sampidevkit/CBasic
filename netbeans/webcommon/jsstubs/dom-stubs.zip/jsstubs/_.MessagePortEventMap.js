/**


@returns {MessagePortEventMap}
*/
MessagePortEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
MessagePortEventMap.prototype["message"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
MessagePortEventMap.prototype["messageerror"] = new MessageEvent();

