/**
An object able to programmatically obtain the position of the device. It gives Web content access to the location of the device. This allows a Web site or app to offer customized results based on the user's location.

@returns {Geolocation}
*/
Geolocation = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} watchId
@returns {undefined}
**/
Geolocation.prototype.clearWatch = function(watchId) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {PositionCallback} successCallback PositionCallback
@param {(PositionErrorCallback | null)} [errorCallback] PositionErrorCallback | null
@param {PositionOptions} [options] PositionOptions
@returns {undefined}
**/
Geolocation.prototype.getCurrentPosition = function(successCallback) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {PositionCallback} successCallback PositionCallback
@param {(PositionErrorCallback | null)} [errorCallback] PositionErrorCallback | null
@param {PositionOptions} [options] PositionOptions
@returns {Number}
**/
Geolocation.prototype.watchPosition = function(successCallback) {};

