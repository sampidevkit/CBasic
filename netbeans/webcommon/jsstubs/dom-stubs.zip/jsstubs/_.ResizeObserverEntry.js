/**


@returns {ResizeObserverEntry}
*/
ResizeObserverEntry = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ReadonlyArray}
**/
ResizeObserverEntry.prototype.borderBoxSize = new ReadonlyArray();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ReadonlyArray}
**/
ResizeObserverEntry.prototype.contentBoxSize = new ReadonlyArray();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMRectReadOnly}
**/
ResizeObserverEntry.prototype.contentRect = new DOMRectReadOnly();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ReadonlyArray}
**/
ResizeObserverEntry.prototype.devicePixelContentBoxSize = new ReadonlyArray();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Element}
**/
ResizeObserverEntry.prototype.target = new Element();

