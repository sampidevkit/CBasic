/**


@returns {GenericTransformStream}
*/
GenericTransformStream = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ReadableStream}
**/
GenericTransformStream.prototype.readable = new ReadableStream();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {WritableStream}
**/
GenericTransformStream.prototype.writable = new WritableStream();

