/**


@returns {RTCRtpCapabilities}
*/
RTCRtpCapabilities = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpCodecCapability[]}
**/
RTCRtpCapabilities.prototype.codecs = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpHeaderExtensionCapability[]}
**/
RTCRtpCapabilities.prototype.headerExtensions = new Array();

