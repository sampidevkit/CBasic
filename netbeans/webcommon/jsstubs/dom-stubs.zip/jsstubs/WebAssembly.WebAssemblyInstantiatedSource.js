/**


@returns {WebAssembly.WebAssemblyInstantiatedSource}
*/
WebAssembly.WebAssemblyInstantiatedSource = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Instance}
**/
WebAssembly.WebAssemblyInstantiatedSource.prototype.instance = new Instance();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Module}
**/
WebAssembly.WebAssemblyInstantiatedSource.prototype.module = new Module();

