/**


@returns {MediaCapabilitiesInfo}
*/
MediaCapabilitiesInfo = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
MediaCapabilitiesInfo.prototype.powerEfficient = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
MediaCapabilitiesInfo.prototype.smooth = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
MediaCapabilitiesInfo.prototype.supported = new Boolean();

