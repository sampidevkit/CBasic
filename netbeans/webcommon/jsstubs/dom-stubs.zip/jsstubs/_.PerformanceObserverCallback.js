/**


@returns {PerformanceObserverCallback}
*/
PerformanceObserverCallback = function() {};

