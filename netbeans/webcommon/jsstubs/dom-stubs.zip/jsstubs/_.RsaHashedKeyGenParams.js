/**


@returns {RsaHashedKeyGenParams}
*/
RsaHashedKeyGenParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Algorithm | String)} HashAlgorithmIdentifier
**/
RsaHashedKeyGenParams.prototype.hash = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RsaHashedKeyGenParams.prototype.modulusLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Uint8Array} BigInteger
**/
RsaHashedKeyGenParams.prototype.publicExponent = new Uint8Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RsaHashedKeyGenParams.prototype.name = new String();

