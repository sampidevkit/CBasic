/**


@returns {RTCConfiguration}
*/
RTCConfiguration = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("balanced" | "max-bundle" | "max-compat")} RTCBundlePolicy
**/
RTCConfiguration.prototype.bundlePolicy = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCCertificate[]}
**/
RTCConfiguration.prototype.certificates = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RTCConfiguration.prototype.iceCandidatePoolSize = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCIceServer[]}
**/
RTCConfiguration.prototype.iceServers = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("all" | "relay")} RTCIceTransportPolicy
**/
RTCConfiguration.prototype.iceTransportPolicy = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {"require"} RTCRtcpMuxPolicy
**/
RTCConfiguration.prototype.rtcpMuxPolicy = "require";

