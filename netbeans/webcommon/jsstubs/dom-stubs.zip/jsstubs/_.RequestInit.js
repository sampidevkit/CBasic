/**


@returns {RequestInit}
*/
RequestInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ReadableStream | Blob | ArrayBufferView | ArrayBuffer | FormData | URLSearchParams | String | null)} BodyInit | null
**/
RequestInit.prototype.body = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("default" | "force-cache" | "no-cache" | "no-store" | "only-if-cached" | "reload")} RequestCache
**/
RequestInit.prototype.cache = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("include" | "omit" | "same-origin")} RequestCredentials
**/
RequestInit.prototype.credentials = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | Object.<String,String> | Headers)} HeadersInit
**/
RequestInit.prototype.headers = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RequestInit.prototype.integrity = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
RequestInit.prototype.keepalive = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RequestInit.prototype.method = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("cors" | "navigate" | "no-cors" | "same-origin")} RequestMode
**/
RequestInit.prototype.mode = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("error" | "follow" | "manual")} RequestRedirect
**/
RequestInit.prototype.redirect = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RequestInit.prototype.referrer = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("" | "no-referrer" | "no-referrer-when-downgrade" | "origin" | "origin-when-cross-origin" | "same-origin" | "strict-origin" | "strict-origin-when-cross-origin" | "unsafe-url")} ReferrerPolicy
**/
RequestInit.prototype.referrerPolicy = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(AbortSignal | null)} AbortSignal | null
**/
RequestInit.prototype.signal = new AbortSignal();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {null}
**/
RequestInit.prototype.window = null;

