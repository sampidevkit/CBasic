/**


@returns {RsaKeyGenParams}
*/
RsaKeyGenParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RsaKeyGenParams.prototype.modulusLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Uint8Array} BigInteger
**/
RsaKeyGenParams.prototype.publicExponent = new Uint8Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RsaKeyGenParams.prototype.name = new String();

