/**


@returns {WindowEventHandlers}
*/
WindowEventHandlers = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: Event) => any) | null
**/
WindowEventHandlers.prototype.onafterprint = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: Event) => any) | null
**/
WindowEventHandlers.prototype.onbeforeprint = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: BeforeUnloadEvent) => any) | null
**/
WindowEventHandlers.prototype.onbeforeunload = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: GamepadEvent) => any) | null
**/
WindowEventHandlers.prototype.ongamepadconnected = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: GamepadEvent) => any) | null
**/
WindowEventHandlers.prototype.ongamepaddisconnected = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: HashChangeEvent) => any) | null
**/
WindowEventHandlers.prototype.onhashchange = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: Event) => any) | null
**/
WindowEventHandlers.prototype.onlanguagechange = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: MessageEvent) => any) | null
**/
WindowEventHandlers.prototype.onmessage = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: MessageEvent) => any) | null
**/
WindowEventHandlers.prototype.onmessageerror = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: Event) => any) | null
**/
WindowEventHandlers.prototype.onoffline = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: Event) => any) | null
**/
WindowEventHandlers.prototype.ononline = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: PageTransitionEvent) => any) | null
**/
WindowEventHandlers.prototype.onpagehide = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: PageTransitionEvent) => any) | null
**/
WindowEventHandlers.prototype.onpageshow = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: PopStateEvent) => any) | null
**/
WindowEventHandlers.prototype.onpopstate = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: PromiseRejectionEvent) => any) | null
**/
WindowEventHandlers.prototype.onrejectionhandled = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: StorageEvent) => any) | null
**/
WindowEventHandlers.prototype.onstorage = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: PromiseRejectionEvent) => any) | null
**/
WindowEventHandlers.prototype.onunhandledrejection = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Function | null)} ((this: WindowEventHandlers, ev: Event) => any) | null
**/
WindowEventHandlers.prototype.onunload = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} type
@param {(EventListener | EventListenerObject)} listener EventListenerOrEventListenerObject
@param {(Boolean | AddEventListenerOptions)} [options] boolean | AddEventListenerOptions
@returns {undefined}
**/
WindowEventHandlers.prototype.addEventListener = function(type, listener) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} type
@param {(EventListener | EventListenerObject)} listener EventListenerOrEventListenerObject
@param {(Boolean | EventListenerOptions)} [options] boolean | EventListenerOptions
@returns {undefined}
**/
WindowEventHandlers.prototype.removeEventListener = function(type, listener) {};

