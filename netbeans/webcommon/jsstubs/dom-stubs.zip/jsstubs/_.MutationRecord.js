/**
A MutationRecord represents an individual DOM mutation. It is the object that is passed to MutationObserver's callback.

@returns {MutationRecord}
*/
MutationRecord = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {NodeList}
**/
MutationRecord.prototype.addedNodes = new NodeList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
MutationRecord.prototype.attributeName = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
MutationRecord.prototype.attributeNamespace = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Node | null)} Node | null
**/
MutationRecord.prototype.nextSibling = new Node();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
MutationRecord.prototype.oldValue = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Node | null)} Node | null
**/
MutationRecord.prototype.previousSibling = new Node();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {NodeList}
**/
MutationRecord.prototype.removedNodes = new NodeList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Node}
**/
MutationRecord.prototype.target = new Node();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("attributes" | "characterData" | "childList")} MutationRecordType
**/
MutationRecord.prototype.type = new Object();

