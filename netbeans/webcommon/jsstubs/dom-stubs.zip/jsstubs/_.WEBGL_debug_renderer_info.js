/**
The WEBGL_debug_renderer_info extension is part of the WebGL API and exposes two constants with information about the graphics driver for debugging purposes.

@returns {WEBGL_debug_renderer_info}
*/
WEBGL_debug_renderer_info = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_debug_renderer_info.prototype.UNMASKED_RENDERER_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_debug_renderer_info.prototype.UNMASKED_VENDOR_WEBGL = new Number();

