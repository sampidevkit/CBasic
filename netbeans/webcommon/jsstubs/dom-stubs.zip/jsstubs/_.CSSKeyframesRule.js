/**
An object representing a complete set of keyframes for a CSS animation. It corresponds to the contains of a whole @keyframes at-rule. It implements the CSSRule interface with a type value of 7 (CSSRule.KEYFRAMES_RULE).

@returns {CSSKeyframesRule}
*/
CSSKeyframesRule = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CSSRuleList}
**/
CSSKeyframesRule.prototype.cssRules = new CSSRuleList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
CSSKeyframesRule.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} rule
@returns {undefined}
**/
CSSKeyframesRule.prototype.appendRule = function(rule) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} select
@returns {undefined}
**/
CSSKeyframesRule.prototype.deleteRule = function(select) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} select
@returns {(CSSKeyframeRule | null)} CSSKeyframeRule | null
**/
CSSKeyframesRule.prototype.findRule = function(select) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
CSSKeyframesRule.prototype.cssText = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(CSSRule | null)} CSSRule | null
**/
CSSKeyframesRule.prototype.parentRule = new CSSRule();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(CSSStyleSheet | null)} CSSStyleSheet | null
**/
CSSKeyframesRule.prototype.parentStyleSheet = new CSSStyleSheet();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.type = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.CHARSET_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.FONT_FACE_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.IMPORT_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.KEYFRAMES_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.KEYFRAME_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.MEDIA_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.NAMESPACE_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.PAGE_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.STYLE_RULE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CSSKeyframesRule.prototype.SUPPORTS_RULE = new Number();

