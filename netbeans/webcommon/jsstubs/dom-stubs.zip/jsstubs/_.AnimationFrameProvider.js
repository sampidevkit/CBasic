/**


@returns {AnimationFrameProvider}
*/
AnimationFrameProvider = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} handle
@returns {undefined}
**/
AnimationFrameProvider.prototype.cancelAnimationFrame = function(handle) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {FrameRequestCallback} callback FrameRequestCallback
@returns {Number}
**/
AnimationFrameProvider.prototype.requestAnimationFrame = function(callback) {};

