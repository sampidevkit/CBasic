/**


@returns {ReadableStreamGenericReader}
*/
ReadableStreamGenericReader = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Promise}
**/
ReadableStreamGenericReader.prototype.closed = new Promise();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} [reason]
@returns {Promise}
**/
ReadableStreamGenericReader.prototype.cancel = function() {};

