/**
Used for attributes which take a list of numbers and which can be animated.

@returns {SVGAnimatedTransformList}
*/
SVGAnimatedTransformList = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGTransformList}
**/
SVGAnimatedTransformList.prototype.animVal = new SVGTransformList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGTransformList}
**/
SVGAnimatedTransformList.prototype.baseVal = new SVGTransformList();

