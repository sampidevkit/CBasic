/**


@returns {WEBGL_debug_shaders}
*/
WEBGL_debug_shaders = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLShader} shader WebGLShader
@returns {String}
**/
WEBGL_debug_shaders.prototype.getTranslatedShaderSource = function(shader) {};

