/**
A commonly used set of constants used for reflecting gradientUnits, patternContentUnits and other similar attributes.

@returns {SVGUnitTypes}
*/
SVGUnitTypes = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGUnitTypes.prototype.SVG_UNIT_TYPE_OBJECTBOUNDINGBOX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGUnitTypes.prototype.SVG_UNIT_TYPE_UNKNOWN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGUnitTypes.prototype.SVG_UNIT_TYPE_USERSPACEONUSE = new Number();

