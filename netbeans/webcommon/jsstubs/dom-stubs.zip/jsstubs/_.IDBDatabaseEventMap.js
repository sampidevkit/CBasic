/**


@returns {IDBDatabaseEventMap}
*/
IDBDatabaseEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
IDBDatabaseEventMap.prototype["abort"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
IDBDatabaseEventMap.prototype["close"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
IDBDatabaseEventMap.prototype["error"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {IDBVersionChangeEvent}
**/
IDBDatabaseEventMap.prototype["versionchange"] = new IDBVersionChangeEvent();

