/**


@returns {IDBObjectStore}
*/
IDBObjectStore = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
IDBObjectStore.prototype.autoIncrement = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMStringList}
**/
IDBObjectStore.prototype.indexNames = new DOMStringList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | String)} string | string[]
**/
IDBObjectStore.prototype.keyPath = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
IDBObjectStore.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {IDBTransaction}
**/
IDBObjectStore.prototype.transaction = new IDBTransaction();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Adds or updates a record in store with the given value and key.

If the store uses in-line keys and key is specified a "DataError" DOMException will be thrown.

If put() is used, any existing record with the key will be replaced. If add() is used, and if a record with the key already exists the request will fail, with request's error set to a "ConstraintError" DOMException.

If successful, request's result will be the record's key.

@param {Object} value
@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[])} [key] IDBValidKey
@returns {IDBRequest}
**/
IDBObjectStore.prototype.add = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Deletes all records in store.

If successful, request's result will be undefined.

@returns {IDBRequest}
**/
IDBObjectStore.prototype.clear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Retrieves the number of records matching the given key or key range in query.

If successful, request's result will be the count.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange)} [query] IDBValidKey | IDBKeyRange
@returns {IDBRequest}
**/
IDBObjectStore.prototype.count = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Creates a new index in store with the given name, keyPath and options and returns a new IDBIndex. If the keyPath and options define constraints that cannot be satisfied with the data already in store the upgrade transaction will abort with a "ConstraintError" DOMException.

Throws an "InvalidStateError" DOMException if not called within an upgrade transaction.

@param {String} name
@param {(String | Iterable)} keyPath string | Iterable<string>
@param {IDBIndexParameters} [options] IDBIndexParameters
@returns {IDBIndex}
**/
IDBObjectStore.prototype.createIndex = function(name, keyPath) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Deletes records in store with the given key or in the given key range in query.

If successful, request's result will be undefined.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange)} query IDBValidKey | IDBKeyRange
@returns {IDBRequest}
**/
IDBObjectStore.prototype.delete = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Deletes the index in store with the given name.

Throws an "InvalidStateError" DOMException if not called within an upgrade transaction.

@param {String} name
@returns {undefined}
**/
IDBObjectStore.prototype.deleteIndex = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Retrieves the value of the first record matching the given key or key range in query.

If successful, request's result will be the value, or undefined if there was no matching record.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange)} query IDBValidKey | IDBKeyRange
@returns {IDBRequest}
**/
IDBObjectStore.prototype.get = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Retrieves the values of the records matching the given key or key range in query (up to count if given).

If successful, request's result will be an Array of the values.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange | null)} [query] IDBValidKey | IDBKeyRange | null
@param {Number} [count]
@returns {IDBRequest}
**/
IDBObjectStore.prototype.getAll = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Retrieves the keys of records matching the given key or key range in query (up to count if given).

If successful, request's result will be an Array of the keys.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange | null)} [query] IDBValidKey | IDBKeyRange | null
@param {Number} [count]
@returns {IDBRequest}
**/
IDBObjectStore.prototype.getAllKeys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Retrieves the key of the first record matching the given key or key range in query.

If successful, request's result will be the key, or undefined if there was no matching record.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange)} query IDBValidKey | IDBKeyRange
@returns {IDBRequest}
**/
IDBObjectStore.prototype.getKey = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@returns {IDBIndex}
**/
IDBObjectStore.prototype.index = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Opens a cursor over the records matching query, ordered by direction. If query is null, all records in store are matched.

If successful, request's result will be an IDBCursorWithValue pointing at the first matching record, or null if there were no matching records.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange | null)} [query] IDBValidKey | IDBKeyRange | null
@param {("next" | "nextunique" | "prev" | "prevunique")} [direction] IDBCursorDirection
@returns {IDBRequest}
**/
IDBObjectStore.prototype.openCursor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Opens a cursor with key only flag set over the records matching query, ordered by direction. If query is null, all records in store are matched.

If successful, request's result will be an IDBCursor pointing at the first matching record, or null if there were no matching records.

@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[] | IDBKeyRange | null)} [query] IDBValidKey | IDBKeyRange | null
@param {("next" | "nextunique" | "prev" | "prevunique")} [direction] IDBCursorDirection
@returns {IDBRequest}
**/
IDBObjectStore.prototype.openKeyCursor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Adds or updates a record in store with the given value and key.

If the store uses in-line keys and key is specified a "DataError" DOMException will be thrown.

If put() is used, any existing record with the key will be replaced. If add() is used, and if a record with the key already exists the request will fail, with request's error set to a "ConstraintError" DOMException.

If successful, request's result will be the record's key.

@param {Object} value
@param {(Number | String | Date | ArrayBufferView | ArrayBuffer | IDBValidKey[])} [key] IDBValidKey
@returns {IDBRequest}
**/
IDBObjectStore.prototype.put = function(value) {};

