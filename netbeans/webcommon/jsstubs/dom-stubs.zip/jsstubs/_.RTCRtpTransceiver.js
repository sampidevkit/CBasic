/**


@returns {RTCRtpTransceiver}
*/
RTCRtpTransceiver = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("inactive" | "recvonly" | "sendonly" | "sendrecv" | "stopped" | null)} RTCRtpTransceiverDirection | null
**/
RTCRtpTransceiver.prototype.currentDirection = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("inactive" | "recvonly" | "sendonly" | "sendrecv" | "stopped")} RTCRtpTransceiverDirection
**/
RTCRtpTransceiver.prototype.direction = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCRtpTransceiver.prototype.mid = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpReceiver}
**/
RTCRtpTransceiver.prototype.receiver = new RTCRtpReceiver();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpSender}
**/
RTCRtpTransceiver.prototype.sender = new RTCRtpSender();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Iterable} codecs Iterable
@returns {undefined}
**/
RTCRtpTransceiver.prototype.setCodecPreferences = function(codecs) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
RTCRtpTransceiver.prototype.stop = function() {};

