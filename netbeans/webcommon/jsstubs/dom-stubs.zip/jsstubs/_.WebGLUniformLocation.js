/**
Part of the WebGL API and represents the location of a uniform variable in a shader program.

@returns {WebGLUniformLocation}
*/
WebGLUniformLocation = function() {};

