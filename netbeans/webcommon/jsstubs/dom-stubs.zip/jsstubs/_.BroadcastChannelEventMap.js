/**


@returns {BroadcastChannelEventMap}
*/
BroadcastChannelEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
BroadcastChannelEventMap.prototype["message"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
BroadcastChannelEventMap.prototype["messageerror"] = new MessageEvent();

