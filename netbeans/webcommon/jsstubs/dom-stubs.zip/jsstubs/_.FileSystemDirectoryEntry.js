/**


@returns {FileSystemDirectoryEntry}
*/
FileSystemDirectoryEntry = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FileSystemDirectoryReader}
**/
FileSystemDirectoryEntry.prototype.createReader = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(String | null)} [path] string | null
@param {FileSystemFlags} [options] FileSystemFlags
@param {FileSystemEntryCallback} [successCallback] FileSystemEntryCallback
@param {ErrorCallback} [errorCallback] ErrorCallback
@returns {undefined}
**/
FileSystemDirectoryEntry.prototype.getDirectory = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(String | null)} [path] string | null
@param {FileSystemFlags} [options] FileSystemFlags
@param {FileSystemEntryCallback} [successCallback] FileSystemEntryCallback
@param {ErrorCallback} [errorCallback] ErrorCallback
@returns {undefined}
**/
FileSystemDirectoryEntry.prototype.getFile = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FileSystem}
**/
FileSystemDirectoryEntry.prototype.filesystem = new FileSystem();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
FileSystemDirectoryEntry.prototype.fullPath = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
FileSystemDirectoryEntry.prototype.isDirectory = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
FileSystemDirectoryEntry.prototype.isFile = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
FileSystemDirectoryEntry.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {FileSystemEntryCallback} [successCallback] FileSystemEntryCallback
@param {ErrorCallback} [errorCallback] ErrorCallback
@returns {undefined}
**/
FileSystemDirectoryEntry.prototype.getParent = function() {};

