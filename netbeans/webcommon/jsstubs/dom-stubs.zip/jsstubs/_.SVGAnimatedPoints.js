/**


@returns {SVGAnimatedPoints}
*/
SVGAnimatedPoints = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGPointList}
**/
SVGAnimatedPoints.prototype.animatedPoints = new SVGPointList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGPointList}
**/
SVGAnimatedPoints.prototype.points = new SVGPointList();

