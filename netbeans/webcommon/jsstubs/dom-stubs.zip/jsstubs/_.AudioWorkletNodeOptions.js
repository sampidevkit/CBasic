/**


@returns {AudioWorkletNodeOptions}
*/
AudioWorkletNodeOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioWorkletNodeOptions.prototype.numberOfInputs = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioWorkletNodeOptions.prototype.numberOfOutputs = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioWorkletNodeOptions.prototype.outputChannelCount = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object.<String,Number>} Record
**/
AudioWorkletNodeOptions.prototype.parameterData = {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
AudioWorkletNodeOptions.prototype.processorOptions = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioWorkletNodeOptions.prototype.channelCount = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("clamped-max" | "explicit" | "max")} ChannelCountMode
**/
AudioWorkletNodeOptions.prototype.channelCountMode = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("discrete" | "speakers")} ChannelInterpretation
**/
AudioWorkletNodeOptions.prototype.channelInterpretation = new Object();

