/**
Part of the WebGL API and represents the information returned by calling the WebGLRenderingContext.getShaderPrecisionFormat() method.

@returns {WebGLShaderPrecisionFormat}
*/
WebGLShaderPrecisionFormat = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLint
**/
WebGLShaderPrecisionFormat.prototype.precision = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLint
**/
WebGLShaderPrecisionFormat.prototype.rangeMax = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLint
**/
WebGLShaderPrecisionFormat.prototype.rangeMin = new Number();

