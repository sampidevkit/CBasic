/**


@returns {ResizeObserverOptions}
*/
ResizeObserverOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("border-box" | "content-box" | "device-pixel-content-box")} ResizeObserverBoxOptions
**/
ResizeObserverOptions.prototype.box = new Object();

