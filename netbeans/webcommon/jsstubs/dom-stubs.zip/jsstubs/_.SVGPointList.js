/**


@returns {SVGPointList}
*/
SVGPointList = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGPointList.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGPointList.prototype.numberOfItems = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMPoint} newItem DOMPoint
@returns {DOMPoint}
**/
SVGPointList.prototype.appendItem = function(newItem) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
SVGPointList.prototype.clear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {DOMPoint}
**/
SVGPointList.prototype.getItem = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMPoint} newItem DOMPoint
@returns {DOMPoint}
**/
SVGPointList.prototype.initialize = function(newItem) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMPoint} newItem DOMPoint
@param {Number} index
@returns {DOMPoint}
**/
SVGPointList.prototype.insertItemBefore = function(newItem, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {DOMPoint}
**/
SVGPointList.prototype.removeItem = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMPoint} newItem DOMPoint
@param {Number} index
@returns {DOMPoint}
**/
SVGPointList.prototype.replaceItem = function(newItem, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
SVGPointList.prototype[Symbol.iterator] = function() {};

