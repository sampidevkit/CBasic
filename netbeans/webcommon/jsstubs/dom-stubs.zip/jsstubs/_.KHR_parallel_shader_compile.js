/**


@returns {KHR_parallel_shader_compile}
*/
KHR_parallel_shader_compile = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
KHR_parallel_shader_compile.prototype.COMPLETION_STATUS_KHR = new Number();

