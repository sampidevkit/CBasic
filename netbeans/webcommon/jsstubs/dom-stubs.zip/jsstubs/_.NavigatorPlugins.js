/**


@returns {NavigatorPlugins}
*/
NavigatorPlugins = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MimeTypeArray}
**/
NavigatorPlugins.prototype.mimeTypes = new MimeTypeArray();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PluginArray}
**/
NavigatorPlugins.prototype.plugins = new PluginArray();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
NavigatorPlugins.prototype.javaEnabled = function() {};

