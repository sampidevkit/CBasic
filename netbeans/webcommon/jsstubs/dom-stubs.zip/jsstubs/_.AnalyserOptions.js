/**


@returns {AnalyserOptions}
*/
AnalyserOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AnalyserOptions.prototype.fftSize = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AnalyserOptions.prototype.maxDecibels = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AnalyserOptions.prototype.minDecibels = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AnalyserOptions.prototype.smoothingTimeConstant = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AnalyserOptions.prototype.channelCount = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("clamped-max" | "explicit" | "max")} ChannelCountMode
**/
AnalyserOptions.prototype.channelCountMode = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("discrete" | "speakers")} ChannelInterpretation
**/
AnalyserOptions.prototype.channelInterpretation = new Object();

