/**


@returns {RsaHashedImportParams}
*/
RsaHashedImportParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Algorithm | String)} HashAlgorithmIdentifier
**/
RsaHashedImportParams.prototype.hash = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RsaHashedImportParams.prototype.name = new String();

