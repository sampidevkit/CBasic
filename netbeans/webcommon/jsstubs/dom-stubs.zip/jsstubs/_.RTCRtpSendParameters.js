/**


@returns {RTCRtpSendParameters}
*/
RTCRtpSendParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("balanced" | "maintain-framerate" | "maintain-resolution")} RTCDegradationPreference
**/
RTCRtpSendParameters.prototype.degradationPreference = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpEncodingParameters[]}
**/
RTCRtpSendParameters.prototype.encodings = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCRtpSendParameters.prototype.transactionId = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpCodecParameters[]}
**/
RTCRtpSendParameters.prototype.codecs = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtpHeaderExtensionParameters[]}
**/
RTCRtpSendParameters.prototype.headerExtensions = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCRtcpParameters}
**/
RTCRtpSendParameters.prototype.rtcp = new RTCRtcpParameters();

