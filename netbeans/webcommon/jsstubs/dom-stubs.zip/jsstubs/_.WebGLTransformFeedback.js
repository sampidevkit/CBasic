/**


@returns {WebGLTransformFeedback}
*/
WebGLTransformFeedback = function() {};

