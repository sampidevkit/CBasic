/**


@returns {LockGrantedCallback}
*/
LockGrantedCallback = function() {};

