/**


@returns {RsaKeyAlgorithm}
*/
RsaKeyAlgorithm = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RsaKeyAlgorithm.prototype.modulusLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Uint8Array} BigInteger
**/
RsaKeyAlgorithm.prototype.publicExponent = new Uint8Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RsaKeyAlgorithm.prototype.name = new String();

