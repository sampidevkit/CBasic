/**
The storage for Cache objects.
Available only in secure contexts.

@returns {CacheStorage}
*/
CacheStorage = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} cacheName
@returns {Promise}
**/
CacheStorage.prototype.delete = function(cacheName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} cacheName
@returns {Promise}
**/
CacheStorage.prototype.has = function(cacheName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Promise}
**/
CacheStorage.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(Request | String)} request RequestInfo
@param {MultiCacheQueryOptions} [options] MultiCacheQueryOptions
@returns {Promise}
**/
CacheStorage.prototype.match = function(request) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} cacheName
@returns {Promise}
**/
CacheStorage.prototype.open = function(cacheName) {};

