/**


@returns {TextTrackListEventMap}
*/
TextTrackListEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TrackEvent}
**/
TextTrackListEventMap.prototype["addtrack"] = new TrackEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
TextTrackListEventMap.prototype["change"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TrackEvent}
**/
TextTrackListEventMap.prototype["removetrack"] = new TrackEvent();

