/**


@returns {FileSystemRemoveOptions}
*/
FileSystemRemoveOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
FileSystemRemoveOptions.prototype.recursive = new Boolean();

