/**


@returns {TransformerTransformCallback}
*/
TransformerTransformCallback = function() {};

