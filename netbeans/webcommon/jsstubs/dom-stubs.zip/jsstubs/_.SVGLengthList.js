/**


@returns {SVGLengthList}
*/
SVGLengthList = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGLengthList.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
SVGLengthList.prototype.numberOfItems = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {SVGLength} newItem SVGLength
@returns {SVGLength}
**/
SVGLengthList.prototype.appendItem = function(newItem) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
SVGLengthList.prototype.clear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {SVGLength}
**/
SVGLengthList.prototype.getItem = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {SVGLength} newItem SVGLength
@returns {SVGLength}
**/
SVGLengthList.prototype.initialize = function(newItem) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {SVGLength} newItem SVGLength
@param {Number} index
@returns {SVGLength}
**/
SVGLengthList.prototype.insertItemBefore = function(newItem, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {SVGLength}
**/
SVGLengthList.prototype.removeItem = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {SVGLength} newItem SVGLength
@param {Number} index
@returns {SVGLength}
**/
SVGLengthList.prototype.replaceItem = function(newItem, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
SVGLengthList.prototype[Symbol.iterator] = function() {};

