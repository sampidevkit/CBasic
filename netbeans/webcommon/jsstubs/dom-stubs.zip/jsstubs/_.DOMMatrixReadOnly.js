/**


@returns {DOMMatrixReadOnly}
*/
DOMMatrixReadOnly = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.a = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.b = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.c = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.d = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.e = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.f = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
DOMMatrixReadOnly.prototype.is2D = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
DOMMatrixReadOnly.prototype.isIdentity = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m11 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m12 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m13 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m14 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m21 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m22 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m23 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m24 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m31 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m32 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m33 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m34 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m41 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m42 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m43 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DOMMatrixReadOnly.prototype.m44 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.flipX = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.flipY = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.inverse = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMMatrixInit} [other] DOMMatrixInit
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.multiply = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [rotX]
@param {Number} [rotY]
@param {Number} [rotZ]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.rotate = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [x]
@param {Number} [y]
@param {Number} [z]
@param {Number} [angle]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.rotateAxisAngle = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [x]
@param {Number} [y]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.rotateFromVector = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [scaleX]
@param {Number} [scaleY]
@param {Number} [scaleZ]
@param {Number} [originX]
@param {Number} [originY]
@param {Number} [originZ]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.scale = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [scale]
@param {Number} [originX]
@param {Number} [originY]
@param {Number} [originZ]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.scale3d = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [scaleX]
@param {Number} [scaleY]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.scaleNonUniform = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [sx]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.skewX = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [sy]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.skewY = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Float32Array}
**/
DOMMatrixReadOnly.prototype.toFloat32Array = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Float64Array}
**/
DOMMatrixReadOnly.prototype.toFloat64Array = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
DOMMatrixReadOnly.prototype.toJSON = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMPointInit} [point] DOMPointInit
@returns {DOMPoint}
**/
DOMMatrixReadOnly.prototype.transformPoint = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} [tx]
@param {Number} [ty]
@param {Number} [tz]
@returns {DOMMatrix}
**/
DOMMatrixReadOnly.prototype.translate = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
DOMMatrixReadOnly.prototype.toString = function() {};

