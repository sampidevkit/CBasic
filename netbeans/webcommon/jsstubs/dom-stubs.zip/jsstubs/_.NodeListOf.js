/**


@returns {NodeListOf}
*/
NodeListOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Returns the node with index index from the collection. The nodes are sorted in tree order.

@param {Number} index
@returns {Object} TNode
**/
NodeListOf.prototype.item = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Performs the specified action for each node in an list.

@param {Function} callbackfn (value: TNode, key: number, parent: NodeListOf<TNode>) => void - A function that accepts up to three arguments. forEach calls the callbackfn function one time for each element in the list.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
@returns {undefined}
**/
NodeListOf.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
NodeListOf.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an array of key, value pairs for every entry in the list.

@returns {IterableIterator}
**/
NodeListOf.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an list of keys in the list.

@returns {IterableIterator}
**/
NodeListOf.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an list of values in the list.

@returns {IterableIterator}
**/
NodeListOf.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
NodeListOf.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Returns the node with index index from the collection. The nodes are sorted in tree order.

@param {Number} index
@returns {(Node | null)} Node | null
**/
NodeListOf.prototype.item = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Performs the specified action for each node in an list.

@param {Function} callbackfn (value: Node, key: number, parent: NodeList) => void - A function that accepts up to three arguments. forEach calls the callbackfn function one time for each element in the list.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
@returns {undefined}
**/
NodeListOf.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
NodeListOf.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an array of key, value pairs for every entry in the list.

@returns {IterableIterator}
**/
NodeListOf.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an list of keys in the list.

@returns {IterableIterator}
**/
NodeListOf.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an list of values in the list.

@returns {IterableIterator}
**/
NodeListOf.prototype.values = function() {};

