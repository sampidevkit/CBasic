/**


@returns {ImageBitmap}
*/
ImageBitmap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
ImageBitmap.prototype.height = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
ImageBitmap.prototype.width = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Releases imageBitmap's underlying bitmap data.

@returns {undefined}
**/
ImageBitmap.prototype.close = function() {};

