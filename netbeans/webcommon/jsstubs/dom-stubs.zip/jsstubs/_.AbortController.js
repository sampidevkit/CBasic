/**
A controller object that allows you to abort one or more DOM requests as and when desired.

@returns {AbortController}
*/
AbortController = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AbortSignal}
**/
AbortController.prototype.signal = new AbortSignal();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Invoking this method will set this object's AbortSignal's aborted flag and signal to any observers that the associated activity is to be aborted.

@param {Object} [reason]
@returns {undefined}
**/
AbortController.prototype.abort = function() {};

