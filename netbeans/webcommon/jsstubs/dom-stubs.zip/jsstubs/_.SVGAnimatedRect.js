/**
Used for attributes of basic SVGRect which can be animated.

@returns {SVGAnimatedRect}
*/
SVGAnimatedRect = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMRectReadOnly}
**/
SVGAnimatedRect.prototype.animVal = new DOMRectReadOnly();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMRect}
**/
SVGAnimatedRect.prototype.baseVal = new DOMRect();

