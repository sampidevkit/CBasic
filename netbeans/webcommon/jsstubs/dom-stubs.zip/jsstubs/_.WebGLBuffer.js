/**
Part of the WebGL API and represents an opaque buffer object storing data such as vertices or colors.

@returns {WebGLBuffer}
*/
WebGLBuffer = function() {};

