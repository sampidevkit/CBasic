/**


@returns {CanvasPathDrawingStyles}
*/
CanvasPathDrawingStyles = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("butt" | "round" | "square")} CanvasLineCap
**/
CanvasPathDrawingStyles.prototype.lineCap = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CanvasPathDrawingStyles.prototype.lineDashOffset = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("bevel" | "miter" | "round")} CanvasLineJoin
**/
CanvasPathDrawingStyles.prototype.lineJoin = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CanvasPathDrawingStyles.prototype.lineWidth = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CanvasPathDrawingStyles.prototype.miterLimit = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
CanvasPathDrawingStyles.prototype.getLineDash = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Iterable} segments Iterable
@returns {undefined}
**/
CanvasPathDrawingStyles.prototype.setLineDash = function(segments) {};

