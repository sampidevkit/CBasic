/**
Available only in secure contexts.

@returns {FileSystemHandle}
*/
FileSystemHandle = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("directory" | "file")} FileSystemHandleKind
**/
FileSystemHandle.prototype.kind = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
FileSystemHandle.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {FileSystemHandle} other FileSystemHandle
@returns {Promise}
**/
FileSystemHandle.prototype.isSameEntry = function(other) {};

