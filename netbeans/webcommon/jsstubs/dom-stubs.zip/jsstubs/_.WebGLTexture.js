/**
Part of the WebGL API and represents an opaque texture object providing storage and state for texturing operations.

@returns {WebGLTexture}
*/
WebGLTexture = function() {};

