/**


@returns {PaymentCurrencyAmount}
*/
PaymentCurrencyAmount = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
PaymentCurrencyAmount.prototype.currency = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
PaymentCurrencyAmount.prototype.value = new String();

