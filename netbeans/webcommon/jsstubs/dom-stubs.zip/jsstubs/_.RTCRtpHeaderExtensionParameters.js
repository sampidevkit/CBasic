/**


@returns {RTCRtpHeaderExtensionParameters}
*/
RTCRtpHeaderExtensionParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
RTCRtpHeaderExtensionParameters.prototype.encrypted = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RTCRtpHeaderExtensionParameters.prototype.id = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCRtpHeaderExtensionParameters.prototype.uri = new String();

