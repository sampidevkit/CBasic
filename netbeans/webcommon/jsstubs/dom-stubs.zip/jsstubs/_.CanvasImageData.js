/**


@returns {CanvasImageData}
*/
CanvasImageData = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {ImageData} imagedata ImageData
@returns {ImageData}
**/
CanvasImageData.prototype.createImageData = function(imagedata) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} sx
@param {Number} sy
@param {Number} sw
@param {Number} sh
@param {ImageDataSettings} [settings] ImageDataSettings
@returns {ImageData}
**/
CanvasImageData.prototype.getImageData = function(sx, sy, sw, sh) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {ImageData} imagedata ImageData
@param {Number} dx
@param {Number} dy
@param {Number} dirtyX
@param {Number} dirtyY
@param {Number} dirtyWidth
@param {Number} dirtyHeight
@returns {undefined}
**/
CanvasImageData.prototype.putImageData = function(imagedata, dx, dy, dirtyX, dirtyY, dirtyWidth, dirtyHeight) {};

