/**


@returns {RTCIceServer}
*/
RTCIceServer = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCIceServer.prototype.credential = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {"password"} RTCIceCredentialType
**/
RTCIceServer.prototype.credentialType = "password";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | String)} string | string[]
**/
RTCIceServer.prototype.urls = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCIceServer.prototype.username = new String();

