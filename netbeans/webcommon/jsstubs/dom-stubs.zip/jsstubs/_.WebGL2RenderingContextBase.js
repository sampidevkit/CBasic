/**


@returns {WebGL2RenderingContextBase}
*/
WebGL2RenderingContextBase = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {WebGLQuery} query WebGLQuery
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.beginQuery = function(target, query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} primitiveMode GLenum
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.beginTransformFeedback = function(primitiveMode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} index GLuint
@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.bindBufferBase = function(target, index, buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} index GLuint
@param {(WebGLBuffer | null)} buffer WebGLBuffer | null
@param {Number} offset GLintptr
@param {Number} size GLsizeiptr
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.bindBufferRange = function(target, index, buffer, offset, size) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} unit GLuint
@param {(WebGLSampler | null)} sampler WebGLSampler | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.bindSampler = function(unit, sampler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {(WebGLTransformFeedback | null)} tf WebGLTransformFeedback | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.bindTransformFeedback = function(target, tf) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObject | null)} array WebGLVertexArrayObject | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.bindVertexArray = function(array) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} srcX0 GLint
@param {Number} srcY0 GLint
@param {Number} srcX1 GLint
@param {Number} srcY1 GLint
@param {Number} dstX0 GLint
@param {Number} dstY0 GLint
@param {Number} dstX1 GLint
@param {Number} dstY1 GLint
@param {Number} mask GLbitfield
@param {Number} filter GLenum
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.blitFramebuffer = function(srcX0, srcY0, srcX1, srcY1, dstX0, dstY0, dstX1, dstY1, mask, filter) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Number} depth GLfloat
@param {Number} stencil GLint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.clearBufferfi = function(buffer, drawbuffer, depth, stencil) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Iterable} values Iterable
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.clearBufferfv = function(buffer, drawbuffer, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Iterable} values Iterable
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.clearBufferiv = function(buffer, drawbuffer, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} buffer GLenum
@param {Number} drawbuffer GLint
@param {Iterable} values Iterable
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.clearBufferuiv = function(buffer, drawbuffer, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSync} sync WebGLSync
@param {Number} flags GLbitfield
@param {Number} timeout GLuint64
@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.clientWaitSync = function(sync, flags, timeout) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} border GLint
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} [srcOffset] GLuint
@param {Number} [srcLengthOverride] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.compressedTexImage3D = function(target, level, internalformat, width, height, depth, border, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} zoffset GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} format GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} [srcOffset] GLuint
@param {Number} [srcLengthOverride] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.compressedTexSubImage3D = function(target, level, xoffset, yoffset, zoffset, width, height, depth, format, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} readTarget GLenum
@param {Number} writeTarget GLenum
@param {Number} readOffset GLintptr
@param {Number} writeOffset GLintptr
@param {Number} size GLsizeiptr
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.copyBufferSubData = function(readTarget, writeTarget, readOffset, writeOffset, size) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} zoffset GLint
@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.copyTexSubImage3D = function(target, level, xoffset, yoffset, zoffset, x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLQuery | null)} WebGLQuery | null
**/
WebGL2RenderingContextBase.prototype.createQuery = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLSampler | null)} WebGLSampler | null
**/
WebGL2RenderingContextBase.prototype.createSampler = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLTransformFeedback | null)} WebGLTransformFeedback | null
**/
WebGL2RenderingContextBase.prototype.createTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLVertexArrayObject | null)} WebGLVertexArrayObject | null
**/
WebGL2RenderingContextBase.prototype.createVertexArray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLQuery | null)} query WebGLQuery | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.deleteQuery = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSampler | null)} sampler WebGLSampler | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.deleteSampler = function(sampler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSync | null)} sync WebGLSync | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.deleteSync = function(sync) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLTransformFeedback | null)} tf WebGLTransformFeedback | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.deleteTransformFeedback = function(tf) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObject | null)} vertexArray WebGLVertexArrayObject | null
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.deleteVertexArray = function(vertexArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} first GLint
@param {Number} count GLsizei
@param {Number} instanceCount GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.drawArraysInstanced = function(mode, first, count, instanceCount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Iterable} buffers Iterable
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.drawBuffers = function(buffers) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} count GLsizei
@param {Number} type GLenum
@param {Number} offset GLintptr
@param {Number} instanceCount GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.drawElementsInstanced = function(mode, count, type, offset, instanceCount) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} mode GLenum
@param {Number} start GLuint
@param {Number} end GLuint
@param {Number} count GLsizei
@param {Number} type GLenum
@param {Number} offset GLintptr
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.drawRangeElements = function(mode, start, end, count, type, offset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.endQuery = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.endTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} condition GLenum
@param {Number} flags GLbitfield
@returns {(WebGLSync | null)} WebGLSync | null
**/
WebGL2RenderingContextBase.prototype.fenceSync = function(condition, flags) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} attachment GLenum
@param {(WebGLTexture | null)} texture WebGLTexture | null
@param {Number} level GLint
@param {Number} layer GLint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.framebufferTextureLayer = function(target, attachment, texture, level, layer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} uniformBlockIndex GLuint
@returns {(String | null)} string | null
**/
WebGL2RenderingContextBase.prototype.getActiveUniformBlockName = function(program, uniformBlockIndex) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} uniformBlockIndex GLuint
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getActiveUniformBlockParameter = function(program, uniformBlockIndex, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Iterable} uniformIndices Iterable
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getActiveUniforms = function(program, uniformIndices, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} srcByteOffset GLintptr
@param {ArrayBufferView} dstBuffer ArrayBufferView
@param {Number} [dstOffset] GLuint
@param {Number} [length] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.getBufferSubData = function(target, srcByteOffset, dstBuffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {String} name
@returns {Number} GLint
**/
WebGL2RenderingContextBase.prototype.getFragDataLocation = function(program, name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} index GLuint
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getIndexedParameter = function(target, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} internalformat GLenum
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getInternalformatParameter = function(target, internalformat, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} pname GLenum
@returns {(WebGLQuery | null)} WebGLQuery | null
**/
WebGL2RenderingContextBase.prototype.getQuery = function(target, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLQuery} query WebGLQuery
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getQueryParameter = function(query, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSampler} sampler WebGLSampler
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getSamplerParameter = function(sampler, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSync} sync WebGLSync
@param {Number} pname GLenum
@returns {Object}
**/
WebGL2RenderingContextBase.prototype.getSyncParameter = function(sync, pname) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} index GLuint
@returns {(WebGLActiveInfo | null)} WebGLActiveInfo | null
**/
WebGL2RenderingContextBase.prototype.getTransformFeedbackVarying = function(program, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {String} uniformBlockName
@returns {Number} GLuint
**/
WebGL2RenderingContextBase.prototype.getUniformBlockIndex = function(program, uniformBlockName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Iterable} uniformNames Iterable
@returns {(Iterable | null)} Iterable<GLuint> | null
**/
WebGL2RenderingContextBase.prototype.getUniformIndices = function(program, uniformNames) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} target GLenum
@param {Iterable} attachments Iterable
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.invalidateFramebuffer = function(target, attachments) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} target GLenum
@param {Iterable} attachments Iterable
@param {Number} x GLint
@param {Number} y GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.invalidateSubFramebuffer = function(target, attachments, x, y, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLQuery | null)} query WebGLQuery | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContextBase.prototype.isQuery = function(query) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSampler | null)} sampler WebGLSampler | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContextBase.prototype.isSampler = function(sampler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLSync | null)} sync WebGLSync | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContextBase.prototype.isSync = function(sync) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLTransformFeedback | null)} tf WebGLTransformFeedback | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContextBase.prototype.isTransformFeedback = function(tf) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObject | null)} vertexArray WebGLVertexArrayObject | null
@returns {Boolean} GLboolean
**/
WebGL2RenderingContextBase.prototype.isVertexArray = function(vertexArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.pauseTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} src GLenum
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.readBuffer = function(src) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} samples GLsizei
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.renderbufferStorageMultisample = function(target, samples, internalformat, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.resumeTransformFeedback = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSampler} sampler WebGLSampler
@param {Number} pname GLenum
@param {Number} param GLfloat
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.samplerParameterf = function(sampler, pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSampler} sampler WebGLSampler
@param {Number} pname GLenum
@param {Number} param GLint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.samplerParameteri = function(sampler, pname, param) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} internalformat GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} border GLint
@param {Number} format GLenum
@param {Number} type GLenum
@param {ArrayBufferView} srcData ArrayBufferView
@param {Number} srcOffset GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.texImage3D = function(target, level, internalformat, width, height, depth, border, format, type, srcData, srcOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} levels GLsizei
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.texStorage2D = function(target, levels, internalformat, width, height) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} levels GLsizei
@param {Number} internalformat GLenum
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.texStorage3D = function(target, levels, internalformat, width, height, depth) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} target GLenum
@param {Number} level GLint
@param {Number} xoffset GLint
@param {Number} yoffset GLint
@param {Number} zoffset GLint
@param {Number} width GLsizei
@param {Number} height GLsizei
@param {Number} depth GLsizei
@param {Number} format GLenum
@param {Number} type GLenum
@param {(ArrayBufferView | null)} srcData ArrayBufferView | null
@param {Number} [srcOffset] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.texSubImage3D = function(target, level, xoffset, yoffset, zoffset, width, height, depth, format, type, srcData) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Iterable} varyings Iterable
@param {Number} bufferMode GLenum
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.transformFeedbackVaryings = function(program, varyings, bufferMode) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform1ui = function(location, v0) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform1uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@param {Number} v1 GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform2ui = function(location, v0, v1) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform2uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@param {Number} v1 GLuint
@param {Number} v2 GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform3ui = function(location, v0, v1, v2) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform3uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Number} v0 GLuint
@param {Number} v1 GLuint
@param {Number} v2 GLuint
@param {Number} v3 GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform4ui = function(location, v0, v1, v2, v3) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniform4uiv = function(location, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLProgram} program WebGLProgram
@param {Number} uniformBlockIndex GLuint
@param {Number} uniformBlockBinding GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformBlockBinding = function(program, uniformBlockIndex, uniformBlockBinding) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformMatrix2x3fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformMatrix2x4fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformMatrix3x2fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformMatrix3x4fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformMatrix4x2fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {(WebGLUniformLocation | null)} location WebGLUniformLocation | null
@param {Boolean} transpose GLboolean
@param {Iterable} data Iterable
@param {Number} [srcOffset] GLuint
@param {Number} [srcLength] GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.uniformMatrix4x3fv = function(location, transpose, data) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} divisor GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.vertexAttribDivisor = function(index, divisor) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLint
@param {Number} y GLint
@param {Number} z GLint
@param {Number} w GLint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.vertexAttribI4i = function(index, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.vertexAttribI4iv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} x GLuint
@param {Number} y GLuint
@param {Number} z GLuint
@param {Number} w GLuint
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.vertexAttribI4ui = function(index, x, y, z, w) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@param {Number} index GLuint
@param {Iterable} values Iterable
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.vertexAttribI4uiv = function(index, values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index GLuint
@param {Number} size GLint
@param {Number} type GLenum
@param {Number} stride GLsizei
@param {Number} offset GLintptr
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.vertexAttribIPointer = function(index, size, type, stride, offset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {WebGLSync} sync WebGLSync
@param {Number} flags GLbitfield
@param {Number} timeout GLint64
@returns {undefined}
**/
WebGL2RenderingContextBase.prototype.waitSync = function(sync, flags, timeout) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.ACTIVE_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.ALREADY_SIGNALED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.ANY_SAMPLES_PASSED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.ANY_SAMPLES_PASSED_CONSERVATIVE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT10 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT11 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT12 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT13 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT14 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT15 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT6 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT7 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COLOR_ATTACHMENT9 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COMPARE_REF_TO_TEXTURE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.CONDITION_SATISFIED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COPY_READ_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COPY_READ_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COPY_WRITE_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.COPY_WRITE_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.CURRENT_QUERY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DEPTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DEPTH24_STENCIL8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DEPTH32F_STENCIL8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DEPTH_COMPONENT24 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DEPTH_COMPONENT32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER0 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER1 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER10 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER11 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER12 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER13 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER14 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER15 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER6 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER7 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_BUFFER9 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_FRAMEBUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DRAW_FRAMEBUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DYNAMIC_COPY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.DYNAMIC_READ = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_32_UNSIGNED_INT_24_8_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_MAT2x3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_MAT2x4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_MAT3x2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_MAT3x4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_MAT4x2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FLOAT_MAT4x3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAGMENT_SHADER_DERIVATIVE_HINT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_ALPHA_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_BLUE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_COLOR_ENCODING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_DEPTH_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_GREEN_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_RED_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_STENCIL_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_ATTACHMENT_TEXTURE_LAYER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_DEFAULT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.FRAMEBUFFER_INCOMPLETE_MULTISAMPLE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.HALF_FLOAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INTERLEAVED_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INT_2_10_10_10_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INT_SAMPLER_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INT_SAMPLER_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INT_SAMPLER_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INT_SAMPLER_CUBE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.INVALID_INDEX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_3D_TEXTURE_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_ARRAY_TEXTURE_LAYERS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_CLIENT_WAIT_TIMEOUT_WEBGL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_COLOR_ATTACHMENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_COMBINED_FRAGMENT_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_COMBINED_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_COMBINED_VERTEX_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_DRAW_BUFFERS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_ELEMENTS_INDICES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_ELEMENTS_VERTICES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_ELEMENT_INDEX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_FRAGMENT_INPUT_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_FRAGMENT_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_FRAGMENT_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_PROGRAM_TEXEL_OFFSET = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_SAMPLES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_SERVER_WAIT_TIMEOUT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_TEXTURE_LOD_BIAS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_TRANSFORM_FEEDBACK_SEPARATE_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_UNIFORM_BLOCK_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_UNIFORM_BUFFER_BINDINGS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_VARYING_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_VERTEX_OUTPUT_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_VERTEX_UNIFORM_BLOCKS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MAX_VERTEX_UNIFORM_COMPONENTS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MIN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.MIN_PROGRAM_TEXEL_OFFSET = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.OBJECT_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PACK_ROW_LENGTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PACK_SKIP_PIXELS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PACK_SKIP_ROWS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PIXEL_PACK_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PIXEL_PACK_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PIXEL_UNPACK_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.PIXEL_UNPACK_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.QUERY_RESULT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.QUERY_RESULT_AVAILABLE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R11F_G11F_B10F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.R8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RASTERIZER_DISCARD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.READ_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.READ_FRAMEBUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.READ_FRAMEBUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RED_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RENDERBUFFER_SAMPLES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB10_A2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB10_A2UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB9_E5 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA16F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA16I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA16UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA32F = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA32I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA32UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA8I = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA8UI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA8_SNORM = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGBA_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RGB_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.RG_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SAMPLER_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SAMPLER_2D_ARRAY_SHADOW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SAMPLER_2D_SHADOW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SAMPLER_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SAMPLER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SAMPLER_CUBE_SHADOW = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SEPARATE_ATTRIBS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SIGNALED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SIGNED_NORMALIZED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SRGB = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SRGB8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SRGB8_ALPHA8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.STATIC_COPY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.STATIC_READ = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.STENCIL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.STREAM_COPY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.STREAM_READ = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SYNC_CONDITION = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SYNC_FENCE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SYNC_FLAGS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SYNC_FLUSH_COMMANDS_BIT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SYNC_GPU_COMMANDS_COMPLETE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.SYNC_STATUS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_BASE_LEVEL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_BINDING_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_BINDING_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_COMPARE_FUNC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_COMPARE_MODE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_IMMUTABLE_FORMAT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_IMMUTABLE_LEVELS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_MAX_LEVEL = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_MAX_LOD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_MIN_LOD = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TEXTURE_WRAP_R = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TIMEOUT_EXPIRED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLint64
**/
WebGL2RenderingContextBase.prototype.TIMEOUT_IGNORED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_ACTIVE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_BUFFER_MODE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_BUFFER_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_BUFFER_START = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_PAUSED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_PRIMITIVES_WRITTEN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.TRANSFORM_FEEDBACK_VARYINGS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_ARRAY_STRIDE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_ACTIVE_UNIFORMS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_ACTIVE_UNIFORM_INDICES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_DATA_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_INDEX = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_REFERENCED_BY_FRAGMENT_SHADER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BLOCK_REFERENCED_BY_VERTEX_SHADER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BUFFER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BUFFER_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BUFFER_OFFSET_ALIGNMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BUFFER_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_BUFFER_START = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_IS_ROW_MAJOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_MATRIX_STRIDE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_OFFSET = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_SIZE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNIFORM_TYPE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNPACK_IMAGE_HEIGHT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNPACK_ROW_LENGTH = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNPACK_SKIP_IMAGES = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNPACK_SKIP_PIXELS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNPACK_SKIP_ROWS = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNALED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_10F_11F_11F_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_24_8 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_2_10_10_10_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_5_9_9_9_REV = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_SAMPLER_2D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_SAMPLER_2D_ARRAY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_SAMPLER_3D = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_SAMPLER_CUBE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_VEC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_VEC3 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_INT_VEC4 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.UNSIGNED_NORMALIZED = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.VERTEX_ARRAY_BINDING = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.VERTEX_ATTRIB_ARRAY_DIVISOR = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.VERTEX_ATTRIB_ARRAY_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WebGL2RenderingContextBase.prototype.WAIT_FAILED = new Number();

