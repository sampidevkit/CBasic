/**


@returns {PaymentDetailsUpdate}
*/
PaymentDetailsUpdate = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
PaymentDetailsUpdate.prototype.paymentMethodErrors = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PaymentItem}
**/
PaymentDetailsUpdate.prototype.total = new PaymentItem();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PaymentItem[]}
**/
PaymentDetailsUpdate.prototype.displayItems = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PaymentDetailsModifier[]}
**/
PaymentDetailsUpdate.prototype.modifiers = new Array();

