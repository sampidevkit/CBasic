/**


@returns {DynamicsCompressorOptions}
*/
DynamicsCompressorOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DynamicsCompressorOptions.prototype.attack = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DynamicsCompressorOptions.prototype.knee = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DynamicsCompressorOptions.prototype.ratio = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DynamicsCompressorOptions.prototype.release = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DynamicsCompressorOptions.prototype.threshold = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
DynamicsCompressorOptions.prototype.channelCount = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("clamped-max" | "explicit" | "max")} ChannelCountMode
**/
DynamicsCompressorOptions.prototype.channelCountMode = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("discrete" | "speakers")} ChannelInterpretation
**/
DynamicsCompressorOptions.prototype.channelInterpretation = new Object();

