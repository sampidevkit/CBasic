/**


@returns {AudioParamMap}
*/
AudioParamMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Function} callbackfn (value: AudioParam, key: string, parent: AudioParamMap) => void
@param {Object} [thisArg]
@returns {undefined}
**/
AudioParamMap.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Function} callbackfn (value: V, key: K, map: ReadonlyMap<K, V>) => void
@param {Object} [thisArg]
@returns {undefined}
**/
AudioParamMap.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {(Object | undefined)} V | undefined
**/
AudioParamMap.prototype.get = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {Boolean}
**/
AudioParamMap.prototype.has = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {Number}
**/
AudioParamMap.prototype.size = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of entries in the map.

@returns {IterableIterator}
**/
AudioParamMap.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of key, value pairs for every entry in the map.

@returns {IterableIterator}
**/
AudioParamMap.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of keys in the map

@returns {IterableIterator}
**/
AudioParamMap.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the map

@returns {IterableIterator}
**/
AudioParamMap.prototype.values = function() {};

