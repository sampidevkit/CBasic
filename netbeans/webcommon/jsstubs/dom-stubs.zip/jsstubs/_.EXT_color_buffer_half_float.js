/**


@returns {EXT_color_buffer_half_float}
*/
EXT_color_buffer_half_float = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
EXT_color_buffer_half_float.prototype.FRAMEBUFFER_ATTACHMENT_COMPONENT_TYPE_EXT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
EXT_color_buffer_half_float.prototype.RGB16F_EXT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
EXT_color_buffer_half_float.prototype.RGBA16F_EXT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
EXT_color_buffer_half_float.prototype.UNSIGNED_NORMALIZED_EXT = new Number();

