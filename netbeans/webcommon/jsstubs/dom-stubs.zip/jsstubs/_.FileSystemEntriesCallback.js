/**


@returns {FileSystemEntriesCallback}
*/
FileSystemEntriesCallback = function() {};

