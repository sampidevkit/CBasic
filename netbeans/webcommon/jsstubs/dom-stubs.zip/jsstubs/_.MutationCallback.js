/**


@returns {MutationCallback}
*/
MutationCallback = function() {};

