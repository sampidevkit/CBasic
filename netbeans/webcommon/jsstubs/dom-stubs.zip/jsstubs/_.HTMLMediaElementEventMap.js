/**


@returns {HTMLMediaElementEventMap}
*/
HTMLMediaElementEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaEncryptedEvent}
**/
HTMLMediaElementEventMap.prototype["encrypted"] = new MediaEncryptedEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["waitingforkey"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["fullscreenchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["fullscreenerror"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLMediaElementEventMap.prototype["copy"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLMediaElementEventMap.prototype["cut"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLMediaElementEventMap.prototype["paste"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
HTMLMediaElementEventMap.prototype["abort"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLMediaElementEventMap.prototype["animationcancel"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLMediaElementEventMap.prototype["animationend"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLMediaElementEventMap.prototype["animationiteration"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLMediaElementEventMap.prototype["animationstart"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["auxclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {InputEvent}
**/
HTMLMediaElementEventMap.prototype["beforeinput"] = new InputEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLMediaElementEventMap.prototype["blur"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["canplay"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["canplaythrough"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["change"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["click"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["close"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLMediaElementEventMap.prototype["compositionend"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLMediaElementEventMap.prototype["compositionstart"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLMediaElementEventMap.prototype["compositionupdate"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["contextmenu"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["cuechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["dblclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["drag"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["dragend"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["dragenter"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["dragleave"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["dragover"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["dragstart"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLMediaElementEventMap.prototype["drop"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["durationchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["emptied"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["ended"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ErrorEvent}
**/
HTMLMediaElementEventMap.prototype["error"] = new ErrorEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLMediaElementEventMap.prototype["focus"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLMediaElementEventMap.prototype["focusin"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLMediaElementEventMap.prototype["focusout"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FormDataEvent}
**/
HTMLMediaElementEventMap.prototype["formdata"] = new FormDataEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["gotpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["input"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["invalid"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLMediaElementEventMap.prototype["keydown"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLMediaElementEventMap.prototype["keypress"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLMediaElementEventMap.prototype["keyup"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["load"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["loadeddata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["loadedmetadata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["loadstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["lostpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mousedown"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mouseenter"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mouseleave"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mousemove"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mouseout"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mouseover"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLMediaElementEventMap.prototype["mouseup"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["pause"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["play"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["playing"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointercancel"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointerdown"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointerenter"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointerleave"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointermove"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointerout"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointerover"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLMediaElementEventMap.prototype["pointerup"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
HTMLMediaElementEventMap.prototype["progress"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["ratechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["reset"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
HTMLMediaElementEventMap.prototype["resize"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["scroll"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SecurityPolicyViolationEvent}
**/
HTMLMediaElementEventMap.prototype["securitypolicyviolation"] = new SecurityPolicyViolationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["seeked"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["seeking"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["select"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["selectionchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["selectstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["slotchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["stalled"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SubmitEvent}
**/
HTMLMediaElementEventMap.prototype["submit"] = new SubmitEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["suspend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["timeupdate"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["toggle"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLMediaElementEventMap.prototype["touchcancel"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLMediaElementEventMap.prototype["touchend"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLMediaElementEventMap.prototype["touchmove"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLMediaElementEventMap.prototype["touchstart"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLMediaElementEventMap.prototype["transitioncancel"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLMediaElementEventMap.prototype["transitionend"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLMediaElementEventMap.prototype["transitionrun"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLMediaElementEventMap.prototype["transitionstart"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["volumechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["waiting"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["webkitanimationend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["webkitanimationiteration"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["webkitanimationstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLMediaElementEventMap.prototype["webkittransitionend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {WheelEvent}
**/
HTMLMediaElementEventMap.prototype["wheel"] = new WheelEvent();

