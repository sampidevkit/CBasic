/**


@returns {RTCRtpCodingParameters}
*/
RTCRtpCodingParameters = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCRtpCodingParameters.prototype.rid = new String();

