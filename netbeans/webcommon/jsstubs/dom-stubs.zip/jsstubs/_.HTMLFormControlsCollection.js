/**
A collection of HTML form control elements.

@returns {HTMLFormControlsCollection}
*/
HTMLFormControlsCollection = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Returns the item with ID or name name from the collection.

If there are multiple matching items, then a RadioNodeList object containing all those elements is returned.

@param {String} name
@returns {(RadioNodeList | Element | null)} RadioNodeList | Element | null
**/
HTMLFormControlsCollection.prototype.namedItem = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
HTMLFormControlsCollection.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Retrieves an object from various collections.

@param {Number} index
@returns {(Element | null)} Element | null
**/
HTMLFormControlsCollection.prototype.item = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
HTMLFormControlsCollection.prototype[Symbol.iterator] = function() {};

