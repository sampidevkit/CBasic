/**


@returns {FileList}
*/
FileList = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
FileList.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {(File | null)} File | null
**/
FileList.prototype.item = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
FileList.prototype[Symbol.iterator] = function() {};

