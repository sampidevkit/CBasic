/**


@returns {OES_vertex_array_object}
*/
OES_vertex_array_object = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObjectOES | null)} arrayObject WebGLVertexArrayObjectOES | null
@returns {undefined}
**/
OES_vertex_array_object.prototype.bindVertexArrayOES = function(arrayObject) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(WebGLVertexArrayObjectOES | null)} WebGLVertexArrayObjectOES | null
**/
OES_vertex_array_object.prototype.createVertexArrayOES = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObjectOES | null)} arrayObject WebGLVertexArrayObjectOES | null
@returns {undefined}
**/
OES_vertex_array_object.prototype.deleteVertexArrayOES = function(arrayObject) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(WebGLVertexArrayObjectOES | null)} arrayObject WebGLVertexArrayObjectOES | null
@returns {Boolean} GLboolean
**/
OES_vertex_array_object.prototype.isVertexArrayOES = function(arrayObject) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
OES_vertex_array_object.prototype.VERTEX_ARRAY_BINDING_OES = new Number();

