/**


@returns {PositionErrorCallback}
*/
PositionErrorCallback = function() {};

