/**


@returns {XMLHttpRequestEventMap}
*/
XMLHttpRequestEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
XMLHttpRequestEventMap.prototype["readystatechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["abort"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["error"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["load"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["loadend"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["loadstart"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["progress"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
XMLHttpRequestEventMap.prototype["timeout"] = new ProgressEvent();

