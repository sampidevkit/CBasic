/**
The RTCIceCandidate interface—part of the WebRTC API—represents a candidate Internet Connectivity Establishment (ICE) configuration which may be used to establish an RTCPeerConnection.

@returns {RTCIceCandidate}
*/
RTCIceCandidate = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidate.prototype.address = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
RTCIceCandidate.prototype.candidate = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("rtcp" | "rtp" | null)} RTCIceComponent | null
**/
RTCIceCandidate.prototype.component = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidate.prototype.foundation = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
RTCIceCandidate.prototype.port = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
RTCIceCandidate.prototype.priority = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("tcp" | "udp" | null)} RTCIceProtocol | null
**/
RTCIceCandidate.prototype.protocol = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidate.prototype.relatedAddress = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
RTCIceCandidate.prototype.relatedPort = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
RTCIceCandidate.prototype.sdpMLineIndex = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidate.prototype.sdpMid = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("active" | "passive" | "so" | null)} RTCIceTcpCandidateType | null
**/
RTCIceCandidate.prototype.tcpType = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("host" | "prflx" | "relay" | "srflx" | null)} RTCIceCandidateType | null
**/
RTCIceCandidate.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
RTCIceCandidate.prototype.usernameFragment = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {RTCIceCandidateInit}
**/
RTCIceCandidate.prototype.toJSON = function() {};

