/**


@returns {CanvasTransform}
*/
CanvasTransform = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMMatrix}
**/
CanvasTransform.prototype.getTransform = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
CanvasTransform.prototype.resetTransform = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} angle
@returns {undefined}
**/
CanvasTransform.prototype.rotate = function(angle) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@returns {undefined}
**/
CanvasTransform.prototype.scale = function(x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {DOMMatrix2DInit} [transform] DOMMatrix2DInit
@returns {undefined}
**/
CanvasTransform.prototype.setTransform = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} a
@param {Number} b
@param {Number} c
@param {Number} d
@param {Number} e
@param {Number} f
@returns {undefined}
**/
CanvasTransform.prototype.transform = function(a, b, c, d, e, f) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@returns {undefined}
**/
CanvasTransform.prototype.translate = function(x, y) {};

