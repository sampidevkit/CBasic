/**


@returns {InputDeviceInfo}
*/
InputDeviceInfo = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
InputDeviceInfo.prototype.deviceId = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
InputDeviceInfo.prototype.groupId = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("audioinput" | "audiooutput" | "videoinput")} MediaDeviceKind
**/
InputDeviceInfo.prototype.kind = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
InputDeviceInfo.prototype.label = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
InputDeviceInfo.prototype.toJSON = function() {};

