/**


@returns {WebAssembly.CompileError}
*/
WebAssembly.CompileError = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
WebAssembly.CompileError.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
WebAssembly.CompileError.prototype.message = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
WebAssembly.CompileError.prototype.stack = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
WebAssembly.CompileError.prototype.cause = new Error();

