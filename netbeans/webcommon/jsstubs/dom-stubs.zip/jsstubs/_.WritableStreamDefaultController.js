/**
This Streams API interface represents a controller allowing control of a WritableStream's state. When constructing a WritableStream, the underlying sink is given a corresponding WritableStreamDefaultController instance to manipulate.

@returns {WritableStreamDefaultController}
*/
WritableStreamDefaultController = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} [e]
@returns {undefined}
**/
WritableStreamDefaultController.prototype.error = function() {};

