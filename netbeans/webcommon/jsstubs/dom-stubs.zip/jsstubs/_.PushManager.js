/**
This Push API interface provides a way to receive notifications from third-party servers as well as request URLs for push notifications.
Available only in secure contexts.

@returns {PushManager}
*/
PushManager = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Promise}
**/
PushManager.prototype.getSubscription = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {PushSubscriptionOptionsInit} [options] PushSubscriptionOptionsInit
@returns {Promise}
**/
PushManager.prototype.permissionState = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {PushSubscriptionOptionsInit} [options] PushSubscriptionOptionsInit
@returns {Promise}
**/
PushManager.prototype.subscribe = function() {};

