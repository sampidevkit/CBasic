/**


@returns {CanvasRect}
*/
CanvasRect = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@param {Number} w
@param {Number} h
@returns {undefined}
**/
CanvasRect.prototype.clearRect = function(x, y, w, h) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@param {Number} w
@param {Number} h
@returns {undefined}
**/
CanvasRect.prototype.fillRect = function(x, y, w, h) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x
@param {Number} y
@param {Number} w
@param {Number} h
@returns {undefined}
**/
CanvasRect.prototype.strokeRect = function(x, y, w, h) {};

