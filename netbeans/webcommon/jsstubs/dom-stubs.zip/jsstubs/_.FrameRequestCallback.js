/**


@returns {FrameRequestCallback}
*/
FrameRequestCallback = function() {};

