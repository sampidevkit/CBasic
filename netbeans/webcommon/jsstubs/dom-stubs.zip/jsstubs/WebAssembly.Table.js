/**


@returns {WebAssembly.Table}
*/
WebAssembly.Table = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
WebAssembly.Table.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@returns {Object}
**/
WebAssembly.Table.prototype.get = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} delta
@param {Object} [value]
@returns {Number}
**/
WebAssembly.Table.prototype.grow = function(delta) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} index
@param {Object} [value]
@returns {undefined}
**/
WebAssembly.Table.prototype.set = function(index) {};

