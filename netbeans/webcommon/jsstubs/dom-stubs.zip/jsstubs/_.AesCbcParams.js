/**


@returns {AesCbcParams}
*/
AesCbcParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ArrayBufferView | ArrayBuffer)} BufferSource
**/
AesCbcParams.prototype.iv = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
AesCbcParams.prototype.name = new String();

