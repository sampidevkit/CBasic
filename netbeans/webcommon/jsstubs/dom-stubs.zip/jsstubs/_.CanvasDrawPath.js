/**


@returns {CanvasDrawPath}
*/
CanvasDrawPath = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {undefined}
**/
CanvasDrawPath.prototype.beginPath = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Path2D} path Path2D
@param {("evenodd" | "nonzero")} [fillRule] CanvasFillRule
@returns {undefined}
**/
CanvasDrawPath.prototype.clip = function(path) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Path2D} path Path2D
@param {("evenodd" | "nonzero")} [fillRule] CanvasFillRule
@returns {undefined}
**/
CanvasDrawPath.prototype.fill = function(path) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Path2D} path Path2D
@param {Number} x
@param {Number} y
@param {("evenodd" | "nonzero")} [fillRule] CanvasFillRule
@returns {Boolean}
**/
CanvasDrawPath.prototype.isPointInPath = function(path, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Path2D} path Path2D
@param {Number} x
@param {Number} y
@returns {Boolean}
**/
CanvasDrawPath.prototype.isPointInStroke = function(path, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Path2D} path Path2D
@returns {undefined}
**/
CanvasDrawPath.prototype.stroke = function(path) {};

