/**


@returns {FileSystemFileEntry}
*/
FileSystemFileEntry = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {FileCallback} successCallback FileCallback
@param {ErrorCallback} [errorCallback] ErrorCallback
@returns {undefined}
**/
FileSystemFileEntry.prototype.file = function(successCallback) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FileSystem}
**/
FileSystemFileEntry.prototype.filesystem = new FileSystem();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
FileSystemFileEntry.prototype.fullPath = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
FileSystemFileEntry.prototype.isDirectory = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
FileSystemFileEntry.prototype.isFile = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
FileSystemFileEntry.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {FileSystemEntryCallback} [successCallback] FileSystemEntryCallback
@param {ErrorCallback} [errorCallback] ErrorCallback
@returns {undefined}
**/
FileSystemFileEntry.prototype.getParent = function() {};

