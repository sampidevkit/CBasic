/**
Available only in secure contexts.

@returns {LockManager}
*/
LockManager = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Promise}
**/
LockManager.prototype.query = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@param {LockOptions} options LockOptions
@param {LockGrantedCallback} callback LockGrantedCallback
@returns {Promise}
**/
LockManager.prototype.request = function(name, options, callback) {};

