/**


@returns {WebGLQuery}
*/
WebGLQuery = function() {};

