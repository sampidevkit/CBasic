/**


@returns {RTCRtpSynchronizationSource}
*/
RTCRtpSynchronizationSource = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RTCRtpSynchronizationSource.prototype.audioLevel = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RTCRtpSynchronizationSource.prototype.rtpTimestamp = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
RTCRtpSynchronizationSource.prototype.source = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} DOMHighResTimeStamp
**/
RTCRtpSynchronizationSource.prototype.timestamp = new Number();

