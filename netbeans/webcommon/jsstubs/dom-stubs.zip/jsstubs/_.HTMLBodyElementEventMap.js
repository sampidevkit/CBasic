/**


@returns {HTMLBodyElementEventMap}
*/
HTMLBodyElementEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["orientationchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["fullscreenchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["fullscreenerror"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLBodyElementEventMap.prototype["copy"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLBodyElementEventMap.prototype["cut"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLBodyElementEventMap.prototype["paste"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
HTMLBodyElementEventMap.prototype["abort"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLBodyElementEventMap.prototype["animationcancel"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLBodyElementEventMap.prototype["animationend"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLBodyElementEventMap.prototype["animationiteration"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLBodyElementEventMap.prototype["animationstart"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["auxclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {InputEvent}
**/
HTMLBodyElementEventMap.prototype["beforeinput"] = new InputEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLBodyElementEventMap.prototype["blur"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["canplay"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["canplaythrough"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["change"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["click"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["close"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLBodyElementEventMap.prototype["compositionend"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLBodyElementEventMap.prototype["compositionstart"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLBodyElementEventMap.prototype["compositionupdate"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["contextmenu"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["cuechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["dblclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["drag"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["dragend"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["dragenter"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["dragleave"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["dragover"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["dragstart"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLBodyElementEventMap.prototype["drop"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["durationchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["emptied"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["ended"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ErrorEvent}
**/
HTMLBodyElementEventMap.prototype["error"] = new ErrorEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLBodyElementEventMap.prototype["focus"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLBodyElementEventMap.prototype["focusin"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLBodyElementEventMap.prototype["focusout"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FormDataEvent}
**/
HTMLBodyElementEventMap.prototype["formdata"] = new FormDataEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["gotpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["input"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["invalid"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLBodyElementEventMap.prototype["keydown"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLBodyElementEventMap.prototype["keypress"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLBodyElementEventMap.prototype["keyup"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["load"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["loadeddata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["loadedmetadata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["loadstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["lostpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mousedown"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mouseenter"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mouseleave"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mousemove"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mouseout"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mouseover"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLBodyElementEventMap.prototype["mouseup"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["pause"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["play"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["playing"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointercancel"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointerdown"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointerenter"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointerleave"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointermove"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointerout"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointerover"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLBodyElementEventMap.prototype["pointerup"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
HTMLBodyElementEventMap.prototype["progress"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["ratechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["reset"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
HTMLBodyElementEventMap.prototype["resize"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["scroll"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SecurityPolicyViolationEvent}
**/
HTMLBodyElementEventMap.prototype["securitypolicyviolation"] = new SecurityPolicyViolationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["seeked"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["seeking"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["select"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["selectionchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["selectstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["slotchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["stalled"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SubmitEvent}
**/
HTMLBodyElementEventMap.prototype["submit"] = new SubmitEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["suspend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["timeupdate"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["toggle"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLBodyElementEventMap.prototype["touchcancel"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLBodyElementEventMap.prototype["touchend"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLBodyElementEventMap.prototype["touchmove"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLBodyElementEventMap.prototype["touchstart"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLBodyElementEventMap.prototype["transitioncancel"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLBodyElementEventMap.prototype["transitionend"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLBodyElementEventMap.prototype["transitionrun"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLBodyElementEventMap.prototype["transitionstart"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["volumechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["waiting"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["webkitanimationend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["webkitanimationiteration"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["webkitanimationstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["webkittransitionend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {WheelEvent}
**/
HTMLBodyElementEventMap.prototype["wheel"] = new WheelEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["afterprint"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["beforeprint"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {BeforeUnloadEvent}
**/
HTMLBodyElementEventMap.prototype["beforeunload"] = new BeforeUnloadEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {GamepadEvent}
**/
HTMLBodyElementEventMap.prototype["gamepadconnected"] = new GamepadEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {GamepadEvent}
**/
HTMLBodyElementEventMap.prototype["gamepaddisconnected"] = new GamepadEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {HashChangeEvent}
**/
HTMLBodyElementEventMap.prototype["hashchange"] = new HashChangeEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["languagechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
HTMLBodyElementEventMap.prototype["message"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MessageEvent}
**/
HTMLBodyElementEventMap.prototype["messageerror"] = new MessageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["offline"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["online"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PageTransitionEvent}
**/
HTMLBodyElementEventMap.prototype["pagehide"] = new PageTransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PageTransitionEvent}
**/
HTMLBodyElementEventMap.prototype["pageshow"] = new PageTransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PopStateEvent}
**/
HTMLBodyElementEventMap.prototype["popstate"] = new PopStateEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PromiseRejectionEvent}
**/
HTMLBodyElementEventMap.prototype["rejectionhandled"] = new PromiseRejectionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {StorageEvent}
**/
HTMLBodyElementEventMap.prototype["storage"] = new StorageEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PromiseRejectionEvent}
**/
HTMLBodyElementEventMap.prototype["unhandledrejection"] = new PromiseRejectionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLBodyElementEventMap.prototype["unload"] = new Event();

