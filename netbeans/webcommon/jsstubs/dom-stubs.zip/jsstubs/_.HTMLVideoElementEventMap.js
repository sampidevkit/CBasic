/**


@returns {HTMLVideoElementEventMap}
*/
HTMLVideoElementEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["enterpictureinpicture"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["leavepictureinpicture"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaEncryptedEvent}
**/
HTMLVideoElementEventMap.prototype["encrypted"] = new MediaEncryptedEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["waitingforkey"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["fullscreenchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["fullscreenerror"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLVideoElementEventMap.prototype["copy"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLVideoElementEventMap.prototype["cut"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ClipboardEvent}
**/
HTMLVideoElementEventMap.prototype["paste"] = new ClipboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
HTMLVideoElementEventMap.prototype["abort"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLVideoElementEventMap.prototype["animationcancel"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLVideoElementEventMap.prototype["animationend"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLVideoElementEventMap.prototype["animationiteration"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AnimationEvent}
**/
HTMLVideoElementEventMap.prototype["animationstart"] = new AnimationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["auxclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {InputEvent}
**/
HTMLVideoElementEventMap.prototype["beforeinput"] = new InputEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLVideoElementEventMap.prototype["blur"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["canplay"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["canplaythrough"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["change"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["click"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["close"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLVideoElementEventMap.prototype["compositionend"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLVideoElementEventMap.prototype["compositionstart"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CompositionEvent}
**/
HTMLVideoElementEventMap.prototype["compositionupdate"] = new CompositionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["contextmenu"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["cuechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["dblclick"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["drag"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["dragend"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["dragenter"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["dragleave"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["dragover"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["dragstart"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DragEvent}
**/
HTMLVideoElementEventMap.prototype["drop"] = new DragEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["durationchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["emptied"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["ended"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ErrorEvent}
**/
HTMLVideoElementEventMap.prototype["error"] = new ErrorEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLVideoElementEventMap.prototype["focus"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLVideoElementEventMap.prototype["focusin"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FocusEvent}
**/
HTMLVideoElementEventMap.prototype["focusout"] = new FocusEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {FormDataEvent}
**/
HTMLVideoElementEventMap.prototype["formdata"] = new FormDataEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["gotpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["input"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["invalid"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLVideoElementEventMap.prototype["keydown"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLVideoElementEventMap.prototype["keypress"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyboardEvent}
**/
HTMLVideoElementEventMap.prototype["keyup"] = new KeyboardEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["load"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["loadeddata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["loadedmetadata"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["loadstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["lostpointercapture"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mousedown"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mouseenter"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mouseleave"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mousemove"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mouseout"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mouseover"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MouseEvent}
**/
HTMLVideoElementEventMap.prototype["mouseup"] = new MouseEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["pause"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["play"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["playing"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointercancel"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointerdown"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointerenter"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointerleave"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointermove"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointerout"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointerover"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PointerEvent}
**/
HTMLVideoElementEventMap.prototype["pointerup"] = new PointerEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ProgressEvent}
**/
HTMLVideoElementEventMap.prototype["progress"] = new ProgressEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["ratechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["reset"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {UIEvent}
**/
HTMLVideoElementEventMap.prototype["resize"] = new UIEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["scroll"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SecurityPolicyViolationEvent}
**/
HTMLVideoElementEventMap.prototype["securitypolicyviolation"] = new SecurityPolicyViolationEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["seeked"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["seeking"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["select"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["selectionchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["selectstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["slotchange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["stalled"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SubmitEvent}
**/
HTMLVideoElementEventMap.prototype["submit"] = new SubmitEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["suspend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["timeupdate"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["toggle"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLVideoElementEventMap.prototype["touchcancel"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLVideoElementEventMap.prototype["touchend"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLVideoElementEventMap.prototype["touchmove"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TouchEvent}
**/
HTMLVideoElementEventMap.prototype["touchstart"] = new TouchEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLVideoElementEventMap.prototype["transitioncancel"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLVideoElementEventMap.prototype["transitionend"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLVideoElementEventMap.prototype["transitionrun"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {TransitionEvent}
**/
HTMLVideoElementEventMap.prototype["transitionstart"] = new TransitionEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["volumechange"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["waiting"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["webkitanimationend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["webkitanimationiteration"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["webkitanimationstart"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
HTMLVideoElementEventMap.prototype["webkittransitionend"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {WheelEvent}
**/
HTMLVideoElementEventMap.prototype["wheel"] = new WheelEvent();

