/**


@returns {LinkStyle}
*/
LinkStyle = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(CSSStyleSheet | null)} CSSStyleSheet | null
**/
LinkStyle.prototype.sheet = new CSSStyleSheet();

