/**


@returns {ScrollToOptions}
*/
ScrollToOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
ScrollToOptions.prototype.left = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
ScrollToOptions.prototype.top = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("auto" | "smooth")} ScrollBehavior
**/
ScrollToOptions.prototype.behavior = new Object();

