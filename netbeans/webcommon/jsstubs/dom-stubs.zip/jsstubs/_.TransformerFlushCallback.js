/**


@returns {TransformerFlushCallback}
*/
TransformerFlushCallback = function() {};

