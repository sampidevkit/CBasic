/**


@returns {PaymentDetailsModifier}
*/
PaymentDetailsModifier = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PaymentItem[]}
**/
PaymentDetailsModifier.prototype.additionalDisplayItems = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
PaymentDetailsModifier.prototype.data = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
PaymentDetailsModifier.prototype.supportedMethods = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {PaymentItem}
**/
PaymentDetailsModifier.prototype.total = new PaymentItem();

