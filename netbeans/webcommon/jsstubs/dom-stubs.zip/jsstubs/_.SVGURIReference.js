/**


@returns {SVGURIReference}
*/
SVGURIReference = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGAnimatedString}
**/
SVGURIReference.prototype.href = new SVGAnimatedString();

