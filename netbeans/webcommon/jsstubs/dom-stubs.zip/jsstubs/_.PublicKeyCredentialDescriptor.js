/**


@returns {PublicKeyCredentialDescriptor}
*/
PublicKeyCredentialDescriptor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ArrayBufferView | ArrayBuffer)} BufferSource
**/
PublicKeyCredentialDescriptor.prototype.id = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {AuthenticatorTransport[]}
**/
PublicKeyCredentialDescriptor.prototype.transports = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {"public-key"} PublicKeyCredentialType
**/
PublicKeyCredentialDescriptor.prototype.type = "public-key";

