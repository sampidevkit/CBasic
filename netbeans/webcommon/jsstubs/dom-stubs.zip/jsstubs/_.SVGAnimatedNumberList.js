/**
The SVGAnimatedNumber interface is used for attributes which take a list of numbers and which can be animated.

@returns {SVGAnimatedNumberList}
*/
SVGAnimatedNumberList = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGNumberList}
**/
SVGAnimatedNumberList.prototype.animVal = new SVGNumberList();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SVGNumberList}
**/
SVGAnimatedNumberList.prototype.baseVal = new SVGNumberList();

