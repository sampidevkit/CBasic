/**
An object providing methods which are not dependent on any particular document. Such an object is returned by the Document.implementation property.

@returns {DOMImplementation}
*/
DOMImplementation = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(String | null)} namespace string | null
@param {(String | null)} qualifiedName string | null
@param {(DocumentType | null)} [doctype] DocumentType | null
@returns {XMLDocument}
**/
DOMImplementation.prototype.createDocument = function(namespace, qualifiedName) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} qualifiedName
@param {String} publicId
@param {String} systemId
@returns {DocumentType}
**/
DOMImplementation.prototype.createDocumentType = function(qualifiedName, publicId, systemId) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} [title]
@returns {Document}
**/
DOMImplementation.prototype.createHTMLDocument = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} args
@returns {true}
**/
DOMImplementation.prototype.hasFeature = function(args) {};

