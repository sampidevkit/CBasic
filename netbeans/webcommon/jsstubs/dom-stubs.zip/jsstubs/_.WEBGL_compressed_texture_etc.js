/**


@returns {WEBGL_compressed_texture_etc}
*/
WEBGL_compressed_texture_etc = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_R11_EAC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_RG11_EAC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_RGB8_ETC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_RGB8_PUNCHTHROUGH_ALPHA1_ETC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_RGBA8_ETC2_EAC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_SIGNED_R11_EAC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_SIGNED_RG11_EAC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_SRGB8_ETC2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_etc.prototype.COMPRESSED_SRGB8_PUNCHTHROUGH_ALPHA1_ETC2 = new Number();

