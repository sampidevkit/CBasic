/**


@returns {AudioBufferSourceOptions}
*/
AudioBufferSourceOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(AudioBuffer | null)} AudioBuffer | null
**/
AudioBufferSourceOptions.prototype.buffer = new AudioBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioBufferSourceOptions.prototype.detune = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
AudioBufferSourceOptions.prototype.loop = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioBufferSourceOptions.prototype.loopEnd = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioBufferSourceOptions.prototype.loopStart = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AudioBufferSourceOptions.prototype.playbackRate = new Number();

