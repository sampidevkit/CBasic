/**


@returns {TextTrackCueEventMap}
*/
TextTrackCueEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
TextTrackCueEventMap.prototype["enter"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
TextTrackCueEventMap.prototype["exit"] = new Event();

