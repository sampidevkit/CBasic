/**
Available only in secure contexts.

@returns {DeviceMotionEventAcceleration}
*/
DeviceMotionEventAcceleration = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
DeviceMotionEventAcceleration.prototype.x = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
DeviceMotionEventAcceleration.prototype.y = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | null)} number | null
**/
DeviceMotionEventAcceleration.prototype.z = new Number();

