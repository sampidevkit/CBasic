/**


@returns {IDBDatabaseInfo}
*/
IDBDatabaseInfo = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
IDBDatabaseInfo.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
IDBDatabaseInfo.prototype.version = new Number();

