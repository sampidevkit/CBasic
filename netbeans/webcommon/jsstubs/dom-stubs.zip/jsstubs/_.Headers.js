/**


@returns {Headers}
*/
Headers = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@param {String} value
@returns {undefined}
**/
Headers.prototype.append = function(name, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@returns {undefined}
**/
Headers.prototype.delete = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@returns {(String | null)} string | null
**/
Headers.prototype.get = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@returns {Boolean}
**/
Headers.prototype.has = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {String} name
@param {String} value
@returns {undefined}
**/
Headers.prototype.set = function(name, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Function} callbackfn (value: string, key: string, parent: Headers) => void
@param {Object} [thisArg]
@returns {undefined}
**/
Headers.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**


@returns {IterableIterator}
**/
Headers.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an iterator allowing to go through all key/value pairs contained in this object.

@returns {IterableIterator}
**/
Headers.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an iterator allowing to go through all keys of the key/value pairs contained in this object.

@returns {IterableIterator}
**/
Headers.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.iterable.d.ts
/**
Returns an iterator allowing to go through all values of the key/value pairs contained in this object.

@returns {IterableIterator}
**/
Headers.prototype.values = function() {};

