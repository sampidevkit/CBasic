/**


@returns {WEBGL_compressed_texture_s3tc_srgb}
*/
WEBGL_compressed_texture_s3tc_srgb = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_s3tc_srgb.prototype.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_s3tc_srgb.prototype.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_s3tc_srgb.prototype.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_compressed_texture_s3tc_srgb.prototype.COMPRESSED_SRGB_S3TC_DXT1_EXT = new Number();

