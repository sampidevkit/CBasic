/**
Basic cryptography features available in the current context. It allows access to a cryptographically strong random number generator and to cryptographic primitives.

@returns {Crypto}
*/
Crypto = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {SubtleCrypto}
**/
Crypto.prototype.subtle = new SubtleCrypto();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Object} array T
@returns {Object} T
**/
Crypto.prototype.getRandomValues = function(array) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**
Available only in secure contexts.

@returns {String}
**/
Crypto.prototype.randomUUID = function() {};

