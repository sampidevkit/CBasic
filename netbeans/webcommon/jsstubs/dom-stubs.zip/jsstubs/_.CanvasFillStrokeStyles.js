/**


@returns {CanvasFillStrokeStyles}
*/
CanvasFillStrokeStyles = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | CanvasGradient | CanvasPattern)} string | CanvasGradient | CanvasPattern
**/
CanvasFillStrokeStyles.prototype.fillStyle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | CanvasGradient | CanvasPattern)} string | CanvasGradient | CanvasPattern
**/
CanvasFillStrokeStyles.prototype.strokeStyle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} startAngle
@param {Number} x
@param {Number} y
@returns {CanvasGradient}
**/
CanvasFillStrokeStyles.prototype.createConicGradient = function(startAngle, x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x0
@param {Number} y0
@param {Number} x1
@param {Number} y1
@returns {CanvasGradient}
**/
CanvasFillStrokeStyles.prototype.createLinearGradient = function(x0, y0, x1, y1) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {(HTMLImageElement | SVGImageElement | HTMLVideoElement | HTMLCanvasElement | ImageBitmap)} image CanvasImageSource
@param {(String | null)} repetition string | null
@returns {(CanvasPattern | null)} CanvasPattern | null
**/
CanvasFillStrokeStyles.prototype.createPattern = function(image, repetition) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@param {Number} x0
@param {Number} y0
@param {Number} r0
@param {Number} x1
@param {Number} y1
@param {Number} r1
@returns {CanvasGradient}
**/
CanvasFillStrokeStyles.prototype.createRadialGradient = function(x0, y0, r0, x1, y1, r1) {};

