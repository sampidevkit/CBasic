/**


@returns {VideoConfiguration}
*/
VideoConfiguration = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
VideoConfiguration.prototype.bitrate = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("p3" | "rec2020" | "srgb")} ColorGamut
**/
VideoConfiguration.prototype.colorGamut = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
VideoConfiguration.prototype.contentType = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
VideoConfiguration.prototype.framerate = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("smpteSt2086" | "smpteSt2094-10" | "smpteSt2094-40")} HdrMetadataType
**/
VideoConfiguration.prototype.hdrMetadataType = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
VideoConfiguration.prototype.height = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
VideoConfiguration.prototype.scalabilityMode = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("hlg" | "pq" | "srgb")} TransferFunction
**/
VideoConfiguration.prototype.transferFunction = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
VideoConfiguration.prototype.width = new Number();

