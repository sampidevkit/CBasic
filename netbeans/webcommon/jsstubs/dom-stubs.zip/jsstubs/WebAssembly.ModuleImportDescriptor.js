/**


@returns {WebAssembly.ModuleImportDescriptor}
*/
WebAssembly.ModuleImportDescriptor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("function" | "global" | "memory" | "table")} ImportExportKind
**/
WebAssembly.ModuleImportDescriptor.prototype.kind = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
WebAssembly.ModuleImportDescriptor.prototype.module = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
WebAssembly.ModuleImportDescriptor.prototype.name = new String();

