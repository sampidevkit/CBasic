/**


@returns {PerformanceMeasureOptions}
*/
PerformanceMeasureOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
PerformanceMeasureOptions.prototype.detail = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} DOMHighResTimeStamp
**/
PerformanceMeasureOptions.prototype.duration = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | Number)} string | DOMHighResTimeStamp
**/
PerformanceMeasureOptions.prototype.end = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | Number)} string | DOMHighResTimeStamp
**/
PerformanceMeasureOptions.prototype.start = new Object();

