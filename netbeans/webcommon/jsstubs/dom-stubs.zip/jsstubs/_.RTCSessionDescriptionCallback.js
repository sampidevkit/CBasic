/**


@returns {RTCSessionDescriptionCallback}
*/
RTCSessionDescriptionCallback = function() {};

