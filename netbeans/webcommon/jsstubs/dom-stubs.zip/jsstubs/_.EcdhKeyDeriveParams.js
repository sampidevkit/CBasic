/**


@returns {EcdhKeyDeriveParams}
*/
EcdhKeyDeriveParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CryptoKey}
**/
EcdhKeyDeriveParams.prototype.public = new CryptoKey();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
EcdhKeyDeriveParams.prototype.name = new String();

