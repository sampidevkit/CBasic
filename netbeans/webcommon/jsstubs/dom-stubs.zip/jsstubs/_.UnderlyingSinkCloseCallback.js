/**


@returns {UnderlyingSinkCloseCallback}
*/
UnderlyingSinkCloseCallback = function() {};

