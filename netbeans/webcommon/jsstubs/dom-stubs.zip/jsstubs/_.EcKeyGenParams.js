/**


@returns {EcKeyGenParams}
*/
EcKeyGenParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String} NamedCurve
**/
EcKeyGenParams.prototype.namedCurve = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
EcKeyGenParams.prototype.name = new String();

