/**


@returns {AesGcmParams}
*/
AesGcmParams = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ArrayBufferView | ArrayBuffer)} BufferSource
**/
AesGcmParams.prototype.additionalData = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ArrayBufferView | ArrayBuffer)} BufferSource
**/
AesGcmParams.prototype.iv = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AesGcmParams.prototype.tagLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
AesGcmParams.prototype.name = new String();

