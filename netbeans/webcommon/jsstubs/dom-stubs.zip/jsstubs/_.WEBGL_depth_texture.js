/**
The WEBGL_depth_texture extension is part of the WebGL API and defines 2D depth and depth-stencil textures.

@returns {WEBGL_depth_texture}
*/
WEBGL_depth_texture = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number} GLenum
**/
WEBGL_depth_texture.prototype.UNSIGNED_INT_24_8_WEBGL = new Number();

