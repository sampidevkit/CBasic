/**


@returns {DOMQuadInit}
*/
DOMQuadInit = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMPointInit}
**/
DOMQuadInit.prototype.p1 = new DOMPointInit();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMPointInit}
**/
DOMQuadInit.prototype.p2 = new DOMPointInit();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMPointInit}
**/
DOMQuadInit.prototype.p3 = new DOMPointInit();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {DOMPointInit}
**/
DOMQuadInit.prototype.p4 = new DOMPointInit();

