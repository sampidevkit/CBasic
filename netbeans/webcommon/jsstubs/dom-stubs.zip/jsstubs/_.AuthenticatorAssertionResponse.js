/**
Available only in secure contexts.

@returns {AuthenticatorAssertionResponse}
*/
AuthenticatorAssertionResponse = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ArrayBuffer}
**/
AuthenticatorAssertionResponse.prototype.authenticatorData = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ArrayBuffer}
**/
AuthenticatorAssertionResponse.prototype.signature = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(ArrayBuffer | null)} ArrayBuffer | null
**/
AuthenticatorAssertionResponse.prototype.userHandle = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {ArrayBuffer}
**/
AuthenticatorAssertionResponse.prototype.clientDataJSON = new ArrayBuffer();

