/**


@returns {PaymentValidationErrors}
*/
PaymentValidationErrors = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
PaymentValidationErrors.prototype.error = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Object}
**/
PaymentValidationErrors.prototype.paymentMethod = new Object();

