/**
This Gamepad API interface represents hardware in the controller designed to provide haptic feedback to the user (if available), most commonly vibration hardware.

@returns {GamepadHapticActuator}
*/
GamepadHapticActuator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {"vibration"} GamepadHapticActuatorType
**/
GamepadHapticActuator.prototype.type = "vibration";

