/**


@returns {ElementCSSInlineStyle}
*/
ElementCSSInlineStyle = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {CSSStyleDeclaration}
**/
ElementCSSInlineStyle.prototype.style = new CSSStyleDeclaration();

