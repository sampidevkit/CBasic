/**


@returns {WebAssembly.MemoryDescriptor}
*/
WebAssembly.MemoryDescriptor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
WebAssembly.MemoryDescriptor.prototype.initial = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
WebAssembly.MemoryDescriptor.prototype.maximum = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
WebAssembly.MemoryDescriptor.prototype.shared = new Boolean();

