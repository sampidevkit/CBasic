/**


@returns {LockManagerSnapshot}
*/
LockManagerSnapshot = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {LockInfo[]}
**/
LockManagerSnapshot.prototype.held = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {LockInfo[]}
**/
LockManagerSnapshot.prototype.pending = new Array();

