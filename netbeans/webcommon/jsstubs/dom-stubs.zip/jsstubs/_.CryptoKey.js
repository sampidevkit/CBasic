/**
The CryptoKey dictionary of the Web Crypto API represents a cryptographic key.
Available only in secure contexts.

@returns {CryptoKey}
*/
CryptoKey = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyAlgorithm}
**/
CryptoKey.prototype.algorithm = new KeyAlgorithm();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Boolean}
**/
CryptoKey.prototype.extractable = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("private" | "public" | "secret")} KeyType
**/
CryptoKey.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {KeyUsage[]}
**/
CryptoKey.prototype.usages = new Array();

