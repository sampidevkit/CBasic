/**


@returns {MediaRecorderEventMap}
*/
MediaRecorderEventMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {BlobEvent}
**/
MediaRecorderEventMap.prototype["dataavailable"] = new BlobEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {MediaRecorderErrorEvent}
**/
MediaRecorderEventMap.prototype["error"] = new MediaRecorderErrorEvent();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
MediaRecorderEventMap.prototype["pause"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
MediaRecorderEventMap.prototype["resume"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
MediaRecorderEventMap.prototype["start"] = new Event();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Event}
**/
MediaRecorderEventMap.prototype["stop"] = new Event();

