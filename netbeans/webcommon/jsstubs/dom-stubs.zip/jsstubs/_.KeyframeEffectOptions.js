/**


@returns {KeyframeEffectOptions}
*/
KeyframeEffectOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("accumulate" | "add" | "replace")} CompositeOperation
**/
KeyframeEffectOptions.prototype.composite = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("accumulate" | "replace")} IterationCompositeOperation
**/
KeyframeEffectOptions.prototype.iterationComposite = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(String | null)} string | null
**/
KeyframeEffectOptions.prototype.pseudoElement = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
KeyframeEffectOptions.prototype.delay = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("alternate" | "alternate-reverse" | "normal" | "reverse")} PlaybackDirection
**/
KeyframeEffectOptions.prototype.direction = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {(Number | String)} number | string
**/
KeyframeEffectOptions.prototype.duration = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
KeyframeEffectOptions.prototype.easing = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
KeyframeEffectOptions.prototype.endDelay = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {("auto" | "backwards" | "both" | "forwards" | "none")} FillMode
**/
KeyframeEffectOptions.prototype.fill = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
KeyframeEffectOptions.prototype.iterationStart = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
KeyframeEffectOptions.prototype.iterations = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
KeyframeEffectOptions.prototype.playbackRate = new Number();

