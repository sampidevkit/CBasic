/**


@returns {AesKeyAlgorithm}
*/
AesKeyAlgorithm = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {Number}
**/
AesKeyAlgorithm.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.dom.d.ts
/**


@returns {String}
**/
AesKeyAlgorithm.prototype.name = new String();

