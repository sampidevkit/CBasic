//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new RegExp(pattern: String)
@example new RegExp(pattern: String, flags: String)
@example new RegExp(pattern: RegExp | string)
@example new RegExp(pattern: RegExp | string, flags: String)
@example new RegExp(pattern: RegExp | string)

@param {String} pattern
@param {String} [flags]
@returns {RegExp}
**/
RegExp = function(pattern) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Executes a search on a string using a regular expression pattern, and returns an array containing the results of that search.

@param {String} string The String object or string literal on which to perform the search.
@returns {(RegExpExecArray | null)} RegExpExecArray | null
**/
RegExp.prototype.exec = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a Boolean value that indicates whether or not a pattern exists in a searched string.

@param {String} string String on which to perform the search.
@returns {Boolean}
**/
RegExp.prototype.test = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.prototype.source = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
RegExp.prototype.global = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
RegExp.prototype.ignoreCase = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
RegExp.prototype.multiline = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
RegExp.prototype.lastIndex = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {String} pattern
@param {String} [flags]
@returns {RegExp}
**/
RegExp.prototype.compile = function(pattern) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {String}
**/
RegExp.prototype.flags = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {Boolean}
**/
RegExp.prototype.sticky = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {Boolean}
**/
RegExp.prototype.unicode = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Matches a string with this regular expression, and returns an array containing the results of
that search.

@param {String} string A string to search within.
@returns {(RegExpMatchArray | null)} RegExpMatchArray | null
**/
RegExp.prototype[Symbol.match] = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Replaces text in a string, using this regular expression.

@param {String} string A String object or string literal whose contents matching against
this regular expression will be replaced
@param {Function} replacer (substring: string, ...args: any[]) => string - A function that returns the replacement text.
@returns {String}
**/
RegExp.prototype[Symbol.replace] = function(string, replacer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Finds the position beginning first substring match in a regular expression search
using this regular expression.

@param {String} string The string to search within.
@returns {Number}
**/
RegExp.prototype[Symbol.search] = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Returns an array of substrings that were delimited by strings in the original input that
match against this regular expression.

If the regular expression contains capturing parentheses, then each time this
regular expression matches, the results (including any undefined results) of the
capturing parentheses are spliced.

@param {String} string string value to split
@param {Number} [limit] if not undefined, the output array is truncated so that it contains no more
than 'limit' elements.
@returns {String}
**/
RegExp.prototype[Symbol.split] = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.regexp.d.ts
/**


@returns {Boolean}
**/
RegExp.prototype.dotAll = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.symbol.wellknown.d.ts
/**
Matches a string with this regular expression, and returns an iterable of matches
containing the results of that search.

@param {String} str
@returns {IterableIterator}
**/
RegExp.prototype[Symbol.matchAll] = function(str) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$1 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$2 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$3 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$4 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$5 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$6 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$7 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$8 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$9 = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.input = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.$_ = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.lastMatch = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp["$&"] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.lastParen = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp["$+"] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.leftContext = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp["$`"] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp.rightContext = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
RegExp["$'"] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {RegExpConstructor}
**/
RegExp[Symbol.species] = new RegExpConstructor();

