/**


@returns {ReadonlyArray}
*/
ReadonlyArray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
ReadonlyArray.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an array.

@returns {String}
**/
ReadonlyArray.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an array. The elements are converted to string using their toLocaleString methods.

@returns {String}
**/
ReadonlyArray.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Combines two or more arrays.

@param {(Object | ConcatArray)} items (T | ConcatArray<T>)[] - Additional items to add to the end of array1.
@returns {T[]}
**/
ReadonlyArray.prototype.concat = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Adds all the elements of an array separated by the specified separator string.

@param {String} [separator] A string used to separate one element of an array from the next in the resulting String. If omitted, the array elements are separated with a comma.
@returns {String}
**/
ReadonlyArray.prototype.join = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a section of an array.

@param {Number} [start] The beginning of the specified portion of the array.
@param {Number} [end] The end of the specified portion of the array. This is exclusive of the element at the index 'end'.
@returns {T[]}
**/
ReadonlyArray.prototype.slice = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the first occurrence of a value in an array.

@param {Object} searchElement T - The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the search starts at index 0.
@returns {Number}
**/
ReadonlyArray.prototype.indexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the last occurrence of a specified value in an array.

@param {Object} searchElement T - The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the search starts at the last index in the array.
@returns {Number}
**/
ReadonlyArray.prototype.lastIndexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether all the members of an array satisfy the specified test.

@param {Function} predicate (value: T, index: number, array: readonly T[]) => unknown - A function that accepts up to three arguments. The every method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value false, or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
ReadonlyArray.prototype.every = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether the specified callback function returns true for any element of an array.

@param {Function} predicate (value: T, index: number, array: readonly T[]) => unknown - A function that accepts up to three arguments. The some method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value true, or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
ReadonlyArray.prototype.some = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Performs the specified action for each element in an array.

@param {Function} callbackfn (value: T, index: number, array: readonly T[]) => void - A function that accepts up to three arguments. forEach calls the callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
@returns {undefined}
**/
ReadonlyArray.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls a defined callback function on each element of an array, and returns an array that contains the results.

@param {Function} callbackfn (value: T, index: number, array: readonly T[]) => U - A function that accepts up to three arguments. The map method calls the callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
@returns {U[]}
**/
ReadonlyArray.prototype.map = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the elements of an array that meet the condition specified in a callback function.

@param {Function} predicate (value: T, index: number, array: readonly T[]) => unknown - A function that accepts up to three arguments. The filter method calls the predicate function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function. If thisArg is omitted, undefined is used as the this value.
@returns {T[]}
**/
ReadonlyArray.prototype.filter = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the specified callback function for all the elements in an array. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: T, currentIndex: number, array: readonly T[]) => U - A function that accepts up to four arguments. The reduce method calls the callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.
@returns {Object} U
**/
ReadonlyArray.prototype.reduce = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the specified callback function for all the elements in an array, in descending order. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: T, currentIndex: number, array: readonly T[]) => U - A function that accepts up to four arguments. The reduceRight method calls the callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.
@returns {Object} U
**/
ReadonlyArray.prototype.reduceRight = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the value of the first element in the array where predicate is true, and undefined
otherwise.

@param {Function} predicate (value: T, index: number, obj: readonly T[]) => unknown
@param {Object} [thisArg]
@returns {(Object | undefined)} T | undefined
**/
ReadonlyArray.prototype.find = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the index of the first element in the array where predicate is true, and -1
otherwise.

@param {Function} predicate (value: T, index: number, obj: readonly T[]) => unknown - find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found,
findIndex immediately returns that element index. Otherwise, findIndex returns -1.
@param {Object} [thisArg] If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.
@returns {Number}
**/
ReadonlyArray.prototype.findIndex = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Iterator of values in the array.

@returns {IterableIterator}
**/
ReadonlyArray.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of key, value pairs for every entry in the array

@returns {IterableIterator}
**/
ReadonlyArray.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of keys in the array

@returns {IterableIterator}
**/
ReadonlyArray.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the array

@returns {IterableIterator}
**/
ReadonlyArray.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2016.array.include.d.ts
/**
Determines whether an array includes a certain element, returning true or false as appropriate.

@param {Object} searchElement T - The element to search for.
@param {Number} [fromIndex] The position in this array at which to begin searching for searchElement.
@returns {Boolean}
**/
ReadonlyArray.prototype.includes = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.array.d.ts
/**
Calls a defined callback function on each element of an array. Then, flattens the result into
a new array.
This is identical to a map followed by flat with depth 1.

@param {Function} callback (this: This, value: T, index: number, array: T[]) => U | ReadonlyArray<U> - A function that accepts up to three arguments. The flatMap method calls the
callback function one time for each element in the array.
@param {Object} [thisArg] This - An object to which the this keyword can refer in the callback function. If
thisArg is omitted, undefined is used as the this value.
@returns {U[]}
**/
ReadonlyArray.prototype.flatMap = function(callback) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.array.d.ts
/**
Returns a new array with all sub-array elements concatenated into it recursively up to the
specified depth.

@param {Object} [depth] D - The maximum recursion depth
@returns {FlatArray[]} FlatArray<A, D>[]
**/
ReadonlyArray.prototype.flat = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.array.d.ts
/**
Returns the item located at the specified index.

@param {Number} index The zero-based index of the desired code unit. A negative index will count back from the last item.
@returns {(Object | undefined)} T | undefined
**/
ReadonlyArray.prototype.at = function(index) {};

