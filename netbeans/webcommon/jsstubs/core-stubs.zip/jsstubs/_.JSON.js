/**


@returns {JSON}
*/
JSON = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts a JavaScript Object Notation (JSON) string into an object.

@param {String} text A valid JSON string.
@param {Function} [reviver] (this: any, key: string, value: any) => any - A function that transforms the results. This function is called for each member of the object.
If a member contains nested objects, the nested objects are transformed before the parent object is.
@returns {Object}
**/
JSON.prototype.parse = function(text) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts a JavaScript value to a JavaScript Object Notation (JSON) string.

@param {Object} value A JavaScript value, usually an object or array, to be converted.
@param {(Number | String | null)} [replacer] (number | string)[] | null - An array of strings and numbers that acts as an approved list for selecting the object properties that will be stringified.
@param {(String | Number)} [space] string | number - Adds indentation, white space, and line break characters to the return-value JSON text to make it easier to read.
@returns {String}
**/
JSON.prototype.stringify = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
JSON.prototype[Symbol.toStringTag] = new String();

