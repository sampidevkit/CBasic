/**


@returns {ConcatArray}
*/
ConcatArray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
ConcatArray.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {String} [separator]
@returns {String}
**/
ConcatArray.prototype.join = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {Number} [start]
@param {Number} [end]
@returns {T[]}
**/
ConcatArray.prototype.slice = function() {};

