//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
NaN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Infinity = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Evaluates JavaScript code and executes it.

@param {String} x A String value that contains valid JavaScript code.
@returns {Object}
**/
eval = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts a string to an integer.

@param {String} string A string to convert into a number.
@param {Number} [radix] A value between 2 and 36 that specifies the base of the number in `string`.
If this argument is not supplied, strings with a prefix of '0x' are considered hexadecimal.
All other strings are considered decimal.
@returns {Number}
**/
parseInt = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts a string to a floating-point number.

@param {String} string A string that contains a floating-point number.
@returns {Number}
**/
parseFloat = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a Boolean value that indicates whether a value is the reserved value NaN (not a number).

@param {Number} number A numeric value.
@returns {Boolean}
**/
isNaN = function(number) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether a supplied number is finite.

@param {Number} number Any numeric value.
@returns {Boolean}
**/
isFinite = function(number) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the unencoded version of an encoded Uniform Resource Identifier (URI).

@param {String} encodedURI A value representing an encoded URI.
@returns {String}
**/
decodeURI = function(encodedURI) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the unencoded version of an encoded component of a Uniform Resource Identifier (URI).

@param {String} encodedURIComponent A value representing an encoded URI component.
@returns {String}
**/
decodeURIComponent = function(encodedURIComponent) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Encodes a text string as a valid Uniform Resource Identifier (URI)

@param {String} uri A value representing an encoded URI.
@returns {String}
**/
encodeURI = function(uri) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Encodes a text string as a valid component of a Uniform Resource Identifier (URI).

@param {(String | Number | Boolean)} uriComponent string | number | boolean - A value representing an encoded URI component.
@returns {String}
**/
encodeURIComponent = function(uriComponent) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Computes a new string in which certain characters have been replaced by a hexadecimal escape sequence.

@param {String} string A string value
@returns {String}
**/
escape = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Computes a new string in which hexadecimal escape sequences are replaced with the character that it represents.

@param {String} string A string value
@returns {String}
**/
unescape = function(string) {};

