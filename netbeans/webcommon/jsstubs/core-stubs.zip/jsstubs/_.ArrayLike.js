/**


@returns {ArrayLike}
*/
ArrayLike = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
ArrayLike.prototype.length = new Number();

