/**


@returns {ErrorOptions}
*/
ErrorOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
ErrorOptions.prototype.cause = new Error();

