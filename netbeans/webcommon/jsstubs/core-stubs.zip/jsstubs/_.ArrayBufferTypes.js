/**


@returns {ArrayBufferTypes}
*/
ArrayBufferTypes = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ArrayBuffer}
**/
ArrayBufferTypes.prototype.ArrayBuffer = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**


@returns {SharedArrayBuffer}
**/
ArrayBufferTypes.prototype.SharedArrayBuffer = new SharedArrayBuffer();

