//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new DataView(buffer: ArrayBufferLike)
@example new DataView(buffer: ArrayBufferLike, byteOffset: Number)
@example new DataView(buffer: ArrayBufferLike, byteOffset: Number, byteLength: Number)

@param {ArrayBuffer} buffer ArrayBufferLike
@param {Number} [byteOffset]
@param {Number} [byteLength]
@returns {DataView}
**/
DataView = function(buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ArrayBuffer}
**/
DataView.prototype.buffer = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
DataView.prototype.byteLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
DataView.prototype.byteOffset = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Float32 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {Number}
**/
DataView.prototype.getFloat32 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Float64 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {Number}
**/
DataView.prototype.getFloat64 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Int8 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@returns {Number}
**/
DataView.prototype.getInt8 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Int16 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {Number}
**/
DataView.prototype.getInt16 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Int32 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {Number}
**/
DataView.prototype.getInt32 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Uint8 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@returns {Number}
**/
DataView.prototype.getUint8 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Uint16 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {Number}
**/
DataView.prototype.getUint16 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the Uint32 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {Number}
**/
DataView.prototype.getUint32 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Float32 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setFloat32 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Float64 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setFloat64 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Int8 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@returns {undefined}
**/
DataView.prototype.setInt8 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Int16 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setInt16 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Int32 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setInt32 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Uint8 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@returns {undefined}
**/
DataView.prototype.setUint8 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Uint16 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setUint16 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Stores an Uint32 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {Number} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setUint32 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
DataView.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Gets the BigInt64 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {BigInt}
**/
DataView.prototype.getBigInt64 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Gets the BigUint64 value at the specified byte offset from the start of the view. There is
no alignment constraint; multi-byte values may be fetched from any offset.

@param {Number} byteOffset The place in the buffer at which the value should be retrieved.
@param {Boolean} [littleEndian]
@returns {BigInt}
**/
DataView.prototype.getBigUint64 = function(byteOffset) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Stores a BigInt64 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {BigInt} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setBigInt64 = function(byteOffset, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Stores a BigUint64 value at the specified byte offset from the start of the view.

@param {Number} byteOffset The place in the buffer at which the value should be set.
@param {BigInt} value The value to set.
@param {Boolean} [littleEndian] If false or undefined, a big-endian value should be written,
otherwise a little-endian value should be written.
@returns {undefined}
**/
DataView.prototype.setBigUint64 = function(byteOffset, value) {};

