/**
An object with properties reflecting the locale
and formatting options computed during initialization
of the `Intl.RelativeTimeFormat` object

[MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/RelativeTimeFormat/resolvedOptions#Description).

@returns {Intl.ResolvedRelativeTimeFormatOptions}
*/
Intl.ResolvedRelativeTimeFormatOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String} UnicodeBCP47LocaleIdentifier
**/
Intl.ResolvedRelativeTimeFormatOptions.prototype.locale = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("long" | "short" | "narrow")} RelativeTimeFormatStyle
**/
Intl.ResolvedRelativeTimeFormatOptions.prototype.style = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("always" | "auto")} RelativeTimeFormatNumeric
**/
Intl.ResolvedRelativeTimeFormatOptions.prototype.numeric = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.ResolvedRelativeTimeFormatOptions.prototype.numberingSystem = new String();

