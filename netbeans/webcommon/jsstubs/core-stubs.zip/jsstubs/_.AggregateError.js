//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@example new AggregateError(errors: Iterable)
@example new AggregateError(errors: Iterable, message: String)
@example new AggregateError(errors: Iterable, message: String, options: ErrorOptions)
@example new AggregateError(errors: Iterable)
@example new AggregateError(errors: Iterable, message: String)

@param {Iterable} errors Iterable
@param {String} [message]
@param {ErrorOptions} [options] ErrorOptions
@returns {AggregateError}
**/
AggregateError = function(errors) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.promise.d.ts
/**


@returns {Object}
**/
AggregateError.prototype.errors = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
AggregateError.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
AggregateError.prototype.message = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
AggregateError.prototype.stack = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
AggregateError.prototype.cause = new Error();

