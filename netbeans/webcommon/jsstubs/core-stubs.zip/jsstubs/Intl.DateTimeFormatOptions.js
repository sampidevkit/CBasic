/**


@returns {Intl.DateTimeFormatOptions}
*/
Intl.DateTimeFormatOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("best fit" | "lookup" | undefined)} "best fit" | "lookup" | undefined
**/
Intl.DateTimeFormatOptions.prototype.localeMatcher = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("long" | "short" | "narrow" | undefined)} "long" | "short" | "narrow" | undefined
**/
Intl.DateTimeFormatOptions.prototype.weekday = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("long" | "short" | "narrow" | undefined)} "long" | "short" | "narrow" | undefined
**/
Intl.DateTimeFormatOptions.prototype.era = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("numeric" | "2-digit" | undefined)} "numeric" | "2-digit" | undefined
**/
Intl.DateTimeFormatOptions.prototype.year = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("numeric" | "2-digit" | "long" | "short" | "narrow" | undefined)} "numeric" | "2-digit" | "long" | "short" | "narrow" | undefined
**/
Intl.DateTimeFormatOptions.prototype.month = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("numeric" | "2-digit" | undefined)} "numeric" | "2-digit" | undefined
**/
Intl.DateTimeFormatOptions.prototype.day = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("numeric" | "2-digit" | undefined)} "numeric" | "2-digit" | undefined
**/
Intl.DateTimeFormatOptions.prototype.hour = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("numeric" | "2-digit" | undefined)} "numeric" | "2-digit" | undefined
**/
Intl.DateTimeFormatOptions.prototype.minute = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("numeric" | "2-digit" | undefined)} "numeric" | "2-digit" | undefined
**/
Intl.DateTimeFormatOptions.prototype.second = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {("long" | "short" | undefined)} "long" | "short" | undefined
**/
Intl.DateTimeFormatOptions.prototype.timeZoneName = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("basic" | "best fit" | "best fit" | undefined)} "basic" | "best fit" | "best fit" | undefined
**/
Intl.DateTimeFormatOptions.prototype.formatMatcher = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Boolean | undefined)} boolean | undefined
**/
Intl.DateTimeFormatOptions.prototype.hour12 = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.DateTimeFormatOptions.prototype.timeZone = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.DateTimeFormatOptions.prototype.calendar = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("narrow" | "short" | "long" | undefined)} "narrow" | "short" | "long" | undefined
**/
Intl.DateTimeFormatOptions.prototype.dayPeriod = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.DateTimeFormatOptions.prototype.numberingSystem = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("full" | "long" | "medium" | "short" | undefined)} "full" | "long" | "medium" | "short" | undefined
**/
Intl.DateTimeFormatOptions.prototype.dateStyle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("full" | "long" | "medium" | "short" | undefined)} "full" | "long" | "medium" | "short" | undefined
**/
Intl.DateTimeFormatOptions.prototype.timeStyle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("h11" | "h12" | "h23" | "h24" | undefined)} "h11" | "h12" | "h23" | "h24" | undefined
**/
Intl.DateTimeFormatOptions.prototype.hourCycle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {(0 | 1 | 2 | 3 | undefined)} 0 | 1 | 2 | 3 | undefined
**/
Intl.DateTimeFormatOptions.prototype.fractionalSecondDigits = new Object();

