/**


@returns {Iterable}
*/
Iterable = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {Iterator}
**/
Iterable.prototype[Symbol.iterator] = function() {};

