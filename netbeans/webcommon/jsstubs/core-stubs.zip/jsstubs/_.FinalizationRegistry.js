//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**


@example new FinalizationRegistry(cleanupCallback: (heldValue: T) => void)

@param {Function} cleanupCallback (heldValue: T) => void - The callback to call after an object in the registry has been reclaimed.
@returns {FinalizationRegistry}
**/
FinalizationRegistry = function(cleanupCallback) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**


@returns {"FinalizationRegistry"}
**/
FinalizationRegistry.prototype[Symbol.toStringTag] = "FinalizationRegistry";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**
Registers an object with the registry.

@param {Object} target The target object to register.
@param {Object} heldValue T - The value to pass to the finalizer for this object. This cannot be the
target object.
@param {Object} [unregisterToken] The token to pass to the unregister method to unregister the target
object. If provided (and not undefined), this must be an object. If not provided, the target
cannot be unregistered.
@returns {undefined}
**/
FinalizationRegistry.prototype.register = function(target, heldValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**
Unregisters an object from the registry.

@param {Object} unregisterToken The token that was used as the unregisterToken argument when calling
register to register the target object.
@returns {undefined}
**/
FinalizationRegistry.prototype.unregister = function(unregisterToken) {};

