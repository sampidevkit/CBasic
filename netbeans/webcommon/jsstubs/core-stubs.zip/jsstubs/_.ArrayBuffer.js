//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new ArrayBuffer(byteLength: Number)

@param {Number} byteLength
@returns {ArrayBuffer}
**/
ArrayBuffer = function(byteLength) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
ArrayBuffer.prototype.byteLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a section of an ArrayBuffer.

@param {Number} begin
@param {Number} [end]
@returns {ArrayBuffer}
**/
ArrayBuffer.prototype.slice = function(begin) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
ArrayBuffer.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {Object} arg
@returns {Boolean} arg is ArrayBufferView
**/
ArrayBuffer.isView = function(arg) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {ArrayBufferConstructor}
**/
ArrayBuffer[Symbol.species] = new ArrayBufferConstructor();

