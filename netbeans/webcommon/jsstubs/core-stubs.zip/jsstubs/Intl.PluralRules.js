/**


@returns {Intl.PluralRules}
*/
Intl.PluralRules = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {ResolvedPluralRulesOptions}
**/
Intl.PluralRules.prototype.resolvedOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@param {Number} n
@returns {("zero" | "one" | "two" | "few" | "many" | "other")} LDMLPluralRule
**/
Intl.PluralRules.prototype.select = function(n) {};

