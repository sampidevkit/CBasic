/**


@returns {PromiseLike}
*/
PromiseLike = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Attaches callbacks for the resolution and/or rejection of the Promise.

@param {(Function | undefined | null)} [onfulfilled] ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null - The callback to execute when the Promise is resolved.
@param {(Function | undefined | null)} [onrejected] ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null - The callback to execute when the Promise is rejected.
@returns {PromiseLike}
**/
PromiseLike.prototype.then = function() {};

