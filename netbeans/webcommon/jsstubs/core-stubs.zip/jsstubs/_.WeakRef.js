//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**


@example new WeakRef(target: T)

@param {Object} target T - The target object for the WeakRef instance.
@returns {WeakRef}
**/
WeakRef = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**


@returns {"WeakRef"}
**/
WeakRef.prototype[Symbol.toStringTag] = "WeakRef";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.weakref.d.ts
/**
Returns the WeakRef instance's target object, or undefined if the target object has been
reclaimed.

@returns {(Object | undefined)} T | undefined
**/
WeakRef.prototype.deref = function() {};

