/**


@returns {Iterator}
*/
Iterator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@param {(Object | Object)} args [] | [TNext]
@returns {(IteratorYieldResult | IteratorReturnResult)} IteratorResult
**/
Iterator.prototype.next = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@param {Object} [value] TReturn
@returns {(IteratorYieldResult | IteratorReturnResult)} IteratorResult
**/
Iterator.prototype.return = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@param {Object} [e]
@returns {(IteratorYieldResult | IteratorReturnResult)} IteratorResult
**/
Iterator.prototype.throw = function() {};

