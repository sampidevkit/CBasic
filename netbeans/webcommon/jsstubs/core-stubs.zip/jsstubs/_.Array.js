//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new Array()
@example new Array(arrayLength: Number)
@example new Array(arrayLength: Number)
@example new Array(items: T[])

@param {Number} [arrayLength]
@returns {Array}
**/
Array = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Array.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an array.

@returns {String}
**/
Array.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an array. The elements are converted to string using their toLocaleString methods.

@returns {String}
**/
Array.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Removes the last element from an array and returns it.
If the array is empty, undefined is returned and the array is not modified.

@returns {(Object | undefined)} T | undefined
**/
Array.prototype.pop = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Appends new elements to the end of an array, and returns the new length of the array.

@param {T[]} items T[] - New elements to add to the array.
@returns {Number}
**/
Array.prototype.push = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Combines two or more arrays.
This method returns a new array without modifying any existing arrays.

@param {(Object | ConcatArray)} items (T | ConcatArray<T>)[] - Additional arrays and/or items to add to the end of the array.
@returns {T[]}
**/
Array.prototype.concat = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Adds all the elements of an array into a string, separated by the specified separator string.

@param {String} [separator] A string used to separate one element of the array from the next in the resulting string. If omitted, the array elements are separated with a comma.
@returns {String}
**/
Array.prototype.join = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Reverses the elements in an array in place.
This method mutates the array and returns a reference to the same array.

@returns {T[]}
**/
Array.prototype.reverse = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Removes the first element from an array and returns it.
If the array is empty, undefined is returned and the array is not modified.

@returns {(Object | undefined)} T | undefined
**/
Array.prototype.shift = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a copy of a section of an array.
For both start and end, a negative index can be used to indicate an offset from the end of the array.
For example, -2 refers to the second to last element of the array.

@param {Number} [start] The beginning index of the specified portion of the array.
If start is undefined, then the slice begins at index 0.
@param {Number} [end] The end index of the specified portion of the array. This is exclusive of the element at the index 'end'.
If end is undefined, then the slice extends to the end of the array.
@returns {T[]}
**/
Array.prototype.slice = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sorts an array in place.
This method mutates the array and returns a reference to the same array.

@param {Function} [compareFn] (a: T, b: T) => number - Function used to determine the order of the elements. It is expected to return
a negative value if the first argument is less than the second argument, zero if they're equal, and a positive
value otherwise. If omitted, the elements are sorted in ascending, ASCII character order.
```ts
[11,2,22,1].sort((a, b) => a - b)
```
@returns {Array}
**/
Array.prototype.sort = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Removes elements from an array and, if necessary, inserts new elements in their place, returning the deleted elements.

@param {Number} start The zero-based location in the array from which to start removing elements.
@param {Number} deleteCount The number of elements to remove.
@param {T[]} items T[] - Elements to insert into the array in place of the deleted elements.
@returns {T[]}
**/
Array.prototype.splice = function(start, deleteCount, items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Inserts new elements at the start of an array, and returns the new length of the array.

@param {T[]} items T[] - Elements to insert at the start of the array.
@returns {Number}
**/
Array.prototype.unshift = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the first occurrence of a value in an array, or -1 if it is not present.

@param {Object} searchElement T - The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the search starts at index 0.
@returns {Number}
**/
Array.prototype.indexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the last occurrence of a specified value in an array, or -1 if it is not present.

@param {Object} searchElement T - The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin searching backward. If fromIndex is omitted, the search starts at the last index in the array.
@returns {Number}
**/
Array.prototype.lastIndexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether all the members of an array satisfy the specified test.

@param {Function} predicate (value: T, index: number, array: T[]) => unknown - A function that accepts up to three arguments. The every method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value false, or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
Array.prototype.every = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether the specified callback function returns true for any element of an array.

@param {Function} predicate (value: T, index: number, array: T[]) => unknown - A function that accepts up to three arguments. The some method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value true, or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
Array.prototype.some = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Performs the specified action for each element in an array.

@param {Function} callbackfn (value: T, index: number, array: T[]) => void - A function that accepts up to three arguments. forEach calls the callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
@returns {undefined}
**/
Array.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls a defined callback function on each element of an array, and returns an array that contains the results.

@param {Function} callbackfn (value: T, index: number, array: T[]) => U - A function that accepts up to three arguments. The map method calls the callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function. If thisArg is omitted, undefined is used as the this value.
@returns {U[]}
**/
Array.prototype.map = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the elements of an array that meet the condition specified in a callback function.

@param {Function} predicate (value: T, index: number, array: T[]) => unknown - A function that accepts up to three arguments. The filter method calls the predicate function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function. If thisArg is omitted, undefined is used as the this value.
@returns {T[]}
**/
Array.prototype.filter = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the specified callback function for all the elements in an array. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: T, currentIndex: number, array: T[]) => U - A function that accepts up to four arguments. The reduce method calls the callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.
@returns {Object} U
**/
Array.prototype.reduce = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the specified callback function for all the elements in an array, in descending order. The return value of the callback function is the accumulated result, and is provided as an argument in the next call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: T, currentIndex: number, array: T[]) => U - A function that accepts up to four arguments. The reduceRight method calls the callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start the accumulation. The first call to the callbackfn function provides this value as an argument instead of an array value.
@returns {Object} U
**/
Array.prototype.reduceRight = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the value of the first element in the array where predicate is true, and undefined
otherwise.

@param {Function} predicate (value: T, index: number, obj: T[]) => unknown
@param {Object} [thisArg]
@returns {(Object | undefined)} T | undefined
**/
Array.prototype.find = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the index of the first element in the array where predicate is true, and -1
otherwise.

@param {Function} predicate (value: T, index: number, obj: T[]) => unknown - find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found,
findIndex immediately returns that element index. Otherwise, findIndex returns -1.
@param {Object} [thisArg] If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.
@returns {Number}
**/
Array.prototype.findIndex = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Changes all array elements from `start` to `end` index to a static `value` and returns the modified array

@param {Object} value T - value to fill array section with
@param {Number} [start] index to start filling the array at. If start is negative, it is treated as
length+start where length is the length of the array.
@param {Number} [end] index to stop filling the array at. If end is negative, it is treated as
length+end.
@returns {Array}
**/
Array.prototype.fill = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the this object after copying a section of the array identified by start and end
to the same array starting at position target

@param {Number} target If target is negative, it is treated as length+target where length is the
length of the array.
@param {Number} start If start is negative, it is treated as length+start. If end is negative, it
is treated as length+end.
@param {Number} [end] If not specified, length of the this object is used as its default value.
@returns {Array}
**/
Array.prototype.copyWithin = function(target, start) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Iterator

@returns {IterableIterator}
**/
Array.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of key, value pairs for every entry in the array

@returns {IterableIterator}
**/
Array.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of keys in the array

@returns {IterableIterator}
**/
Array.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the array

@returns {IterableIterator}
**/
Array.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Returns an object whose properties have the value 'true'
when they will be absent when used in a 'with' statement.

@returns {Object} {
        copyWithin: boolean;
        entries: boolean;
        fill: boolean;
        find: boolean;
        findIndex: boolean;
        keys: boolean;
        values: boolean;
    }
**/
Array.prototype[Symbol.unscopables] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2016.array.include.d.ts
/**
Determines whether an array includes a certain element, returning true or false as appropriate.

@param {Object} searchElement T - The element to search for.
@param {Number} [fromIndex] The position in this array at which to begin searching for searchElement.
@returns {Boolean}
**/
Array.prototype.includes = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.array.d.ts
/**
Calls a defined callback function on each element of an array. Then, flattens the result into
a new array.
This is identical to a map followed by flat with depth 1.

@param {Function} callback (this: This, value: T, index: number, array: T[]) => U | ReadonlyArray<U> - A function that accepts up to three arguments. The flatMap method calls the
callback function one time for each element in the array.
@param {Object} [thisArg] This - An object to which the this keyword can refer in the callback function. If
thisArg is omitted, undefined is used as the this value.
@returns {U[]}
**/
Array.prototype.flatMap = function(callback) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.array.d.ts
/**
Returns a new array with all sub-array elements concatenated into it recursively up to the
specified depth.

@param {Object} [depth] D - The maximum recursion depth
@returns {FlatArray[]} FlatArray<A, D>[]
**/
Array.prototype.flat = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.array.d.ts
/**
Returns the item located at the specified index.

@param {Number} index The zero-based index of the desired code unit. A negative index will count back from the last item.
@returns {(Object | undefined)} T | undefined
**/
Array.prototype.at = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {Object} arg
@returns {Boolean} arg is any[]
**/
Array.isArray = function(arg) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Creates an array from an iterable object.

@param {(Iterable | ArrayLike)} iterable Iterable<T> | ArrayLike<T> - An iterable object to convert to an array.
@param {Function} mapfn (v: T, k: number) => U - A mapping function to call on every element of the array.
@param {Object} [thisArg] Value of 'this' used to invoke the mapfn.
@returns {U[]}
**/
Array.from = function(iterable, mapfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a new array from a set of elements.

@param {T[]} items T[] - A set of elements to include in the new array object.
@returns {T[]}
**/
Array.of = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {ArrayConstructor}
**/
Array[Symbol.species] = new ArrayConstructor();

