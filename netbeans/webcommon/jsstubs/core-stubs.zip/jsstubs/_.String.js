//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new String()
@example new String(value: Object)

@param {Object} [value]
@returns {String}
**/
String = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of a string.

@returns {String}
**/
String.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the character at the specified index.

@param {Number} pos The zero-based index of the desired character.
@returns {String}
**/
String.prototype.charAt = function(pos) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the Unicode value of the character at the specified location.

@param {Number} index The zero-based index of the desired character. If there is no character at the specified index, NaN is returned.
@returns {Number}
**/
String.prototype.charCodeAt = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string that contains the concatenation of two or more strings.

@param {String} strings The strings to append to the end of the string.
@returns {String}
**/
String.prototype.concat = function(strings) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the position of the first occurrence of a substring.

@param {String} searchString The substring to search for in the string
@param {Number} [position] The index at which to begin searching the String object. If omitted, search starts at the beginning of the string.
@returns {Number}
**/
String.prototype.indexOf = function(searchString) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the last occurrence of a substring in the string.

@param {String} searchString The substring to search for.
@param {Number} [position] The index at which to begin searching. If omitted, the search begins at the end of the string.
@returns {Number}
**/
String.prototype.lastIndexOf = function(searchString) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether two strings are equivalent in the current locale.
Determines whether two strings are equivalent in the current or specified locale.

@param {String} that String to compare to target string
@param {(String | String)} [locales] string | string[] - A locale string or array of locale strings that contain one or more language or locale tags. If you include more than one locale string, list them in descending order of priority so that the first entry is the preferred locale. If you omit this parameter, the default locale of the JavaScript runtime is used. This parameter must conform to BCP 47 standards; see the Intl.Collator object for details.
@param {Intl.CollatorOptions} [options] Intl.CollatorOptions - An object that contains one or more properties that specify comparison options. see the Intl.Collator object for details.
@returns {Number}
**/
String.prototype.localeCompare = function(that) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Matches a string or an object that supports being matched against, and returns an array
containing the results of that search, or null if no matches are found.

@param {Object} matcher { [Symbol.match](string: string): RegExpMatchArray | null; } - An object that supports being matched against.
@returns {(RegExpMatchArray | null)} RegExpMatchArray | null
**/
String.prototype.match = function(matcher) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Replaces first match with string or all matches with RegExp.
Replaces text in a string, using an object that supports replacement within a string.

@param {Object} searchValue { [Symbol.replace](string: string, replacer: (substring: string, ...args: any[]) => string): string; } - A object can search for and replace matches within a string.
@param {Function} replacer (substring: string, ...args: any[]) => string - A function that returns the replacement text.
@returns {String}
**/
String.prototype.replace = function(searchValue, replacer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Finds the first substring match in a regular expression search.

@param {Object} searcher { [Symbol.search](string: string): number; } - An object which supports searching within a string.
@returns {Number}
**/
String.prototype.search = function(searcher) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a section of a string.

@param {Number} [start] The index to the beginning of the specified portion of stringObj.
@param {Number} [end] The index to the end of the specified portion of stringObj. The substring includes the characters up to, but not including, the character indicated by end.
If this value is not specified, the substring continues to the end of stringObj.
@returns {String}
**/
String.prototype.slice = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Split a string into substrings using the specified separator and return them as an array.

@param {Object} splitter { [Symbol.split](string: string, limit?: number): string[]; } - An object that can split a string.
@param {Number} [limit] A value used to limit the number of elements returned in the array.
@returns {String}
**/
String.prototype.split = function(splitter) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the substring at the specified location within a String object.

@param {Number} start The zero-based index number indicating the beginning of the substring.
@param {Number} [end] Zero-based index number indicating the end of the substring. The substring includes the characters up to, but not including, the character indicated by end.
If end is omitted, the characters from start through the end of the original string are returned.
@returns {String}
**/
String.prototype.substring = function(start) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts all the alphabetic characters in a string to lowercase.

@returns {String}
**/
String.prototype.toLowerCase = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts all alphabetic characters to lowercase, taking into account the host environment's current locale.

@param {(String | String)} [locales] string | string[]
@returns {String}
**/
String.prototype.toLocaleLowerCase = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts all the alphabetic characters in a string to uppercase.

@returns {String}
**/
String.prototype.toUpperCase = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string where all alphabetic characters have been converted to uppercase, taking into account the host environment's current locale.

@param {(String | String)} [locales] string | string[]
@returns {String}
**/
String.prototype.toLocaleUpperCase = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Removes the leading and trailing white space and line terminator characters from a string.

@returns {String}
**/
String.prototype.trim = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
String.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets a substring beginning at the specified location and having the specified length.

@param {Number} from The starting position of the desired substring. The index of the first character in the string is zero.
@param {Number} [length] The number of characters to include in the returned substring.
@returns {String}
**/
String.prototype.substr = function(from) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the primitive value of the specified object.

@returns {String}
**/
String.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a nonnegative integer Number less than 1114112 (0x110000) that is the code point
value of the UTF-16 encoded code point starting at the string element at position pos in
the String resulting from converting this object to a String.
If there is no element at that position, the result is undefined.
If a valid UTF-16 surrogate pair does not begin at pos, the result is the code unit at pos.

@param {Number} pos
@returns {(Number | undefined)} number | undefined
**/
String.prototype.codePointAt = function(pos) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if searchString appears as a substring of the result of converting this
object to a String, at one or more positions that are
greater than or equal to position; otherwise, returns false.

@param {String} searchString search string
@param {Number} [position] If position is undefined, 0 is assumed, so as to search all of the String.
@returns {Boolean}
**/
String.prototype.includes = function(searchString) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if the sequence of elements of searchString converted to a String is the
same as the corresponding elements of this object (converted to a String) starting at
endPosition – length(this). Otherwise returns false.

@param {String} searchString
@param {Number} [endPosition]
@returns {Boolean}
**/
String.prototype.endsWith = function(searchString) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the String value result of normalizing the string into the normalization form
named by form as specified in Unicode Standard Annex #15, Unicode Normalization Forms.

@param {String} [form] Applicable values: "NFC", "NFD", "NFKC", or "NFKD", If not specified default
is "NFC"
@returns {String}
**/
String.prototype.normalize = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a String value that is made from count copies appended together. If count is 0,
the empty string is returned.

@param {Number} count number of copies to append
@returns {String}
**/
String.prototype.repeat = function(count) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if the sequence of elements of searchString converted to a String is the
same as the corresponding elements of this object (converted to a String) starting at
position. Otherwise returns false.

@param {String} searchString
@param {Number} [position]
@returns {Boolean}
**/
String.prototype.startsWith = function(searchString) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns an `<a>` HTML anchor element and sets the name attribute to the text value

@param {String} name
@returns {String}
**/
String.prototype.anchor = function(name) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<big>` HTML element

@returns {String}
**/
String.prototype.big = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<blink>` HTML element

@returns {String}
**/
String.prototype.blink = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<b>` HTML element

@returns {String}
**/
String.prototype.bold = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<tt>` HTML element

@returns {String}
**/
String.prototype.fixed = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<font>` HTML element and sets the color attribute value

@param {String} color
@returns {String}
**/
String.prototype.fontcolor = function(color) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<font>` HTML element and sets the size attribute value

@param {String} size
@returns {String}
**/
String.prototype.fontsize = function(size) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns an `<i>` HTML element

@returns {String}
**/
String.prototype.italics = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns an `<a>` HTML element and sets the href attribute value

@param {String} url
@returns {String}
**/
String.prototype.link = function(url) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<small>` HTML element

@returns {String}
**/
String.prototype.small = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<strike>` HTML element

@returns {String}
**/
String.prototype.strike = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<sub>` HTML element

@returns {String}
**/
String.prototype.sub = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a `<sup>` HTML element

@returns {String}
**/
String.prototype.sup = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Iterator

@returns {IterableIterator}
**/
String.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.string.d.ts
/**
Pads the current string with a given string (possibly repeated) so that the resulting string reaches a given length.
The padding is applied from the start (left) of the current string.

@param {Number} maxLength The length of the resulting string once the current string has been padded.
If this parameter is smaller than the current string's length, the current string will be returned as it is.
@param {String} [fillString] The string to pad the current string with.
If this string is too long, it will be truncated and the left-most part will be applied.
The default value for this parameter is " " (U+0020).
@returns {String}
**/
String.prototype.padStart = function(maxLength) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.string.d.ts
/**
Pads the current string with a given string (possibly repeated) so that the resulting string reaches a given length.
The padding is applied from the end (right) of the current string.

@param {Number} maxLength The length of the resulting string once the current string has been padded.
If this parameter is smaller than the current string's length, the current string will be returned as it is.
@param {String} [fillString] The string to pad the current string with.
If this string is too long, it will be truncated and the left-most part will be applied.
The default value for this parameter is " " (U+0020).
@returns {String}
**/
String.prototype.padEnd = function(maxLength) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.string.d.ts
/**
Removes the trailing white space and line terminator characters from a string.

@returns {String}
**/
String.prototype.trimEnd = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.string.d.ts
/**
Removes the leading white space and line terminator characters from a string.

@returns {String}
**/
String.prototype.trimStart = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.string.d.ts
/**
Removes the leading white space and line terminator characters from a string.

@returns {String}
**/
String.prototype.trimLeft = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.string.d.ts
/**
Removes the trailing white space and line terminator characters from a string.

@returns {String}
**/
String.prototype.trimRight = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.string.d.ts
/**
Matches a string with a regular expression, and returns an iterable of matches
containing the results of that search.

@param {RegExp} regexp RegExp - A variable name or string literal containing the regular expression pattern and flags.
@returns {IterableIterator}
**/
String.prototype.matchAll = function(regexp) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.string.d.ts
/**
Replace all instances of a substring in a string, using a regular expression or search string.

@param {(String | RegExp)} searchValue string | RegExp - A string to search for.
@param {Function} replacer (substring: string, ...args: any[]) => string - A function that returns the replacement text.
@returns {String}
**/
String.prototype.replaceAll = function(searchValue, replacer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.string.d.ts
/**
Returns a new String consisting of the single UTF-16 code unit located at the specified index.

@param {Number} index The zero-based index of the desired code unit. A negative index will count back from the last item.
@returns {(String | undefined)} string | undefined
**/
String.prototype.at = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {Number} codes
@returns {String}
**/
String.fromCharCode = function(codes) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Return the String value whose elements are, in order, the elements in the List elements.
If length is 0, the empty string is returned.

@param {Number} codePoints
@returns {String}
**/
String.fromCodePoint = function(codePoints) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
String.raw is usually used as a tag function of a Tagged Template String. When called as
such, the first argument will be a well formed template call site object and the rest
parameter will contain the substitution values. It can also be called directly, for example,
to interleave strings and values from your own tag function, and in this case the only thing
it needs from the first argument is the raw property.

@param {Object} template { raw: readonly string[] | ArrayLike<string>} - A well-formed template string call site representation.
@param {Object} substitutions A set of substitution values.
@returns {String}
**/
String.raw = function(template, substitutions) {};

