//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@example new ReferenceError()
@example new ReferenceError(message: String)
@example new ReferenceError(message: String, options: ErrorOptions)
@example new ReferenceError()
@example new ReferenceError(message: String)

@param {String} [message]
@param {ErrorOptions} [options] ErrorOptions
@returns {ReferenceError}
**/
ReferenceError = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
ReferenceError.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
ReferenceError.prototype.message = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
ReferenceError.prototype.stack = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
ReferenceError.prototype.cause = new Error();

