/**


@returns {IteratorYieldResult}
*/
IteratorYieldResult = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {false}
**/
IteratorYieldResult.prototype.done = false;

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {Object} TYield
**/
IteratorYieldResult.prototype.value = new Object();

