/**


@returns {IteratorReturnResult}
*/
IteratorReturnResult = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {true}
**/
IteratorReturnResult.prototype.done = true;

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {Object} TReturn
**/
IteratorReturnResult.prototype.value = new Object();

