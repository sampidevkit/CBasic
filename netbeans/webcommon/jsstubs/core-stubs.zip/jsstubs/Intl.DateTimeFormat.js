/**


@returns {Intl.DateTimeFormat}
*/
Intl.DateTimeFormat = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {(Date | Number)} [date] Date | number
@returns {String}
**/
Intl.DateTimeFormat.prototype.format = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ResolvedDateTimeFormatOptions}
**/
Intl.DateTimeFormat.prototype.resolvedOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.intl.d.ts
/**


@param {(Date | Number)} [date] Date | number
@returns {DateTimeFormatPart[]}
**/
Intl.DateTimeFormat.prototype.formatToParts = function() {};

