/**
An object with some or all of properties of `options` parameter
of `Intl.RelativeTimeFormat` constructor.

[MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/RelativeTimeFormat/RelativeTimeFormat#Parameters).

@returns {Intl.RelativeTimeFormatOptions}
*/
Intl.RelativeTimeFormatOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("lookup" | "best fit")} RelativeTimeFormatLocaleMatcher
**/
Intl.RelativeTimeFormatOptions.prototype.localeMatcher = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("always" | "auto")} RelativeTimeFormatNumeric
**/
Intl.RelativeTimeFormatOptions.prototype.numeric = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("long" | "short" | "narrow")} RelativeTimeFormatStyle
**/
Intl.RelativeTimeFormatOptions.prototype.style = new Object();

