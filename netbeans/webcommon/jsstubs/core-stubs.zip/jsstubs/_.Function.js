//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new Function(args: String)

@param {String} args A list of arguments the function accepts.
@returns {Function}
**/
Function = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the function, substituting the specified object for the this value of the function, and the specified array for the arguments of the function.

@param {Object} thisArg The object to be used as the this object.
@param {Object} [argArray] A set of arguments to be passed to the function.
@returns {Object}
**/
Function.prototype.apply = function(thisArg) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls a method of an object, substituting another object for the current object.

@param {Object} thisArg The object to be used as the current object.
@param {Object} argArray A list of arguments to be passed to the method.
@returns {Object}
**/
Function.prototype.call = function(thisArg, argArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
For a given function, creates a bound function that has the same body as the original function.
The this object of the bound function is associated with the specified object, and has the specified initial parameters.

@param {Object} thisArg An object to which the this keyword can refer inside the new function.
@param {Object} argArray A list of arguments to be passed to the new function.
@returns {Object}
**/
Function.prototype.bind = function(thisArg, argArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of a function.

@returns {String}
**/
Function.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Function.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Object}
**/
Function.prototype.arguments = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Function}
**/
Function.prototype.caller = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {String}
**/
Function.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Determines whether the given value inherits from this function if this function was used
as a constructor function.

A constructor function can control which objects are recognized as its instances by
'instanceof' by overriding this method.

@param {Object} value
@returns {Boolean}
**/
Function.prototype[Symbol.hasInstance] = function(value) {};

