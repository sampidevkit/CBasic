//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@example new WeakSet()
@example new WeakSet(values: readonly T[] | null)
@example new WeakSet(iterable: Iterable)

@param {(T[] | null)} [values] readonly T[] | null
@returns {WeakSet}
**/
WeakSet = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {WeakSet}
**/
WeakSet.prototype.add = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {Boolean}
**/
WeakSet.prototype.delete = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {Boolean}
**/
WeakSet.prototype.has = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
WeakSet.prototype[Symbol.toStringTag] = new String();

