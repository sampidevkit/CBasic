/**
An object representing the relative time format in parts
that can be used for custom locale-aware formatting.

[MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/RelativeTimeFormat/formatToParts#Using_formatToParts).

@returns {Intl.RelativeTimeFormatPart}
*/
Intl.RelativeTimeFormatPart = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.RelativeTimeFormatPart.prototype.type = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.RelativeTimeFormatPart.prototype.value = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("year" | "years" | "quarter" | "quarters" | "month" | "months" | "week" | "weeks" | "day" | "days" | "hour" | "hours" | "minute" | "minutes" | "second" | "seconds")} RelativeTimeFormatUnit
**/
Intl.RelativeTimeFormatPart.prototype.unit = new Object();

