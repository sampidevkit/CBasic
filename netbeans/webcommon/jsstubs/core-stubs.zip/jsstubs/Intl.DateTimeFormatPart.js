/**


@returns {Intl.DateTimeFormatPart}
*/
Intl.DateTimeFormatPart = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.intl.d.ts
/**


@returns {("day" | "dayPeriod" | "era" | "hour" | "literal" | "minute" | "month" | "second" | "timeZoneName" | "weekday" | "year")} DateTimeFormatPartTypes
**/
Intl.DateTimeFormatPart.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.intl.d.ts
/**


@returns {String}
**/
Intl.DateTimeFormatPart.prototype.value = new String();

