/**


@returns {PropertyDescriptorMap}
*/
PropertyDescriptorMap = function() {};

