/**


@returns {ReadonlySet}
*/
ReadonlySet = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Function} callbackfn (value: T, value2: T, set: ReadonlySet<T>) => void
@param {Object} [thisArg]
@returns {undefined}
**/
ReadonlySet.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {Boolean}
**/
ReadonlySet.prototype.has = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {Number}
**/
ReadonlySet.prototype.size = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Iterates over values in the set.

@returns {IterableIterator}
**/
ReadonlySet.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of [v,v] pairs for every value `v` in the set.

@returns {IterableIterator}
**/
ReadonlySet.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Despite its name, returns an iterable of the values in the set.

@returns {IterableIterator}
**/
ReadonlySet.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the set.

@returns {IterableIterator}
**/
ReadonlySet.prototype.values = function() {};

