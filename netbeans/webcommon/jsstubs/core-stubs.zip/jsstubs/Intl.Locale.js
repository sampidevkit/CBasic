/**
Constructor creates [Intl.Locale](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Intl/Locale)
objects

@returns {Intl.Locale}
*/
Intl.Locale = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**
Gets the most likely values for the language, script, and region of the locale based on existing values.

@returns {Locale}
**/
Intl.Locale.prototype.maximize = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**
Attempts to remove information about the locale that would be added by calling `Locale.maximize()`.

@returns {Locale}
**/
Intl.Locale.prototype.minimize = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**
Returns the locale's full locale identifier string.

@returns {String} BCP47LanguageTag
**/
Intl.Locale.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.baseName = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.calendar = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("upper" | "lower" | "false")} LocaleCollationCaseFirst
**/
Intl.Locale.prototype.caseFirst = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.collation = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("h12" | "h23" | "h11" | "h24")} LocaleHourCycleKey
**/
Intl.Locale.prototype.hourCycle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.language = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.numberingSystem = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {Boolean}
**/
Intl.Locale.prototype.numeric = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.region = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.Locale.prototype.script = new String();

