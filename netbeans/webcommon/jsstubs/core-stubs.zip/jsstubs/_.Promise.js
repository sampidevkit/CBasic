//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.promise.d.ts
/**
Represents the completion of an asynchronous operation
Represents the completion of an asynchronous operation
@example new Promise(executor: (resolve: (value: T | PromiseLike<T>) => void, reject: (reason?: any) => void) => void)

@param {Function} executor (resolve: (value: T | PromiseLike<T>) => void, reject: (reason?: any) => void) => void - A callback used to initialize the promise. This callback is passed two arguments:
a resolve callback used to resolve the promise with a value or the result of another promise,
and a reject callback used to reject the promise with a provided reason or error.
@returns {Promise}
**/
Promise = function(executor) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Attaches callbacks for the resolution and/or rejection of the Promise.

@param {(Function | undefined | null)} [onfulfilled] ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null - The callback to execute when the Promise is resolved.
@param {(Function | undefined | null)} [onrejected] ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null - The callback to execute when the Promise is rejected.
@returns {Promise}
**/
Promise.prototype.then = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Attaches a callback for only the rejection of the Promise.

@param {(Function | undefined | null)} [onrejected] ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null - The callback to execute when the Promise is rejected.
@returns {Promise}
**/
Promise.prototype.catch = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
Promise.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.promise.d.ts
/**
Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
resolved value cannot be modified from the callback.

@param {(Function | undefined | null)} [onfinally] (() => void) | undefined | null - The callback to execute when the Promise is settled (fulfilled or rejected).
@returns {Promise}
**/
Promise.prototype.finally = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.promise.d.ts
/**
Creates a Promise that is resolved with an array of results when all of the provided Promises
resolve, or rejected when any Promise is rejected.

@param {Object} values T - An array of Promises.
@returns {Promise}
**/
Promise.all = function(values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.promise.d.ts
/**
Creates a Promise that is resolved or rejected when any of the provided Promises are resolved
or rejected.

@param {Object} values T - An array of Promises.
@returns {Promise}
**/
Promise.race = function(values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.promise.d.ts
/**
Creates a new rejected promise for the provided reason.

@param {Object} [reason] The reason the promise was rejected.
@returns {Promise}
**/
Promise.reject = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.promise.d.ts
/**
Creates a new resolved promise.
Creates a new resolved promise for the provided value.

@param {(Object | PromiseLike)} value T | PromiseLike<T> - A promise.
@returns {Promise}
**/
Promise.resolve = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {PromiseConstructor}
**/
Promise[Symbol.species] = new PromiseConstructor();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.promise.d.ts
/**
Creates a Promise that is resolved with an array of results when all
of the provided Promises resolve or reject.

@param {Iterable} values Iterable - An array of Promises.
@returns {Promise}
**/
Promise.allSettled = function(values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.promise.d.ts
/**
The any function returns a promise that is fulfilled by the first given promise to be fulfilled, or rejected with an AggregateError containing an array of rejection reasons if all of the given promises are rejected. It resolves all elements of the passed iterable to promises as it runs this algorithm.

@param {Iterable} values Iterable - An array or iterable of Promises.
@returns {Promise}
**/
Promise.any = function(values) {};

