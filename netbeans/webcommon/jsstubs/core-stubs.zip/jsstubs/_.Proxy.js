//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@example new Proxy(target: T, handler: ProxyHandler)

@param {Object} target T
@param {ProxyHandler} handler ProxyHandler
@returns {Proxy}
**/
Proxy = function(target, handler) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {ProxyHandler} handler ProxyHandler
@returns {Object} { proxy: T; revoke: () => void; }
**/
Proxy.revocable = function(target, handler) {};

