/**


@returns {ProxyHandler}
*/
ProxyHandler = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {Object} thisArg
@param {Object} argArray
@returns {Object}
**/
ProxyHandler.prototype.apply = function(target, thisArg, argArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {Object} argArray
@param {Function} newTarget Function
@returns {Object}
**/
ProxyHandler.prototype.construct = function(target, argArray, newTarget) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(String | Symbol)} p string | symbol
@param {PropertyDescriptor} attributes PropertyDescriptor
@returns {Boolean}
**/
ProxyHandler.prototype.defineProperty = function(target, p, attributes) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(String | Symbol)} p string | symbol
@returns {Boolean}
**/
ProxyHandler.prototype.deleteProperty = function(target, p) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(String | Symbol)} p string | symbol
@param {Object} receiver
@returns {Object}
**/
ProxyHandler.prototype.get = function(target, p, receiver) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(String | Symbol)} p string | symbol
@returns {(PropertyDescriptor | undefined)} PropertyDescriptor | undefined
**/
ProxyHandler.prototype.getOwnPropertyDescriptor = function(target, p) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@returns {(Object | null)} object | null
**/
ProxyHandler.prototype.getPrototypeOf = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(String | Symbol)} p string | symbol
@returns {Boolean}
**/
ProxyHandler.prototype.has = function(target, p) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@returns {Boolean}
**/
ProxyHandler.prototype.isExtensible = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@returns {ArrayLike}
**/
ProxyHandler.prototype.ownKeys = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@returns {Boolean}
**/
ProxyHandler.prototype.preventExtensions = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(String | Symbol)} p string | symbol
@param {Object} value
@param {Object} receiver
@returns {Boolean}
**/
ProxyHandler.prototype.set = function(target, p, value, receiver) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.proxy.d.ts
/**


@param {Object} target T
@param {(Object | null)} v object | null
@returns {Boolean}
**/
ProxyHandler.prototype.setPrototypeOf = function(target, v) {};

