/**


@returns {ReadonlyMap}
*/
ReadonlyMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Function} callbackfn (value: V, key: K, map: ReadonlyMap<K, V>) => void
@param {Object} [thisArg]
@returns {undefined}
**/
ReadonlyMap.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {(Object | undefined)} V | undefined
**/
ReadonlyMap.prototype.get = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {Boolean}
**/
ReadonlyMap.prototype.has = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {Number}
**/
ReadonlyMap.prototype.size = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of entries in the map.

@returns {IterableIterator}
**/
ReadonlyMap.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of key, value pairs for every entry in the map.

@returns {IterableIterator}
**/
ReadonlyMap.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of keys in the map

@returns {IterableIterator}
**/
ReadonlyMap.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the map

@returns {IterableIterator}
**/
ReadonlyMap.prototype.values = function() {};

