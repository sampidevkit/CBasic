/**


@returns {AsyncIterable}
*/
AsyncIterable = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@returns {AsyncIterator}
**/
AsyncIterable.prototype[Symbol.asyncIterator] = function() {};

