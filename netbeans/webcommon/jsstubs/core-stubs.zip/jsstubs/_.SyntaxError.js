//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@example new SyntaxError()
@example new SyntaxError(message: String)
@example new SyntaxError(message: String, options: ErrorOptions)
@example new SyntaxError()
@example new SyntaxError(message: String)

@param {String} [message]
@param {ErrorOptions} [options] ErrorOptions
@returns {SyntaxError}
**/
SyntaxError = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
SyntaxError.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
SyntaxError.prototype.message = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
SyntaxError.prototype.stack = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
SyntaxError.prototype.cause = new Error();

