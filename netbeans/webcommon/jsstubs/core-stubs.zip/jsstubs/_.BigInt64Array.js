//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@example new BigInt64Array(buffer: ArrayBufferLike)
@example new BigInt64Array(buffer: ArrayBufferLike, byteOffset: Number)
@example new BigInt64Array(buffer: ArrayBufferLike, byteOffset: Number, length: Number)
@example new BigInt64Array()
@example new BigInt64Array(length: Number)
@example new BigInt64Array(array: Iterable)

@param {ArrayBuffer} buffer ArrayBufferLike
@param {Number} [byteOffset]
@param {Number} [length]
@returns {BigInt64Array}
**/
BigInt64Array = function(buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {Number}
**/
BigInt64Array.prototype.BYTES_PER_ELEMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {ArrayBuffer} ArrayBufferLike
**/
BigInt64Array.prototype.buffer = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {Number}
**/
BigInt64Array.prototype.byteLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {Number}
**/
BigInt64Array.prototype.byteOffset = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the this object after copying a section of the array identified by start and end
to the same array starting at position target

@param {Number} target If target is negative, it is treated as length+target where length is the
length of the array.
@param {Number} start If start is negative, it is treated as length+start. If end is negative, it
is treated as length+end.
@param {Number} [end] If not specified, length of the this object is used as its default value.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.copyWithin = function(target, start) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Yields index, value pairs for every entry in the array.

@returns {IterableIterator}
**/
BigInt64Array.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Determines whether all the members of an array satisfy the specified test.

@param {Function} predicate (value: bigint, index: number, array: BigInt64Array) => boolean - A function that accepts up to three arguments. The every method calls
the predicate function for each element in the array until the predicate returns false,
or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
BigInt64Array.prototype.every = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Changes all array elements from `start` to `end` index to a static `value` and returns the modified array

@param {BigInt} value value to fill array section with
@param {Number} [start] index to start filling the array at. If start is negative, it is treated as
length+start where length is the length of the array.
@param {Number} [end] index to stop filling the array at. If end is negative, it is treated as
length+end.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.fill = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the elements of an array that meet the condition specified in a callback function.

@param {Function} predicate (value: bigint, index: number, array: BigInt64Array) => any - A function that accepts up to three arguments. The filter method calls
the predicate function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.filter = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the value of the first element in the array where predicate is true, and undefined
otherwise.

@param {Function} predicate (value: bigint, index: number, array: BigInt64Array) => boolean - find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found, find
immediately returns that element value. Otherwise, find returns undefined.
@param {Object} [thisArg] If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.
@returns {(BigInt | undefined)} bigint | undefined
**/
BigInt64Array.prototype.find = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the index of the first element in the array where predicate is true, and -1
otherwise.

@param {Function} predicate (value: bigint, index: number, array: BigInt64Array) => boolean - find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found,
findIndex immediately returns that element index. Otherwise, findIndex returns -1.
@param {Object} [thisArg] If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.
@returns {Number}
**/
BigInt64Array.prototype.findIndex = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Performs the specified action for each element in an array.

@param {Function} callbackfn (value: bigint, index: number, array: BigInt64Array) => void - A function that accepts up to three arguments. forEach calls the
callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function.
If thisArg is omitted, undefined is used as the this value.
@returns {undefined}
**/
BigInt64Array.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Determines whether an array includes a certain element, returning true or false as appropriate.

@param {BigInt} searchElement The element to search for.
@param {Number} [fromIndex] The position in this array at which to begin searching for searchElement.
@returns {Boolean}
**/
BigInt64Array.prototype.includes = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the index of the first occurrence of a value in an array.

@param {BigInt} searchElement The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the
search starts at index 0.
@returns {Number}
**/
BigInt64Array.prototype.indexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Adds all the elements of an array separated by the specified separator string.

@param {String} [separator] A string used to separate one element of an array from the next in the
resulting String. If omitted, the array elements are separated with a comma.
@returns {String}
**/
BigInt64Array.prototype.join = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Yields each index in the array.

@returns {IterableIterator}
**/
BigInt64Array.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the index of the last occurrence of a value in an array.

@param {BigInt} searchElement The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the
search starts at index 0.
@returns {Number}
**/
BigInt64Array.prototype.lastIndexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {Number}
**/
BigInt64Array.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Calls a defined callback function on each element of an array, and returns an array that
contains the results.

@param {Function} callbackfn (value: bigint, index: number, array: BigInt64Array) => bigint - A function that accepts up to three arguments. The map method calls the
callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function.
If thisArg is omitted, undefined is used as the this value.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.map = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Calls the specified callback function for all the elements in an array. The return value of
the callback function is the accumulated result, and is provided as an argument in the next
call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: bigint, currentIndex: number, array: BigInt64Array) => U - A function that accepts up to four arguments. The reduce method calls the
callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start
the accumulation. The first call to the callbackfn function provides this value as an argument
instead of an array value.
@returns {Object} U
**/
BigInt64Array.prototype.reduce = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Calls the specified callback function for all the elements in an array, in descending order.
The return value of the callback function is the accumulated result, and is provided as an
argument in the next call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: bigint, currentIndex: number, array: BigInt64Array) => U - A function that accepts up to four arguments. The reduceRight method calls
the callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start
the accumulation. The first call to the callbackfn function provides this value as an argument
instead of an array value.
@returns {Object} U
**/
BigInt64Array.prototype.reduceRight = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Reverses the elements in the array.

@returns {BigInt64Array}
**/
BigInt64Array.prototype.reverse = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Sets a value or an array of values.

@param {ArrayLike} array ArrayLike - A typed or untyped array of values to set.
@param {Number} [offset] The index in the current array at which the values are to be written.
@returns {undefined}
**/
BigInt64Array.prototype.set = function(array) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns a section of an array.

@param {Number} [start] The beginning of the specified portion of the array.
@param {Number} [end] The end of the specified portion of the array.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.slice = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Determines whether the specified callback function returns true for any element of an array.

@param {Function} predicate (value: bigint, index: number, array: BigInt64Array) => boolean - A function that accepts up to three arguments. The some method calls the
predicate function for each element in the array until the predicate returns true, or until
the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
BigInt64Array.prototype.some = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Sorts the array.

@param {Function} [compareFn] (a: bigint, b: bigint) => number | bigint - The function used to determine the order of the elements. If omitted, the elements are sorted in ascending order.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.sort = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Gets a new BigInt64Array view of the ArrayBuffer store for this array, referencing the elements
at begin, inclusive, up to end, exclusive.

@param {Number} [begin] The index of the beginning of the array.
@param {Number} [end] The index of the end of the array.
@returns {BigInt64Array}
**/
BigInt64Array.prototype.subarray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Converts the array to a string by using the current locale.

@returns {String}
**/
BigInt64Array.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns a string representation of the array.

@returns {String}
**/
BigInt64Array.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the primitive value of the specified object.

@returns {BigInt64Array}
**/
BigInt64Array.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Yields each value in the array.

@returns {IterableIterator}
**/
BigInt64Array.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {IterableIterator}
**/
BigInt64Array.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {"BigInt64Array"}
**/
BigInt64Array.prototype[Symbol.toStringTag] = "BigInt64Array";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.array.d.ts
/**
Returns the item located at the specified index.

@param {Number} index The zero-based index of the desired code unit. A negative index will count back from the last item.
@returns {(BigInt | undefined)} bigint | undefined
**/
BigInt64Array.prototype.at = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {Number}
**/
BigInt64Array.BYTES_PER_ELEMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns a new array from a set of elements.

@param {BigInt} items A set of elements to include in the new array object.
@returns {BigInt64Array}
**/
BigInt64Array.of = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Creates an array from an array-like or iterable object.

@param {ArrayLike} arrayLike ArrayLike
@param {Function} mapfn (v: U, k: number) => bigint
@param {Object} [thisArg]
@returns {BigInt64Array}
**/
BigInt64Array.from = function(arrayLike, mapfn) {};

