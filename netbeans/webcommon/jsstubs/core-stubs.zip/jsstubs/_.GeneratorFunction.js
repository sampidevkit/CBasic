//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.generator.d.ts
/**


@example new GeneratorFunction(args: Object)
@example new GeneratorFunction(args: String)

@param {Object} args A list of arguments the function accepts.
@returns {GeneratorFunction}
**/
GeneratorFunction = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.generator.d.ts
/**


@returns {Number}
**/
GeneratorFunction.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.generator.d.ts
/**


@returns {String}
**/
GeneratorFunction.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
GeneratorFunction.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.generator.d.ts
/**


@returns {Number}
**/
GeneratorFunction.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.generator.d.ts
/**


@returns {String}
**/
GeneratorFunction.name = new String();

