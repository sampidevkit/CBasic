/**


@returns {PromiseRejectedResult}
*/
PromiseRejectedResult = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.promise.d.ts
/**


@returns {"rejected"}
**/
PromiseRejectedResult.prototype.status = "rejected";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.promise.d.ts
/**


@returns {Object}
**/
PromiseRejectedResult.prototype.reason = new Object();

