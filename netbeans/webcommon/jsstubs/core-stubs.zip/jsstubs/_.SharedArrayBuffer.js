//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**


@example new SharedArrayBuffer(byteLength: Number)

@param {Number} byteLength
@returns {SharedArrayBuffer}
**/
SharedArrayBuffer = function(byteLength) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**


@returns {Number}
**/
SharedArrayBuffer.prototype.byteLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**
Returns a section of an SharedArrayBuffer.

@param {Number} begin
@param {Number} [end]
@returns {SharedArrayBuffer}
**/
SharedArrayBuffer.prototype.slice = function(begin) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**


@returns {SharedArrayBuffer}
**/
SharedArrayBuffer.prototype[Symbol.species] = new SharedArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**


@returns {"SharedArrayBuffer"}
**/
SharedArrayBuffer.prototype[Symbol.toStringTag] = "SharedArrayBuffer";

