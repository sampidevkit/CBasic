/**


@returns {Math}
*/
Math = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.E = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.LN10 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.LN2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.LOG2E = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.LOG10E = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.PI = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.SQRT1_2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Math.SQRT2 = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the absolute value of a number (the value without regard to whether it is positive or negative).
For example, the absolute value of -5 is the same as the absolute value of 5.

@param {Number} x A numeric expression for which the absolute value is needed.
@returns {Number}
**/
Math.abs = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the arc cosine (or inverse cosine) of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.acos = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the arcsine of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.asin = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the arctangent of a number.

@param {Number} x A numeric expression for which the arctangent is needed.
@returns {Number}
**/
Math.atan = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the angle (in radians) from the X axis to a point.

@param {Number} y A numeric expression representing the cartesian y-coordinate.
@param {Number} x A numeric expression representing the cartesian x-coordinate.
@returns {Number}
**/
Math.atan2 = function(y, x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the smallest integer greater than or equal to its numeric argument.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.ceil = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the cosine of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.cos = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns e (the base of natural logarithms) raised to a power.

@param {Number} x A numeric expression representing the power of e.
@returns {Number}
**/
Math.exp = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the greatest integer less than or equal to its numeric argument.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.floor = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the natural logarithm (base e) of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.log = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the larger of a set of supplied numeric expressions.

@param {Number} values Numeric expressions to be evaluated.
@returns {Number}
**/
Math.max = function(values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the smaller of a set of supplied numeric expressions.

@param {Number} values Numeric expressions to be evaluated.
@returns {Number}
**/
Math.min = function(values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the value of a base expression taken to a specified power.

@param {Number} x The base value of the expression.
@param {Number} y The exponent value of the expression.
@returns {Number}
**/
Math.pow = function(x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a pseudorandom number between 0 and 1.

@returns {Number}
**/
Math.random = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a supplied numeric expression rounded to the nearest integer.

@param {Number} x The value to be rounded to the nearest integer.
@returns {Number}
**/
Math.round = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the sine of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.sin = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the square root of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.sqrt = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the tangent of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.tan = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the number of leading zero bits in the 32-bit binary representation of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.clz32 = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the result of 32-bit multiplication of two numbers.

@param {Number} x First number
@param {Number} y Second number
@returns {Number}
**/
Math.imul = function(x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the sign of the x, indicating whether x is positive, negative or zero.

@param {Number} x The numeric expression to test
@returns {Number}
**/
Math.sign = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the base 10 logarithm of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.log10 = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the base 2 logarithm of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.log2 = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the natural logarithm of 1 + x.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.log1p = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the result of (e^x - 1), which is an implementation-dependent approximation to
subtracting 1 from the exponential function of x (e raised to the power of x, where e
is the base of the natural logarithms).

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.expm1 = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the hyperbolic cosine of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.cosh = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the hyperbolic sine of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.sinh = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the hyperbolic tangent of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.tanh = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the inverse hyperbolic cosine of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.acosh = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the inverse hyperbolic sine of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.asinh = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the inverse hyperbolic tangent of a number.

@param {Number} x A numeric expression that contains an angle measured in radians.
@returns {Number}
**/
Math.atanh = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the square root of the sum of squares of its arguments.

@param {Number} values Values to compute the square root for.
If no arguments are passed, the result is +0.
If there is only one argument, the result is the absolute value.
If any argument is +Infinity or -Infinity, the result is +Infinity.
If any argument is NaN, the result is NaN.
If all arguments are either +0 or −0, the result is +0.
@returns {Number}
**/
Math.hypot = function(values) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the integral part of the a numeric expression, x, removing any fractional digits.
If x is already an integer, the result is x.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.trunc = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the nearest single precision float representation of a number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.fround = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns an implementation-dependent approximation to the cube root of number.

@param {Number} x A numeric expression.
@returns {Number}
**/
Math.cbrt = function(x) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
Math[Symbol.toStringTag] = new String();

