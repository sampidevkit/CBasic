/**
The type for the `assert` property of the optional second argument to `import()`.

@returns {ImportAssertions}
*/
ImportAssertions = function() {};

