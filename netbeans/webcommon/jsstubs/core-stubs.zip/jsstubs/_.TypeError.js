//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@example new TypeError()
@example new TypeError(message: String)
@example new TypeError(message: String, options: ErrorOptions)
@example new TypeError()
@example new TypeError(message: String)

@param {String} [message]
@param {ErrorOptions} [options] ErrorOptions
@returns {TypeError}
**/
TypeError = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
TypeError.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
TypeError.prototype.message = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
TypeError.prototype.stack = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
TypeError.prototype.cause = new Error();

