/**


@returns {Intl.DisplayNamesOptions}
*/
Intl.DisplayNamesOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String} UnicodeBCP47LocaleIdentifier
**/
Intl.DisplayNamesOptions.prototype.locale = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("lookup" | "best fit")} RelativeTimeFormatLocaleMatcher
**/
Intl.DisplayNamesOptions.prototype.localeMatcher = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("long" | "short" | "narrow")} RelativeTimeFormatStyle
**/
Intl.DisplayNamesOptions.prototype.style = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("language" | "region" | "script" | "currency")} "language" | "region" | "script" | "currency"
**/
Intl.DisplayNamesOptions.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("code" | "none")} "code" | "none"
**/
Intl.DisplayNamesOptions.prototype.fallback = new Object();

