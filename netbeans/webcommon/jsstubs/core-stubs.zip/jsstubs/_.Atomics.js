/**


@returns {Atomics}
*/
Atomics = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Adds a value to the value at the given position in the array, returning the original value.
Until this atomic operation completes, any other read or write operation against the array
will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.add = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Stores the bitwise AND of a value with the value at the given position in the array,
returning the original value. Until this atomic operation completes, any other read or
write operation against the array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.and = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Replaces the value at the given position in the array if the original value equals the given
expected value, returning the original value. Until this atomic operation completes, any
other read or write operation against the array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} expectedValue
@param {BigInt} replacementValue
@returns {BigInt}
**/
Atomics.prototype.compareExchange = function(typedArray, index, expectedValue, replacementValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Replaces the value at the given position in the array, returning the original value. Until
this atomic operation completes, any other read or write operation against the array will
block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.exchange = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**
Returns a value indicating whether high-performance algorithms can use atomic operations
(`true`) or must use locks (`false`) for the given number of bytes-per-element of a typed
array.

@param {Number} size
@returns {Boolean}
**/
Atomics.prototype.isLockFree = function(size) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Returns the value at the given position in the array. Until this atomic operation completes,
any other read or write operation against the array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@returns {BigInt}
**/
Atomics.prototype.load = function(typedArray, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Stores the bitwise OR of a value with the value at the given position in the array,
returning the original value. Until this atomic operation completes, any other read or write
operation against the array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.or = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Stores a value at the given position in the array, returning the new value. Until this
atomic operation completes, any other read or write operation against the array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.store = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Subtracts a value from the value at the given position in the array, returning the original
value. Until this atomic operation completes, any other read or write operation against the
array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.sub = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
If the value at the given position in the array is equal to the provided value, the current
agent is put to sleep causing execution to suspend until the timeout expires (returning
`"timed-out"`) or until the agent is awoken (returning `"ok"`); otherwise, returns
`"not-equal"`.

@param {BigInt64Array} typedArray BigInt64Array
@param {Number} index
@param {BigInt} value
@param {Number} [timeout]
@returns {("ok" | "not-equal" | "timed-out")} "ok" | "not-equal" | "timed-out"
**/
Atomics.prototype.wait = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Wakes up sleeping agents that are waiting on the given index of the array, returning the
number of agents that were awoken.

@param {BigInt64Array} typedArray BigInt64Array - A shared BigInt64Array.
@param {Number} index The position in the typedArray to wake up on.
@param {Number} [count] The number of sleeping agents to notify. Defaults to +Infinity.
@returns {Number}
**/
Atomics.prototype.notify = function(typedArray, index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.sharedmemory.d.ts
/**
Stores the bitwise XOR of a value with the value at the given position in the array,
returning the original value. Until this atomic operation completes, any other read or write
operation against the array will block.

@param {(BigInt64Array | BigUint64Array)} typedArray BigInt64Array | BigUint64Array
@param {Number} index
@param {BigInt} value
@returns {BigInt}
**/
Atomics.prototype.xor = function(typedArray, index, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.sharedmemory.d.ts
/**


@returns {"Atomics"}
**/
Atomics.prototype[Symbol.toStringTag] = "Atomics";

