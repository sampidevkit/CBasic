/**


@returns {PromiseFulfilledResult}
*/
PromiseFulfilledResult = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.promise.d.ts
/**


@returns {"fulfilled"}
**/
PromiseFulfilledResult.prototype.status = "fulfilled";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.promise.d.ts
/**


@returns {Object} T
**/
PromiseFulfilledResult.prototype.value = new Object();

