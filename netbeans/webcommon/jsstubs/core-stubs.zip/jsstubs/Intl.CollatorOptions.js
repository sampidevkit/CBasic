/**


@returns {Intl.CollatorOptions}
*/
Intl.CollatorOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.CollatorOptions.prototype.usage = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.CollatorOptions.prototype.localeMatcher = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Boolean | undefined)} boolean | undefined
**/
Intl.CollatorOptions.prototype.numeric = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.CollatorOptions.prototype.caseFirst = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.CollatorOptions.prototype.sensitivity = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Boolean | undefined)} boolean | undefined
**/
Intl.CollatorOptions.prototype.ignorePunctuation = new Boolean();

