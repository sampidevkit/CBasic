//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Provides functionality common to all JavaScript objects.

@example new Object()
@example new Object(value: Object)

@param {Object} [value]
@returns {Object}
**/
Object = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an object.

@returns {String}
**/
Object.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a date converted to a string using the current locale.

@returns {String}
**/
Object.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the primitive value of the specified object.

@returns {Object}
**/
Object.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether an object has a property with the specified name.

@param {(String | Number | Symbol)} v PropertyKey - A property name.
@returns {Boolean}
**/
Object.prototype.hasOwnProperty = function(v) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether an object exists in another object's prototype chain.

@param {Object} v Object - Another object whose prototype chain is to be checked.
@returns {Boolean}
**/
Object.prototype.isPrototypeOf = function(v) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether a specified property is enumerable.

@param {(String | Number | Symbol)} v PropertyKey - A property name.
@returns {Boolean}
**/
Object.prototype.propertyIsEnumerable = function(v) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the prototype of an object.

@param {Object} o The object that references the prototype.
@returns {Object}
**/
Object.getPrototypeOf = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the own property descriptor of the specified object.
An own property descriptor is one that is defined directly on the object and is not inherited from the object's prototype.

@param {Object} o Object that contains the property.
@param {(String | Number | Symbol)} p PropertyKey - Name of the property.
@returns {(PropertyDescriptor | undefined)} PropertyDescriptor | undefined
**/
Object.getOwnPropertyDescriptor = function(o, p) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the names of the own properties of an object. The own properties of an object are those that are defined directly
on that object, and are not inherited from the object's prototype. The properties of an object include both fields (objects) and functions.

@param {Object} o Object that contains the own properties.
@returns {String}
**/
Object.getOwnPropertyNames = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Creates an object that has the specified prototype or that has null prototype.
Creates an object that has the specified prototype, and that optionally contains specified properties.

@param {(Object | null)} o object | null - Object to use as a prototype. May be null
@param {Object} properties PropertyDescriptorMap & ThisType<any> - JavaScript object that contains one or more property descriptors.
@returns {Object}
**/
Object.create = function(o, properties) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Adds a property to an object, or modifies attributes of an existing property.

@param {Object} o T - Object on which to add or modify the property. This can be a native JavaScript object (that is, a user-defined object or a built in object) or a DOM object.
@param {(String | Number | Symbol)} p PropertyKey - The property name.
@param {Object} attributes PropertyDescriptor & ThisType<any> - Descriptor for the property. It can be for a data property or an accessor property.
@returns {Object} T
**/
Object.defineProperty = function(o, p, attributes) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Adds one or more properties to an object, and/or modifies attributes of existing properties.

@param {Object} o T - Object on which to add or modify the properties. This can be a native JavaScript object or a DOM object.
@param {Object} properties PropertyDescriptorMap & ThisType<any> - JavaScript object that contains one or more descriptor objects. Each descriptor object describes a data property or an accessor property.
@returns {Object} T
**/
Object.defineProperties = function(o, properties) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Prevents the modification of attributes of existing properties, and prevents the addition of new properties.

@param {Object} o T - Object on which to lock the attributes.
@returns {Object} T
**/
Object.seal = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Prevents the modification of existing property attributes and values, and prevents the addition of new properties.

@param {Object} o T - Object on which to lock the attributes.
@returns {Object} Readonly
**/
Object.freeze = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Prevents the addition of new properties to an object.

@param {Object} o T - Object to make non-extensible.
@returns {Object} T
**/
Object.preventExtensions = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns true if existing property attributes cannot be modified in an object and new properties cannot be added to the object.

@param {Object} o Object to test.
@returns {Boolean}
**/
Object.isSealed = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns true if existing property attributes and values cannot be modified in an object, and new properties cannot be added to the object.

@param {Object} o Object to test.
@returns {Boolean}
**/
Object.isFrozen = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a value that indicates whether new properties can be added to an object.

@param {Object} o Object to test.
@returns {Boolean}
**/
Object.isExtensible = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns the names of the enumerable string properties and methods of an object.

@param {Object} o {} - Object that contains the properties and methods. This can be an object that you created or an existing Document Object Model (DOM) object.
@returns {String}
**/
Object.keys = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Copy the values of all of the enumerable own properties from one or more source objects to a
target object. Returns the target object.

@param {Object} target The target object to copy to.
@param {Object} sources One or more source objects from which to copy properties
@returns {Object}
**/
Object.assign = function(target, sources) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns an array of all symbol properties found directly on object o.

@param {Object} o Object to retrieve the symbols from.
@returns {Symbol}
**/
Object.getOwnPropertySymbols = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if the values are the same value, false otherwise.

@param {Object} value1 The first value.
@param {Object} value2 The second value.
@returns {Boolean}
**/
Object.is = function(value1, value2) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Sets the prototype of a specified object o to object proto or null. Returns the object o.

@param {Object} o The object to change its prototype.
@param {(Object | null)} proto object | null - The value of the new prototype or null.
@returns {Object}
**/
Object.setPrototypeOf = function(o, proto) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.object.d.ts
/**
Returns an array of values of the enumerable properties of an object

@param {Object} o {} - Object that contains the properties and methods. This can be an object that you created or an existing Document Object Model (DOM) object.
@returns {Object}
**/
Object.values = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.object.d.ts
/**
Returns an array of key/values of the enumerable properties of an object

@param {Object} o {} - Object that contains the properties and methods. This can be an object that you created or an existing Document Object Model (DOM) object.
@returns {Object} [string, any][]
**/
Object.entries = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2017.object.d.ts
/**
Returns an object containing all own property descriptors of an object

@param {Object} o T - Object that contains the properties and methods. This can be an object that you created or an existing Document Object Model (DOM) object.
@returns {Object} {[P in keyof T]: TypedPropertyDescriptor<T[P]>} & { [x: string]: PropertyDescriptor }
**/
Object.getOwnPropertyDescriptors = function(o) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.object.d.ts
/**
Returns an object created by key-value entries for properties and methods

@param {Iterable} entries Iterable - An iterable object that contains key-value entries for properties and methods.
@returns {Object}
**/
Object.fromEntries = function(entries) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.object.d.ts
/**
Determines whether an object has a property with the specified name.

@param {Object} o An object.
@param {(String | Number | Symbol)} v PropertyKey - A property name.
@returns {Boolean}
**/
Object.hasOwn = function(o, v) {};

