//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new Date(year: Number, month: Number)
@example new Date(year: Number, month: Number, date: Number)
@example new Date(year: Number, month: Number, date: Number, hours: Number)
@example new Date(year: Number, month: Number, date: Number, hours: Number, minutes: Number)
@example new Date(year: Number, month: Number, date: Number, hours: Number, minutes: Number, seconds: Number)
@example new Date(year: Number, month: Number, date: Number, hours: Number, minutes: Number, seconds: Number, ms: Number)
@example new Date(value: number | string)
@example new Date(vd: VarDate)
@example new Date(value: number | string | Date)
@example new Date()

@param {Number} year
@param {Number} month
@param {Number} [date]
@param {Number} [hours]
@param {Number} [minutes]
@param {Number} [seconds]
@param {Number} [ms]
@returns {Date}
**/
Date = function(year, month) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of a date. The format of the string depends on the locale.

@returns {String}
**/
Date.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a date as a string value.

@returns {String}
**/
Date.prototype.toDateString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a time as a string value.

@returns {String}
**/
Date.prototype.toTimeString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a value as a string value appropriate to the host environment's current locale.
Converts a date and time to a string by using the current or specified locale.

@param {(String | String)} [locales] string | string[] - A locale string or array of locale strings that contain one or more language or locale tags. If you include more than one locale string, list them in descending order of priority so that the first entry is the preferred locale. If you omit this parameter, the default locale of the JavaScript runtime is used.
@param {Intl.DateTimeFormatOptions} [options] Intl.DateTimeFormatOptions - An object that contains one or more properties that specify comparison options.
@returns {String}
**/
Date.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a date as a string value appropriate to the host environment's current locale.
Converts a date to a string by using the current or specified locale.

@param {(String | String)} [locales] string | string[] - A locale string or array of locale strings that contain one or more language or locale tags. If you include more than one locale string, list them in descending order of priority so that the first entry is the preferred locale. If you omit this parameter, the default locale of the JavaScript runtime is used.
@param {Intl.DateTimeFormatOptions} [options] Intl.DateTimeFormatOptions - An object that contains one or more properties that specify comparison options.
@returns {String}
**/
Date.prototype.toLocaleDateString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a time as a string value appropriate to the host environment's current locale.
Converts a time to a string by using the current or specified locale.

@param {(String | String)} [locales] string | string[] - A locale string or array of locale strings that contain one or more language or locale tags. If you include more than one locale string, list them in descending order of priority so that the first entry is the preferred locale. If you omit this parameter, the default locale of the JavaScript runtime is used.
@param {Intl.DateTimeFormatOptions} [options] Intl.DateTimeFormatOptions - An object that contains one or more properties that specify comparison options.
@returns {String}
**/
Date.prototype.toLocaleTimeString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the stored time value in milliseconds since midnight, January 1, 1970 UTC.

@returns {Number}
**/
Date.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the time value in milliseconds.

@returns {Number}
**/
Date.prototype.getTime = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the year, using local time.

@returns {Number}
**/
Date.prototype.getFullYear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the year using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCFullYear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the month, using local time.

@returns {Number}
**/
Date.prototype.getMonth = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the month of a Date object using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCMonth = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the day-of-the-month, using local time.

@returns {Number}
**/
Date.prototype.getDate = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the day-of-the-month, using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCDate = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the day of the week, using local time.

@returns {Number}
**/
Date.prototype.getDay = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the day of the week using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCDay = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the hours in a date, using local time.

@returns {Number}
**/
Date.prototype.getHours = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the hours value in a Date object using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCHours = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the minutes of a Date object, using local time.

@returns {Number}
**/
Date.prototype.getMinutes = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the minutes of a Date object using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCMinutes = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the seconds of a Date object, using local time.

@returns {Number}
**/
Date.prototype.getSeconds = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the seconds of a Date object using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCSeconds = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the milliseconds of a Date, using local time.

@returns {Number}
**/
Date.prototype.getMilliseconds = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the milliseconds of a Date object using Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getUTCMilliseconds = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets the difference in minutes between the time on the local computer and Universal Coordinated Time (UTC).

@returns {Number}
**/
Date.prototype.getTimezoneOffset = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the date and time value in the Date object.

@param {Number} time A numeric value representing the number of elapsed milliseconds since midnight, January 1, 1970 GMT.
@returns {Number}
**/
Date.prototype.setTime = function(time) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the milliseconds value in the Date object using local time.

@param {Number} ms A numeric value equal to the millisecond value.
@returns {Number}
**/
Date.prototype.setMilliseconds = function(ms) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the milliseconds value in the Date object using Universal Coordinated Time (UTC).

@param {Number} ms A numeric value equal to the millisecond value.
@returns {Number}
**/
Date.prototype.setUTCMilliseconds = function(ms) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the seconds value in the Date object using local time.

@param {Number} sec A numeric value equal to the seconds value.
@param {Number} [ms] A numeric value equal to the milliseconds value.
@returns {Number}
**/
Date.prototype.setSeconds = function(sec) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the seconds value in the Date object using Universal Coordinated Time (UTC).

@param {Number} sec A numeric value equal to the seconds value.
@param {Number} [ms] A numeric value equal to the milliseconds value.
@returns {Number}
**/
Date.prototype.setUTCSeconds = function(sec) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the minutes value in the Date object using local time.

@param {Number} min A numeric value equal to the minutes value.
@param {Number} [sec] A numeric value equal to the seconds value.
@param {Number} [ms] A numeric value equal to the milliseconds value.
@returns {Number}
**/
Date.prototype.setMinutes = function(min) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the minutes value in the Date object using Universal Coordinated Time (UTC).

@param {Number} min A numeric value equal to the minutes value.
@param {Number} [sec] A numeric value equal to the seconds value.
@param {Number} [ms] A numeric value equal to the milliseconds value.
@returns {Number}
**/
Date.prototype.setUTCMinutes = function(min) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the hour value in the Date object using local time.

@param {Number} hours A numeric value equal to the hours value.
@param {Number} [min] A numeric value equal to the minutes value.
@param {Number} [sec] A numeric value equal to the seconds value.
@param {Number} [ms] A numeric value equal to the milliseconds value.
@returns {Number}
**/
Date.prototype.setHours = function(hours) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the hours value in the Date object using Universal Coordinated Time (UTC).

@param {Number} hours A numeric value equal to the hours value.
@param {Number} [min] A numeric value equal to the minutes value.
@param {Number} [sec] A numeric value equal to the seconds value.
@param {Number} [ms] A numeric value equal to the milliseconds value.
@returns {Number}
**/
Date.prototype.setUTCHours = function(hours) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the numeric day-of-the-month value of the Date object using local time.

@param {Number} date A numeric value equal to the day of the month.
@returns {Number}
**/
Date.prototype.setDate = function(date) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the numeric day of the month in the Date object using Universal Coordinated Time (UTC).

@param {Number} date A numeric value equal to the day of the month.
@returns {Number}
**/
Date.prototype.setUTCDate = function(date) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the month value in the Date object using local time.

@param {Number} month A numeric value equal to the month. The value for January is 0, and other month values follow consecutively.
@param {Number} [date] A numeric value representing the day of the month. If this value is not supplied, the value from a call to the getDate method is used.
@returns {Number}
**/
Date.prototype.setMonth = function(month) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the month value in the Date object using Universal Coordinated Time (UTC).

@param {Number} month A numeric value equal to the month. The value for January is 0, and other month values follow consecutively.
@param {Number} [date] A numeric value representing the day of the month. If it is not supplied, the value from a call to the getUTCDate method is used.
@returns {Number}
**/
Date.prototype.setUTCMonth = function(month) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the year of the Date object using local time.

@param {Number} year A numeric value for the year.
@param {Number} [month] A zero-based numeric value for the month (0 for January, 11 for December). Must be specified if numDate is specified.
@param {Number} [date] A numeric value equal for the day of the month.
@returns {Number}
**/
Date.prototype.setFullYear = function(year) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets the year value in the Date object using Universal Coordinated Time (UTC).

@param {Number} year A numeric value equal to the year.
@param {Number} [month] A numeric value equal to the month. The value for January is 0, and other month values follow consecutively. Must be supplied if numDate is supplied.
@param {Number} [date] A numeric value equal to the day of the month.
@returns {Number}
**/
Date.prototype.setUTCFullYear = function(year) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a date converted to a string using Universal Coordinated Time (UTC).

@returns {String}
**/
Date.prototype.toUTCString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a date as a string value in ISO format.

@returns {String}
**/
Date.prototype.toISOString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Used by the JSON.stringify method to enable the transformation of an object's data for JavaScript Object Notation (JSON) serialization.

@param {Object} [key]
@returns {String}
**/
Date.prototype.toJSON = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.scripthost.d.ts
/**


@returns {Function} () => VarDate
**/
Date.prototype.getVarDate = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Converts a Date object to a string or number.

@param {String} hint The strings "number", "string", or "default" to specify what primitive to return.
@returns {(String | Number)} string | number
**/
Date.prototype[Symbol.toPrimitive] = function(hint) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Parses a string containing a date, and returns the number of milliseconds between that date and midnight, January 1, 1970.

@param {String} s A date string
@returns {Number}
**/
Date.parse = function(s) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the number of milliseconds between midnight, January 1, 1970 Universal Coordinated Time (UTC) (or GMT) and the specified date.

@param {Number} year The full year designation is required for cross-century date accuracy. If year is between 0 and 99 is used, then year is assumed to be 1900 + year.
@param {Number} month The month as a number between 0 and 11 (January to December).
@param {Number} [date] The date as a number between 1 and 31.
@param {Number} [hours] Must be supplied if minutes is supplied. A number from 0 to 23 (midnight to 11pm) that specifies the hour.
@param {Number} [minutes] Must be supplied if seconds is supplied. A number from 0 to 59 that specifies the minutes.
@param {Number} [seconds] Must be supplied if milliseconds is supplied. A number from 0 to 59 that specifies the seconds.
@param {Number} [ms] A number from 0 to 999 that specifies the milliseconds.
@returns {Number}
**/
Date.UTC = function(year, month) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Date.now = function() {};

