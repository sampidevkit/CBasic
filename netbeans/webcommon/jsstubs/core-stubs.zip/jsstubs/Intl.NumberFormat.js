/**


@returns {Intl.NumberFormat}
*/
Intl.NumberFormat = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@param {(Number | BigInt)} value number | bigint
@returns {String}
**/
Intl.NumberFormat.prototype.format = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {ResolvedNumberFormatOptions}
**/
Intl.NumberFormat.prototype.resolvedOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@param {(Number | BigInt)} [number] number | bigint
@returns {NumberFormatPart[]}
**/
Intl.NumberFormat.prototype.formatToParts = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@param {(Number | BigInt)} startDate number | bigint
@param {(Number | BigInt)} endDate number | bigint
@returns {String}
**/
Intl.NumberFormat.prototype.formatRange = function(startDate, endDate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@param {(Number | BigInt)} startDate number | bigint
@param {(Number | BigInt)} endDate number | bigint
@returns {NumberFormatPart[]}
**/
Intl.NumberFormat.prototype.formatRangeToParts = function(startDate, endDate) {};

