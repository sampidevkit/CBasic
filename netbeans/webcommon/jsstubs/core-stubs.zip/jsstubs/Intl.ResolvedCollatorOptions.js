/**


@returns {Intl.ResolvedCollatorOptions}
*/
Intl.ResolvedCollatorOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedCollatorOptions.prototype.locale = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedCollatorOptions.prototype.usage = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedCollatorOptions.prototype.sensitivity = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
Intl.ResolvedCollatorOptions.prototype.ignorePunctuation = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedCollatorOptions.prototype.collation = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedCollatorOptions.prototype.caseFirst = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
Intl.ResolvedCollatorOptions.prototype.numeric = new Boolean();

