/**


@returns {Intl.ResolvedNumberFormatOptions}
*/
Intl.ResolvedNumberFormatOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.locale = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.numberingSystem = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.style = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.currency = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Intl.ResolvedNumberFormatOptions.prototype.minimumIntegerDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Intl.ResolvedNumberFormatOptions.prototype.minimumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Intl.ResolvedNumberFormatOptions.prototype.maximumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Intl.ResolvedNumberFormatOptions.prototype.minimumSignificantDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Intl.ResolvedNumberFormatOptions.prototype.maximumSignificantDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
Intl.ResolvedNumberFormatOptions.prototype.useGrouping = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("short" | "long")} "short" | "long"
**/
Intl.ResolvedNumberFormatOptions.prototype.compactDisplay = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("standard" | "scientific" | "engineering" | "compact")} "standard" | "scientific" | "engineering" | "compact"
**/
Intl.ResolvedNumberFormatOptions.prototype.notation = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("auto" | "never" | "always" | "exceptZero")} "auto" | "never" | "always" | "exceptZero"
**/
Intl.ResolvedNumberFormatOptions.prototype.signDisplay = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.unit = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("short" | "long" | "narrow")} "short" | "long" | "narrow"
**/
Intl.ResolvedNumberFormatOptions.prototype.unitDisplay = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.currencyDisplay = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.ResolvedNumberFormatOptions.prototype.currencySign = new String();

