/**


@returns {Intl.NumberFormatOptions}
*/
Intl.NumberFormatOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.NumberFormatOptions.prototype.localeMatcher = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.NumberFormatOptions.prototype.style = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.NumberFormatOptions.prototype.currency = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.NumberFormatOptions.prototype.currencySign = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Boolean | undefined)} boolean | undefined
**/
Intl.NumberFormatOptions.prototype.useGrouping = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.NumberFormatOptions.prototype.minimumIntegerDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.NumberFormatOptions.prototype.minimumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.NumberFormatOptions.prototype.maximumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.NumberFormatOptions.prototype.minimumSignificantDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.NumberFormatOptions.prototype.maximumSignificantDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("short" | "long" | undefined)} "short" | "long" | undefined
**/
Intl.NumberFormatOptions.prototype.compactDisplay = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("standard" | "scientific" | "engineering" | "compact" | undefined)} "standard" | "scientific" | "engineering" | "compact" | undefined
**/
Intl.NumberFormatOptions.prototype.notation = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("auto" | "never" | "always" | "exceptZero" | undefined)} "auto" | "never" | "always" | "exceptZero" | undefined
**/
Intl.NumberFormatOptions.prototype.signDisplay = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.NumberFormatOptions.prototype.unit = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("short" | "long" | "narrow" | undefined)} "short" | "long" | "narrow" | undefined
**/
Intl.NumberFormatOptions.prototype.unitDisplay = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Intl.NumberFormatOptions.prototype.currencyDisplay = new String();

