/**


@returns {Intl.PluralRulesOptions}
*/
Intl.PluralRulesOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {("lookup" | "best fit" | undefined)} "lookup" | "best fit" | undefined
**/
Intl.PluralRulesOptions.prototype.localeMatcher = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {("cardinal" | "ordinal" | undefined)} PluralRuleType | undefined
**/
Intl.PluralRulesOptions.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.PluralRulesOptions.prototype.minimumIntegerDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.PluralRulesOptions.prototype.minimumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.PluralRulesOptions.prototype.maximumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.PluralRulesOptions.prototype.minimumSignificantDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {(Number | undefined)} number | undefined
**/
Intl.PluralRulesOptions.prototype.maximumSignificantDigits = new Number();

