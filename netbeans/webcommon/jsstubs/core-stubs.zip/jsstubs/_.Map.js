//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@example new Map()
@example new Map(entries: readonly (readonly [K, V])[] | null)
@example new Map()
@example new Map(iterable: Iterable<readonly [K, V]> | null)
@example new Map()
@example new Map()

@param {(Object | null)} [entries] readonly (readonly [K, V])[] | null
@returns {Map}
**/
Map = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {undefined}
**/
Map.prototype.clear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {Boolean}
**/
Map.prototype.delete = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Function} callbackfn (value: V, key: K, map: Map<K, V>) => void
@param {Object} [thisArg]
@returns {undefined}
**/
Map.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {(Object | undefined)} V | undefined
**/
Map.prototype.get = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {Boolean}
**/
Map.prototype.has = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@param {Object} value V
@returns {Map}
**/
Map.prototype.set = function(key, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {Number}
**/
Map.prototype.size = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of entries in the map.

@returns {IterableIterator}
**/
Map.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of key, value pairs for every entry in the map.

@returns {IterableIterator}
**/
Map.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of keys in the map

@returns {IterableIterator}
**/
Map.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the map

@returns {IterableIterator}
**/
Map.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
Map.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {MapConstructor}
**/
Map[Symbol.species] = new MapConstructor();

