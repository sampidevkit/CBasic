/**


@returns {Intl.Collator}
*/
Intl.Collator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@param {String} x
@param {String} y
@returns {Number}
**/
Intl.Collator.prototype.compare = function(x, y) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ResolvedCollatorOptions}
**/
Intl.Collator.prototype.resolvedOptions = function() {};

