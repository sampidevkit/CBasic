Reflect = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Calls the function with the specified object as the this value
and the elements of specified array as the arguments.

@param {Function} target Function - The function to call.
@param {Object} thisArgument The object to be used as the this object.
@param {ArrayLike} argumentsList ArrayLike - An array of argument values to be passed to the function.
@returns {Object}
**/
Reflect.apply = function(target, thisArgument, argumentsList) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Constructs the target with the elements of specified array as the arguments
and the specified constructor as the `new.target` value.

@param {Function} target Function - The constructor to invoke.
@param {ArrayLike} argumentsList ArrayLike - An array of argument values to be passed to the constructor.
@param {Function} [newTarget] Function - The constructor to be used as the `new.target` object.
@returns {Object}
**/
Reflect.construct = function(target, argumentsList) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Adds a property to an object, or modifies attributes of an existing property.

@param {Object} target Object on which to add or modify the property. This can be a native JavaScript object
(that is, a user-defined object or a built in object) or a DOM object.
@param {Object} propertyKey PropertyKey - The property name.
@param {PropertyDescriptor} attributes PropertyDescriptor - Descriptor for the property. It can be for a data property or an accessor property.
@returns {Boolean}
**/
Reflect.defineProperty = function(target, propertyKey, attributes) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Removes a property from an object, equivalent to `delete target[propertyKey]`,
except it won't throw if `target[propertyKey]` is non-configurable.

@param {Object} target Object from which to remove the own property.
@param {Object} propertyKey PropertyKey - The property name.
@returns {Boolean}
**/
Reflect.deleteProperty = function(target, propertyKey) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Gets the property of target, equivalent to `target[propertyKey]` when `receiver === target`.

@param {Object} target Object that contains the property on itself or in its prototype chain.
@param {Object} propertyKey PropertyKey - The property name.
@param {Object} [receiver] The reference to use as the `this` value in the getter function,
if `target[propertyKey]` is an accessor property.
@returns {Object}
**/
Reflect.get = function(target, propertyKey) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Gets the own property descriptor of the specified object.
An own property descriptor is one that is defined directly on the object and is not inherited from the object's prototype.

@param {Object} target Object that contains the property.
@param {Object} propertyKey PropertyKey - The property name.
@returns {(PropertyDescriptor | undefined)} PropertyDescriptor | undefined
**/
Reflect.getOwnPropertyDescriptor = function(target, propertyKey) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Returns the prototype of an object.

@param {Object} target The object that references the prototype.
@returns {(Object | null)} object | null
**/
Reflect.getPrototypeOf = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Equivalent to `propertyKey in target`.

@param {Object} target Object that contains the property on itself or in its prototype chain.
@param {Object} propertyKey PropertyKey - Name of the property.
@returns {Boolean}
**/
Reflect.has = function(target, propertyKey) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Returns a value that indicates whether new properties can be added to an object.

@param {Object} target Object to test.
@returns {Boolean}
**/
Reflect.isExtensible = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Returns the string and symbol keys of the own properties of an object. The own properties of an object
are those that are defined directly on that object, and are not inherited from the object's prototype.

@param {Object} target Object that contains the own properties.
@returns {(String | Symbol)} (string | symbol)[]
**/
Reflect.ownKeys = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Prevents the addition of new properties to an object.

@param {Object} target Object to make non-extensible.
@returns {Boolean}
**/
Reflect.preventExtensions = function(target) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Sets the property of target, equivalent to `target[propertyKey] = value` when `receiver === target`.

@param {Object} target Object that contains the property on itself or in its prototype chain.
@param {Object} propertyKey PropertyKey - Name of the property.
@param {Object} value
@param {Object} [receiver] The reference to use as the `this` value in the setter function,
if `target[propertyKey]` is an accessor property.
@returns {Boolean}
**/
Reflect.set = function(target, propertyKey, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.reflect.d.ts
/**
Sets the prototype of a specified object o to object proto or null.

@param {Object} target The object to change its prototype.
@param {(Object | null)} proto object | null - The value of the new prototype or null.
@returns {Boolean}
**/
Reflect.setPrototypeOf = function(target, proto) {};

