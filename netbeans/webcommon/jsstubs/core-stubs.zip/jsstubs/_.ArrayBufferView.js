/**


@returns {ArrayBufferView}
*/
ArrayBufferView = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ArrayBuffer} ArrayBufferLike
**/
ArrayBufferView.prototype.buffer = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
ArrayBufferView.prototype.byteLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
ArrayBufferView.prototype.byteOffset = new Number();

