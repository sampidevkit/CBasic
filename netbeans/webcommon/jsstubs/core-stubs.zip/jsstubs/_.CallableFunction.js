/**


@returns {CallableFunction}
*/
CallableFunction = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the function with the specified object as the this value and the elements of specified array as the arguments.

@param {Object} thisArg T
@param {Object} args A
@returns {Object} R
**/
CallableFunction.prototype.apply = function(thisArg, args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the function with the specified object as the this value and the specified rest arguments as the arguments.

@param {Object} thisArg T - The object to be used as the this object.
@param {Object} args A - Argument values to be passed to the function.
@returns {Object} R
**/
CallableFunction.prototype.call = function(thisArg, args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
For a given function, creates a bound function that has the same body as the original function.
The this object of the bound function is associated with the specified object, and has the specified initial parameters.

@param {Object} thisArg T
@param {AX[]} args AX[]
@returns {Function} (...args: AX[]) => R
**/
CallableFunction.prototype.bind = function(thisArg, args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the function, substituting the specified object for the this value of the function, and the specified array for the arguments of the function.

@param {Object} thisArg The object to be used as the this object.
@param {Object} [argArray] A set of arguments to be passed to the function.
@returns {Object}
**/
CallableFunction.prototype.apply = function(thisArg) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls a method of an object, substituting another object for the current object.

@param {Object} thisArg The object to be used as the current object.
@param {Object} argArray A list of arguments to be passed to the method.
@returns {Object}
**/
CallableFunction.prototype.call = function(thisArg, argArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
For a given function, creates a bound function that has the same body as the original function.
The this object of the bound function is associated with the specified object, and has the specified initial parameters.

@param {Object} thisArg An object to which the this keyword can refer inside the new function.
@param {Object} argArray A list of arguments to be passed to the new function.
@returns {Object}
**/
CallableFunction.prototype.bind = function(thisArg, argArray) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of a function.

@returns {String}
**/
CallableFunction.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
CallableFunction.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Object}
**/
CallableFunction.prototype.arguments = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Function}
**/
CallableFunction.prototype.caller = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {String}
**/
CallableFunction.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Determines whether the given value inherits from this function if this function was used
as a constructor function.

A constructor function can control which objects are recognized as its instances by
'instanceof' by overriding this method.

@param {Object} value
@returns {Boolean}
**/
CallableFunction.prototype[Symbol.hasInstance] = function(value) {};

