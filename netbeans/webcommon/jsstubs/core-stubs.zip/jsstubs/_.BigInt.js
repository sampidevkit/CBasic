/**


@returns {BigInt}
*/
BigInt = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns a string representation of an object.

@param {Number} [radix] Specifies a radix for converting numeric values to strings.
@returns {String}
**/
BigInt.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns a string representation appropriate to the host environment's current locale.

@param {String} [locales]
@param {BigIntToLocaleStringOptions} [options] BigIntToLocaleStringOptions
@returns {String}
**/
BigInt.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Returns the primitive value of the specified object.

@returns {BigInt}
**/
BigInt.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {"BigInt"}
**/
BigInt.prototype[Symbol.toStringTag] = "BigInt";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Interprets the low bits of a BigInt as a 2's-complement signed integer.
All higher bits are discarded.

@param {Number} bits The number of low bits to use
@param {BigInt} int The BigInt whose bits to extract
@returns {BigInt}
**/
BigInt.asIntN = function(bits, int) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**
Interprets the low bits of a BigInt as an unsigned integer.
All higher bits are discarded.

@param {Number} bits The number of low bits to use
@param {BigInt} int The BigInt whose bits to extract
@returns {BigInt}
**/
BigInt.asUintN = function(bits, int) {};

