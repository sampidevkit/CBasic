Intl = function() {};

