/**


@returns {TypedPropertyDescriptor}
*/
TypedPropertyDescriptor = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
TypedPropertyDescriptor.prototype.enumerable = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
TypedPropertyDescriptor.prototype.configurable = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
TypedPropertyDescriptor.prototype.writable = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Object} T
**/
TypedPropertyDescriptor.prototype.value = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Function} () => T
**/
TypedPropertyDescriptor.prototype.get = new Function();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Function} (value: T) => void
**/
TypedPropertyDescriptor.prototype.set = new Function();

