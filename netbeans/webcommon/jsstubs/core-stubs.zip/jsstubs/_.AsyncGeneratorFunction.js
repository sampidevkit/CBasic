//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@example new AsyncGeneratorFunction(args: Object)
@example new AsyncGeneratorFunction(args: String)

@param {Object} args A list of arguments the function accepts.
@returns {AsyncGeneratorFunction}
**/
AsyncGeneratorFunction = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@returns {Number}
**/
AsyncGeneratorFunction.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@returns {String}
**/
AsyncGeneratorFunction.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@returns {Number}
**/
AsyncGeneratorFunction.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@returns {String}
**/
AsyncGeneratorFunction.name = new String();

