/**


@returns {BigIntToLocaleStringOptions}
*/
BigIntToLocaleStringOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.localeMatcher = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.style = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.numberingSystem = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.unit = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.unitDisplay = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.currency = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.currencyDisplay = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {Boolean}
**/
BigIntToLocaleStringOptions.prototype.useGrouping = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {(1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21)} 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21
**/
BigIntToLocaleStringOptions.prototype.minimumIntegerDigits = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {(0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20)} 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20
**/
BigIntToLocaleStringOptions.prototype.minimumFractionDigits = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {(0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20)} 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20
**/
BigIntToLocaleStringOptions.prototype.maximumFractionDigits = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {(1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21)} 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21
**/
BigIntToLocaleStringOptions.prototype.minimumSignificantDigits = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {(1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21)} 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21
**/
BigIntToLocaleStringOptions.prototype.maximumSignificantDigits = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.notation = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.bigint.d.ts
/**


@returns {String}
**/
BigIntToLocaleStringOptions.prototype.compactDisplay = new String();

