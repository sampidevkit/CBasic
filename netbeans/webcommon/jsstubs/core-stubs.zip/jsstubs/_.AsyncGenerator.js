/**


@returns {AsyncGenerator}
*/
AsyncGenerator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@param {(Object | Object)} args [] | [TNext]
@returns {Promise}
**/
AsyncGenerator.prototype.next = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@param {(Object | PromiseLike)} value TReturn | PromiseLike<TReturn>
@returns {Promise}
**/
AsyncGenerator.prototype.return = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@param {Object} e
@returns {Promise}
**/
AsyncGenerator.prototype.throw = function(e) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asyncgenerator.d.ts
/**


@returns {AsyncGenerator}
**/
AsyncGenerator.prototype[Symbol.asyncIterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {(Object | Object)} args [] | [TNext]
@returns {Promise}
**/
AsyncGenerator.prototype.next = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {(Object | PromiseLike)} [value] TReturn | PromiseLike<TReturn>
@returns {Promise}
**/
AsyncGenerator.prototype.return = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {Object} [e]
@returns {Promise}
**/
AsyncGenerator.prototype.throw = function() {};

