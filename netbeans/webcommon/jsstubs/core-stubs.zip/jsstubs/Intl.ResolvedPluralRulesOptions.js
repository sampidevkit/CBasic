/**


@returns {Intl.ResolvedPluralRulesOptions}
*/
Intl.ResolvedPluralRulesOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {String}
**/
Intl.ResolvedPluralRulesOptions.prototype.locale = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {LDMLPluralRule[]}
**/
Intl.ResolvedPluralRulesOptions.prototype.pluralCategories = new Array();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {("cardinal" | "ordinal")} PluralRuleType
**/
Intl.ResolvedPluralRulesOptions.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {Number}
**/
Intl.ResolvedPluralRulesOptions.prototype.minimumIntegerDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {Number}
**/
Intl.ResolvedPluralRulesOptions.prototype.minimumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {Number}
**/
Intl.ResolvedPluralRulesOptions.prototype.maximumFractionDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {Number}
**/
Intl.ResolvedPluralRulesOptions.prototype.minimumSignificantDigits = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {Number}
**/
Intl.ResolvedPluralRulesOptions.prototype.maximumSignificantDigits = new Number();

