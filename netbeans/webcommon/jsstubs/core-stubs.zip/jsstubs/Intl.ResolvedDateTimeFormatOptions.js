/**


@returns {Intl.ResolvedDateTimeFormatOptions}
*/
Intl.ResolvedDateTimeFormatOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.locale = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.calendar = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.numberingSystem = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.timeZone = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Boolean}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.hour12 = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.weekday = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.era = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.year = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.month = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.day = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.hour = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.minute = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.second = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
Intl.ResolvedDateTimeFormatOptions.prototype.timeZoneName = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("basic" | "best fit" | "best fit")} "basic" | "best fit" | "best fit"
**/
Intl.ResolvedDateTimeFormatOptions.prototype.formatMatcher = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("full" | "long" | "medium" | "short")} "full" | "long" | "medium" | "short"
**/
Intl.ResolvedDateTimeFormatOptions.prototype.dateStyle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("full" | "long" | "medium" | "short")} "full" | "long" | "medium" | "short"
**/
Intl.ResolvedDateTimeFormatOptions.prototype.timeStyle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("h11" | "h12" | "h23" | "h24")} "h11" | "h12" | "h23" | "h24"
**/
Intl.ResolvedDateTimeFormatOptions.prototype.hourCycle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {("narrow" | "short" | "long")} "narrow" | "short" | "long"
**/
Intl.ResolvedDateTimeFormatOptions.prototype.dayPeriod = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2021.intl.d.ts
/**


@returns {(0 | 1 | 2 | 3)} 0 | 1 | 2 | 3
**/
Intl.ResolvedDateTimeFormatOptions.prototype.fractionalSecondDigits = new Object();

