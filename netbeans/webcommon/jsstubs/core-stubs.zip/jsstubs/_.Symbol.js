/**


@returns {Symbol}
*/
Symbol = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an object.

@returns {String}
**/
Symbol.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the primitive value of the specified object.

@returns {Symbol}
**/
Symbol.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**
Converts a Symbol object to a symbol.

@param {String} hint
@returns {Symbol}
**/
Symbol.prototype[Symbol.toPrimitive] = function(hint) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
Symbol.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2019.symbol.d.ts
/**


@returns {(String | undefined)} string | undefined
**/
Symbol.prototype.description = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {Symbol}
**/
Symbol.iterator = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.d.ts
/**
Returns a Symbol object from the global symbol registry matching the given key if found.
Otherwise, returns a new symbol with this key.

@param {String} key key to search for.
@returns {Symbol}
**/
Symbol.for = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.d.ts
/**
Returns a key from the global symbol registry matching the given Symbol if found.
Otherwise, returns a undefined.

@param {Symbol} sym Symbol to find the key for.
@returns {(String | undefined)} string | undefined
**/
Symbol.keyFor = function(sym) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.hasInstance = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.isConcatSpreadable = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.match = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.replace = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.search = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.species = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.split = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.toPrimitive = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.toStringTag = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.unscopables = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@returns {Symbol}
**/
Symbol.asyncIterator = new Symbol();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.symbol.wellknown.d.ts
/**


@returns {Symbol}
**/
Symbol.matchAll = new Symbol();

