/**


@returns {Intl.NumberFormatPart}
*/
Intl.NumberFormatPart = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {("literal" | "nan" | "infinity" | "percent" | "integer" | "group" | "decimal" | "fraction" | "plusSign" | "minusSign" | "percentSign" | "currency" | "code" | "symbol" | "name" | "compact" | "exponentInteger" | "exponentMinusSign" | "exponentSeparator" | "unit" | "unknown")} NumberFormatPartTypes
**/
Intl.NumberFormatPart.prototype.type = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.intl.d.ts
/**


@returns {String}
**/
Intl.NumberFormatPart.prototype.value = new String();

