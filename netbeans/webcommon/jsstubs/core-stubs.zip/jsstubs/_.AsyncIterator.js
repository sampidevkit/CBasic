/**


@returns {AsyncIterator}
*/
AsyncIterator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {(Object | Object)} args [] | [TNext]
@returns {Promise}
**/
AsyncIterator.prototype.next = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {(Object | PromiseLike)} [value] TReturn | PromiseLike<TReturn>
@returns {Promise}
**/
AsyncIterator.prototype.return = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {Object} [e]
@returns {Promise}
**/
AsyncIterator.prototype.throw = function() {};

