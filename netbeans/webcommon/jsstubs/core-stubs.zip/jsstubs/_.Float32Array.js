//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new Float32Array(buffer: ArrayBufferLike)
@example new Float32Array(buffer: ArrayBufferLike, byteOffset: Number)
@example new Float32Array(buffer: ArrayBufferLike, byteOffset: Number, length: Number)
@example new Float32Array(length: Number)
@example new Float32Array(array: ArrayLike<number> | ArrayBufferLike)
@example new Float32Array(elements: Iterable)
@example new Float32Array()

@param {ArrayBuffer} buffer ArrayBufferLike
@param {Number} [byteOffset]
@param {Number} [length]
@returns {Float32Array}
**/
Float32Array = function(buffer) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Float32Array.prototype.BYTES_PER_ELEMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ArrayBuffer} ArrayBufferLike
**/
Float32Array.prototype.buffer = new ArrayBuffer();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Float32Array.prototype.byteLength = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Float32Array.prototype.byteOffset = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the this object after copying a section of the array identified by start and end
to the same array starting at position target

@param {Number} target If target is negative, it is treated as length+target where length is the
length of the array.
@param {Number} start If start is negative, it is treated as length+start. If end is negative, it
is treated as length+end.
@param {Number} [end] If not specified, length of the this object is used as its default value.
@returns {Float32Array}
**/
Float32Array.prototype.copyWithin = function(target, start) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether all the members of an array satisfy the specified test.

@param {Function} predicate (value: number, index: number, array: Float32Array) => unknown - A function that accepts up to three arguments. The every method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value false, or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
Float32Array.prototype.every = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Changes all array elements from `start` to `end` index to a static `value` and returns the modified array

@param {Number} value value to fill array section with
@param {Number} [start] index to start filling the array at. If start is negative, it is treated as
length+start where length is the length of the array.
@param {Number} [end] index to stop filling the array at. If end is negative, it is treated as
length+end.
@returns {Float32Array}
**/
Float32Array.prototype.fill = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the elements of an array that meet the condition specified in a callback function.

@param {Function} predicate (value: number, index: number, array: Float32Array) => any - A function that accepts up to three arguments. The filter method calls
the predicate function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Float32Array}
**/
Float32Array.prototype.filter = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the value of the first element in the array where predicate is true, and undefined
otherwise.

@param {Function} predicate (value: number, index: number, obj: Float32Array) => boolean - find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found, find
immediately returns that element value. Otherwise, find returns undefined.
@param {Object} [thisArg] If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.
@returns {(Number | undefined)} number | undefined
**/
Float32Array.prototype.find = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the first element in the array where predicate is true, and -1
otherwise.

@param {Function} predicate (value: number, index: number, obj: Float32Array) => boolean - find calls predicate once for each element of the array, in ascending
order, until it finds one where predicate returns true. If such an element is found,
findIndex immediately returns that element index. Otherwise, findIndex returns -1.
@param {Object} [thisArg] If provided, it will be used as the this value for each invocation of
predicate. If it is not provided, undefined is used instead.
@returns {Number}
**/
Float32Array.prototype.findIndex = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Performs the specified action for each element in an array.

@param {Function} callbackfn (value: number, index: number, array: Float32Array) => void - A function that accepts up to three arguments. forEach calls the
callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function.
If thisArg is omitted, undefined is used as the this value.
@returns {undefined}
**/
Float32Array.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the first occurrence of a value in an array.

@param {Number} searchElement The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the
search starts at index 0.
@returns {Number}
**/
Float32Array.prototype.indexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Adds all the elements of an array separated by the specified separator string.

@param {String} [separator] A string used to separate one element of an array from the next in the
resulting String. If omitted, the array elements are separated with a comma.
@returns {String}
**/
Float32Array.prototype.join = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the index of the last occurrence of a value in an array.

@param {Number} searchElement The value to locate in the array.
@param {Number} [fromIndex] The array index at which to begin the search. If fromIndex is omitted, the
search starts at index 0.
@returns {Number}
**/
Float32Array.prototype.lastIndexOf = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Float32Array.prototype.length = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls a defined callback function on each element of an array, and returns an array that
contains the results.

@param {Function} callbackfn (value: number, index: number, array: Float32Array) => number - A function that accepts up to three arguments. The map method calls the
callbackfn function one time for each element in the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the callbackfn function.
If thisArg is omitted, undefined is used as the this value.
@returns {Float32Array}
**/
Float32Array.prototype.map = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the specified callback function for all the elements in an array. The return value of
the callback function is the accumulated result, and is provided as an argument in the next
call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: number, currentIndex: number, array: Float32Array) => U - A function that accepts up to four arguments. The reduce method calls the
callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start
the accumulation. The first call to the callbackfn function provides this value as an argument
instead of an array value.
@returns {Object} U
**/
Float32Array.prototype.reduce = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Calls the specified callback function for all the elements in an array, in descending order.
The return value of the callback function is the accumulated result, and is provided as an
argument in the next call to the callback function.

@param {Function} callbackfn (previousValue: U, currentValue: number, currentIndex: number, array: Float32Array) => U - A function that accepts up to four arguments. The reduceRight method calls
the callbackfn function one time for each element in the array.
@param {Object} initialValue U - If initialValue is specified, it is used as the initial value to start
the accumulation. The first call to the callbackfn function provides this value as an argument
instead of an array value.
@returns {Object} U
**/
Float32Array.prototype.reduceRight = function(callbackfn, initialValue) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Reverses the elements in an Array.

@returns {Float32Array}
**/
Float32Array.prototype.reverse = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sets a value or an array of values.

@param {ArrayLike} array ArrayLike - A typed or untyped array of values to set.
@param {Number} [offset] The index in the current array at which the values are to be written.
@returns {undefined}
**/
Float32Array.prototype.set = function(array) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a section of an array.

@param {Number} [start] The beginning of the specified portion of the array.
@param {Number} [end] The end of the specified portion of the array. This is exclusive of the element at the index 'end'.
@returns {Float32Array}
**/
Float32Array.prototype.slice = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Determines whether the specified callback function returns true for any element of an array.

@param {Function} predicate (value: number, index: number, array: Float32Array) => unknown - A function that accepts up to three arguments. The some method calls
the predicate function for each element in the array until the predicate returns a value
which is coercible to the Boolean value true, or until the end of the array.
@param {Object} [thisArg] An object to which the this keyword can refer in the predicate function.
If thisArg is omitted, undefined is used as the this value.
@returns {Boolean}
**/
Float32Array.prototype.some = function(predicate) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Sorts an array.

@param {Function} [compareFn] (a: number, b: number) => number - Function used to determine the order of the elements. It is expected to return
a negative value if first argument is less than second argument, zero if they're equal and a positive
value otherwise. If omitted, the elements are sorted in ascending order.
```ts
[11,2,22,1].sort((a, b) => a - b)
```
@returns {Float32Array}
**/
Float32Array.prototype.sort = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Gets a new Float32Array view of the ArrayBuffer store for this array, referencing the elements
at begin, inclusive, up to end, exclusive.

@param {Number} [begin] The index of the beginning of the array.
@param {Number} [end] The index of the end of the array.
@returns {Float32Array}
**/
Float32Array.prototype.subarray = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts a number to a string by using the current locale.

@returns {String}
**/
Float32Array.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an array.

@returns {String}
**/
Float32Array.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the primitive value of the specified object.

@returns {Float32Array}
**/
Float32Array.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**


@returns {IterableIterator}
**/
Float32Array.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an array of key, value pairs for every entry in the array

@returns {IterableIterator}
**/
Float32Array.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an list of keys in the array

@returns {IterableIterator}
**/
Float32Array.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an list of values in the array

@returns {IterableIterator}
**/
Float32Array.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {"Float32Array"}
**/
Float32Array.prototype[Symbol.toStringTag] = "Float32Array";

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2016.array.include.d.ts
/**
Determines whether an array includes a certain element, returning true or false as appropriate.

@param {Number} searchElement The element to search for.
@param {Number} [fromIndex] The position in this array at which to begin searching for searchElement.
@returns {Boolean}
**/
Float32Array.prototype.includes = function(searchElement) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.array.d.ts
/**
Returns the item located at the specified index.

@param {Number} index The zero-based index of the desired code unit. A negative index will count back from the last item.
@returns {(Number | undefined)} number | undefined
**/
Float32Array.prototype.at = function(index) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Float32Array.BYTES_PER_ELEMENT = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a new array from a set of elements.

@param {Number} items A set of elements to include in the new array object.
@returns {Float32Array}
**/
Float32Array.of = function(items) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Creates an array from an array-like or iterable object.

@param {Iterable} arrayLike Iterable - An array-like or iterable object to convert to an array.
@param {Function} [mapfn] (v: number, k: number) => number - A mapping function to call on every element of the array.
@param {Object} [thisArg] Value of 'this' used to invoke the mapfn.
@returns {Float32Array}
**/
Float32Array.from = function(arrayLike) {};

