//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@example new WeakMap()
@example new WeakMap(entries: readonly [K, V][] | null)
@example new WeakMap(iterable: Iterable)

@param {(Object | null)} [entries] readonly [K, V][] | null
@returns {WeakMap}
**/
WeakMap = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {Boolean}
**/
WeakMap.prototype.delete = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {(Object | undefined)} V | undefined
**/
WeakMap.prototype.get = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@returns {Boolean}
**/
WeakMap.prototype.has = function(key) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} key K
@param {Object} value V
@returns {WeakMap}
**/
WeakMap.prototype.set = function(key, value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
WeakMap.prototype[Symbol.toStringTag] = new String();

