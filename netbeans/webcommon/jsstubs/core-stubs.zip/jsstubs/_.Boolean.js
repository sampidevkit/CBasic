//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@example new Boolean()
@example new Boolean(value: Object)

@param {Object} [value]
@returns {Boolean}
**/
Boolean = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the primitive value of the specified object.

@returns {Boolean}
**/
Boolean.prototype.valueOf = function() {};

