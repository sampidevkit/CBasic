/**
Marker for contextual 'this' type

@returns {ThisType}
*/
ThisType = function() {};

