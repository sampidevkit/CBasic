//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@example new Set()
@example new Set(values: readonly T[] | null)
@example new Set()
@example new Set(iterable: Iterable<T> | null)

@param {(T[] | null)} [values] readonly T[] | null
@returns {Set}
**/
Set = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {Set}
**/
Set.prototype.add = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {undefined}
**/
Set.prototype.clear = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {Boolean}
**/
Set.prototype.delete = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Function} callbackfn (value: T, value2: T, set: Set<T>) => void
@param {Object} [thisArg]
@returns {undefined}
**/
Set.prototype.forEach = function(callbackfn) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@param {Object} value T
@returns {Boolean}
**/
Set.prototype.has = function(value) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.collection.d.ts
/**


@returns {Number}
**/
Set.prototype.size = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Iterates over values in the set.

@returns {IterableIterator}
**/
Set.prototype[Symbol.iterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of [v,v] pairs for every value `v` in the set.

@returns {IterableIterator}
**/
Set.prototype.entries = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Despite its name, returns an iterable of the values in the set.

@returns {IterableIterator}
**/
Set.prototype.keys = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.iterable.d.ts
/**
Returns an iterable of values in the set.

@returns {IterableIterator}
**/
Set.prototype.values = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {String}
**/
Set.prototype[Symbol.toStringTag] = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.symbol.wellknown.d.ts
/**


@returns {SetConstructor}
**/
Set[Symbol.species] = new SetConstructor();

