/**
The type for the optional second argument to `import()`.

If your host environment supports additional options, this type may be
augmented via interface merging.

@returns {ImportCallOptions}
*/
ImportCallOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {ImportAssertions}
**/
ImportCallOptions.prototype.assert = new ImportAssertions();

