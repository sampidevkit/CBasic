//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
An object that represents a number of any kind. All JavaScript numbers are 64-bit floating-point numbers.

@example new Number()
@example new Number(value: Object)

@param {Object} [value]
@returns {Number}
**/
Number = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representation of an object.

@param {Number} [radix] Specifies a radix for converting numeric values to strings. This value is only used for numbers.
@returns {String}
**/
Number.prototype.toString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string representing a number in fixed-point notation.

@param {Number} [fractionDigits] Number of digits after the decimal point. Must be in the range 0 - 20, inclusive.
@returns {String}
**/
Number.prototype.toFixed = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string containing a number represented in exponential notation.

@param {Number} [fractionDigits] Number of digits after the decimal point. Must be in the range 0 - 20, inclusive.
@returns {String}
**/
Number.prototype.toExponential = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns a string containing a number represented either in exponential or fixed-point notation with a specified number of digits.

@param {Number} [precision] Number of significant digits. Must be in the range 1 - 21, inclusive.
@returns {String}
**/
Number.prototype.toPrecision = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Returns the primitive value of the specified object.

@returns {Number}
**/
Number.prototype.valueOf = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**
Converts a number to a string by using the current or specified locale.

@param {(String | String)} [locales] string | string[] - A locale string or array of locale strings that contain one or more language or locale tags. If you include more than one locale string, list them in descending order of priority so that the first entry is the preferred locale. If you omit this parameter, the default locale of the JavaScript runtime is used.
@param {Intl.NumberFormatOptions} [options] Intl.NumberFormatOptions - An object that contains one or more properties that specify comparison options.
@returns {String}
**/
Number.prototype.toLocaleString = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Number.MAX_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Number.MIN_VALUE = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Number.NaN = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Number.NEGATIVE_INFINITY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {Number}
**/
Number.POSITIVE_INFINITY = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {Number}
**/
Number.EPSILON = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if passed value is finite.
Unlike the global isFinite, Number.isFinite doesn't forcibly convert the parameter to a
number. Only finite values of the type number, result in true.

@param {Object} number A numeric value.
@returns {Boolean}
**/
Number.isFinite = function(number) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if the value passed is an integer, false otherwise.

@param {Object} number A numeric value.
@returns {Boolean}
**/
Number.isInteger = function(number) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns a Boolean value that indicates whether a value is the reserved value NaN (not a
number). Unlike the global isNaN(), Number.isNaN() doesn't forcefully convert the parameter
to a number. Only values of the type number, that are also NaN, result in true.

@param {Object} number A numeric value.
@returns {Boolean}
**/
Number.isNaN = function(number) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Returns true if the value passed is a safe integer.

@param {Object} number A numeric value.
@returns {Boolean}
**/
Number.isSafeInteger = function(number) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {Number}
**/
Number.MAX_SAFE_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**


@returns {Number}
**/
Number.MIN_SAFE_INTEGER = new Number();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Converts a string to a floating-point number.

@param {String} string A string that contains a floating-point number.
@returns {Number}
**/
Number.parseFloat = function(string) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2015.core.d.ts
/**
Converts A string to an integer.

@param {String} string A string to convert into a number.
@param {Number} [radix] A value between 2 and 36 that specifies the base of the number in `string`.
If this argument is not supplied, strings with a prefix of '0x' are considered hexadecimal.
All other strings are considered decimal.
@returns {Number}
**/
Number.parseInt = function(string) {};

