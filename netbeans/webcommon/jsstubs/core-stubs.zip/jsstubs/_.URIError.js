//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@example new URIError()
@example new URIError(message: String)
@example new URIError(message: String, options: ErrorOptions)
@example new URIError()
@example new URIError(message: String)

@param {String} [message]
@param {ErrorOptions} [options] ErrorOptions
@returns {URIError}
**/
URIError = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
URIError.prototype.name = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
URIError.prototype.message = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es5.d.ts
/**


@returns {String}
**/
URIError.prototype.stack = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2022.error.d.ts
/**


@returns {Error}
**/
URIError.prototype.cause = new Error();

