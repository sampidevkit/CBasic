/**


@returns {Intl.LocaleOptions}
*/
Intl.LocaleOptions = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.baseName = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.calendar = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("upper" | "lower" | "false")} LocaleCollationCaseFirst
**/
Intl.LocaleOptions.prototype.caseFirst = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.collation = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {("h12" | "h23" | "h11" | "h24")} LocaleHourCycleKey
**/
Intl.LocaleOptions.prototype.hourCycle = new Object();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.language = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.numberingSystem = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {Boolean}
**/
Intl.LocaleOptions.prototype.numeric = new Boolean();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.region = new String();

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2020.intl.d.ts
/**


@returns {String}
**/
Intl.LocaleOptions.prototype.script = new String();

