/**


@returns {AsyncIterableIterator}
*/
AsyncIterableIterator = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@returns {AsyncIterableIterator}
**/
AsyncIterableIterator.prototype[Symbol.asyncIterator] = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {(Object | Object)} args [] | [TNext]
@returns {Promise}
**/
AsyncIterableIterator.prototype.next = function(args) {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {(Object | PromiseLike)} [value] TReturn | PromiseLike<TReturn>
@returns {Promise}
**/
AsyncIterableIterator.prototype.return = function() {};

//Source: /home/matthias/src/netbeans-tools/jsstub-generator/node_modules/typescript/lib/lib.es2018.asynciterable.d.ts
/**


@param {Object} [e]
@returns {Promise}
**/
AsyncIterableIterator.prototype.throw = function() {};

